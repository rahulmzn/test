# neom-fss-pay-cross-cutting-lib

Library for common cross cutting functions like exception handling, logging, utils


<!-- ABOUT THE PROJECT -->

## About The Project

This is common library which will provide all the common cross-cutting concerns like handling exceptions, logging
functionality, web-flux support, utils support. These common concerns are required in almost all the Microservices and
can be used by just adding this library as a dependency.

# About Webflux

WebRequestSender interface exposes methods that allows sending basic http requests. Usage:

Inject the service and do the request. Example:

```   
   @Value("${api.address}")
   private String apiAddress;
    
   private final WebRequestSender apiSender;

   public List<CountryDto> getSomething() {
   ParameterizedTypeReference<List<String>> parameterizedTypeReference = new ParameterizedTypeReference<>() {};
   var availableCountriesURI = UriComponentsBuilder.fromHttpUrl(apiAddress + "/AvailableCountries").build().toUri();

   return Optional.ofNullable(apiSender.sendGetRequest(availableCountriesURI, parameterizedTypeReference))
      .orElse(new ArrayList<>());
   }
   ```

In case of any specific configurations for API like responseTimeout, default headers etc. you
should create your own WebClient configuration and import it using @Qualifier.

# About Common Exception Handling

Whenever any exception is getting generated if its Bad Request, Data not Found, Client or Server error then those
exceptions are intercepted by the Exception handling advice and based on the exception class specific advice handles it
and builds a proper error response which is passed as a ResponseEntity aas a final response.



example:
Bad Request Exception handling

``` 
@ExceptionHandler(ServiceException.BadInput.class)
public ResponseEntity<ErrorResponse> handleServiceExceptionBadInput(ServiceException.BadInput e) {
  log.error(String.format("handleServiceExceptionBadInput %s", e.getMessage()), e);
  return new ResponseEntity<>(
          this.buildErrorResponse(HttpStatus.BAD_REQUEST, CommonConstants.VALIDATION_FAILED,
                  e.getMessage()), HttpStatus.BAD_REQUEST);
}
``` 

To use the exception handling flow in microservices then you have to add the current service package name and 
cross-cutting lib package name in ComponentScan Annotation as mentioned below in the Application.java file.

``` 
@SpringBootApplication
@ComponentScan(value = {"<your-base-package-name>","com.neom.fss.neompay.crosscuttinglib"})
public class Application {

    @Generated
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}
``` 

# About Performance Logging

If any request from Client reaches the Endpoint then for checking the performance of the request and response we keep
the performance logs. This provides an analysis of how much time a request takes to complete and based on that we can
determine if the flow needs any performance upgrades.

Here, we have created a configuration which defines Pointcut expressions and advice. Moreover, there is an interceptor
which intercepts all the request and when the pointcut expression is matched then log with start time is registered in
log file and when the final response is sent from the controller then logs the total time the request has taken.

example:
Pointcut defined within PerformanceLoggingConfiguration

```@Pointcut("execution(public * com.neom.fss.neompay.*.*.controller.*Controller.*(..))")
public void performanceMonitor() {
}
``` 

PerformanceLoggingInterceptor that logs the time

```
@Override
    protected Object invokeUnderTrace(MethodInvocation methodInvocation, Log logger)
        throws Throwable {
        String name = createInvocationTraceName(methodInvocation);
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        try {
            return methodInvocation.proceed();
        } finally {
            stopWatch.stop();
            log.trace(String.format("[PERFTMSTMP:%s:%d]", name, stopWatch.getTotalTimeMillis()));
        }
    }
```
Enable the performance logging by adding following to the logging settings within application yaml of a domain service
```
   com.neom.fss.neompay.domain.crosscuttinglib.logging.PerformanceLoggingInterceptor: TRACE
```


## Built With - Frameworks, Tools & technologies

* [JDK 11](https://jdk.java.net/11/)
* SpringBoot <version> - MicroService Implementation. It has been tested with two oAuth providers.
    * [GitLab API](https://docs.gitlab.com/ee/api/)
    * [GitHub API](https://docs.github.com/en/rest)
* Nimbus-jose-jwt framework
* Google Flogger - Logging
* Spring Security - Securing the service and implementing zero trust model standards.
* Mockito Springboot & Junit - Unit & Component Testing
* Helm - for packing and deploying the service to any kubernetes platform
* [Google JIB](https://github.com/GoogleContainerTools/jib)
* Docker - for building java containers alternative to Google JIB
* Gradle - Build Tool
* Jenkins & shared libraries for build and deploy

## Prerequisites

* JDK 11
* Java IDE, you can use any IDE whichever you want, examples:
    * IntelliJ
    * Eclipse

## Setup guidelines for server environments

## Endpoints Available