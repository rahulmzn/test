package com.lbg.crosscuttinglib.util;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.crosscuttinglib.model.TestData;
import java.io.File;
import java.io.IOException;
import java.util.Objects;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class JsonHelperTest {

    private JsonHelper jsonHelper = new JsonHelper(new ObjectMapper());

    @Test
    void objectFromJsonFile() throws IOException {
        File newState = new File("test.json");
        TestData actualResult = jsonHelper.objectFromJsonFile("test.json", TestData.class);
        assertTrue(Objects.nonNull(actualResult));
        assertEquals(1, actualResult.getPostId());
        assertEquals(6, actualResult.getId());
        assertEquals("test-data", actualResult.getBody());
    }

    @Test
    void objectAsJsonData() throws IOException {
        TestData givenData = jsonHelper.objectFromJsonFile("test.json", TestData.class);
        String actualResult = jsonHelper.objectAsJsonData(givenData);
        assertTrue(actualResult.contains(givenData.getBody()));
    }
}