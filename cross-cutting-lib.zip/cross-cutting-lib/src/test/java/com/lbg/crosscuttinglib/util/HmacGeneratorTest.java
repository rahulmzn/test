package com.lbg.crosscuttinglib.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.security.SignatureException;
import org.apache.logging.log4j.util.Strings;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@Tag("HMACGeneratorTest")
class HmacGeneratorTest {


    @Test
    @DisplayName("Should generate hash value for given content")
    void generateHMACBySHA256() throws SignatureException {
        String textContentToBeEncrypted = "{\"id\":\"evt_acynoqlweulejnbj6sbc5n2mhi\",\"type\":\"payment_approved\",\"created_on\":\"2022-02-20T22:18:40Z\",\"data\":{\"action_id\":\"act_psplalyviglk5mcjvdghmedylm\",\"payment_type\":\"REGULAR\",\"auth_code\":\"360937\",\"response_code\":\"10000\",\"response_summary\":\"Approved\",\"description\":\"Some Description\",\"scheme_id\":\"954190541657990\",\"source\":{\"id\":\"src_xaj7hqhnjvkefgt3qi4sn2amta\",\"type\":\"card\",\"billing_address\":{},\"expiry_month\":2,\"expiry_year\":2022,\"scheme\":\"VISA\",\"last_4\":\"3827\",\"fingerprint\":\"eb18d6fead198af0e2aed05ff13b8b207002f89623860132c62c592d9c5a8baa\",\"bin\":\"453936\",\"card_type\":\"Credit\",\"card_category\":\"Consumer\",\"issuer\":\"CITIBANK\",\"issuer_country\":\"KR\",\"product_id\":\"P\",\"product_type\":\"Visa Gold\",\"avs_check\":\"UM\",\"cvv_check\":\"Y\"},\"customer\":{\"id\":\"cus_xo3k3uh55ppurnt6uq7o2rva4u\",\"email\":\"9638527415@neom.com\"},\"processing\":{\"acquirer_transaction_id\":\"9191192240\",\"retrieval_reference_number\":\"099349644082\"},\"amount\":100,\"metadata\":{},\"risk\":{\"flagged\":false},\"id\":\"pay_psplalyviglk5mcjvdghmedylm\",\"currency\":\"SAR\",\"processed_on\":\"2022-02-20T22:18:40Z\"},\"_links\":{\"self\":{\"href\":\"https://api.sandbox.checkout.com/events/evt_acynoqlweulejnbj6sbc5n2mhi\"},\"payment\":{\"href\":\"https://api.sandbox.checkout.com/payments/pay_psplalyviglk5mcjvdghmedylm\"}}}";
        String sceretKeyForEncryption = "sk_test_a44e4116-9927-4d86-ba12-bf8e61b632af";
        String expectedHashOutput = "6679446b56d6fb62ab452d228b5304ada8b22b7e8a09308b26650e81e3340e12";

        String actualResult = HmacGenerator.generateHMACBySHA256(textContentToBeEncrypted, sceretKeyForEncryption);
        assertEquals(actualResult, expectedHashOutput);
    }


    @Test
    @DisplayName("Should return empty hash string when content is empty")
    void generateEmptyHash() throws SignatureException {
        String key = "sk_test_a44e4116-9927-4d86-ba12-bf8e61b632af";

        String actualResult = HmacGenerator.generateHMACBySHA256(Strings.EMPTY, key);
        assertEquals(Strings.EMPTY, actualResult);
    }
}