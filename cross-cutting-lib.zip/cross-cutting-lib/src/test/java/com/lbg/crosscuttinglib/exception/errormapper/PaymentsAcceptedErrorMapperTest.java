package com.lbg.crosscuttinglib.exception.errormapper;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.lbg.crosscuttinglib.proxy.checkout.CheckoutErrorMappings;
import com.lbg.crosscuttinglib.proxy.checkout.errormapper.PaymentsAcceptedErrorMapper;

import java.io.IOException;
import java.net.URL;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class PaymentsAcceptedErrorMapperTest {

    @Mock
    private CheckoutErrorMappings checkoutErrorMappings;

    @InjectMocks
    private PaymentsAcceptedErrorMapper paymentsAcceptedErrorMapper;

    private ObjectNode objectNode;

    @Mock
    private JsonNode jsonNode;

    @BeforeEach
    void setUp() throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        URL url = new URL("file:src/test/resources/payments-accepted-response-test.JSON");
        objectNode = (ObjectNode) mapper.readTree(url);
    }

    @ParameterizedTest(name = "responseStatus:{0}, expected:{1}")
    @CsvSource({
        "BAD_REQUEST,Pending, false",
        "ACCEPTED,Pending, false",
        "ACCEPTED,Authorised, true"
    })
    @DisplayName("Test isValid for different status codes")
    void isValid(HttpStatus responseStatus,String status, boolean expected) {
        objectNode.put("status",status);

        boolean isValid = paymentsAcceptedErrorMapper.isApplicable(objectNode, responseStatus);

        if (expected){
            assertTrue(isValid);
        } else {
            assertFalse(isValid);
        }
    }

    @ParameterizedTest(name = "responseStatus:{0}, expected:{1}")
    @CsvSource({
        "BAD_REQUEST,Pending",
        "ACCEPTED,Pending",
        "ACCEPTED,Authorised"
    })
    @DisplayName("Test isValid for different status codes")
    void map(HttpStatus responseStatus,String status) {
        objectNode.put("status",status);

        String genericPaymentErrorCode = "NPAY_PYMT_10137";
        when(checkoutErrorMappings.getGenericPaymentErrorCode()).thenReturn(genericPaymentErrorCode);

        Mono<ClientResponse> map = paymentsAcceptedErrorMapper.processError(objectNode, responseStatus);

        assertNotNull(map);
    }
}