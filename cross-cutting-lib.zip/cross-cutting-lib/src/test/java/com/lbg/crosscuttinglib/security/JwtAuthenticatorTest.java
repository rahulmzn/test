package com.lbg.crosscuttinglib.security;

import static org.junit.jupiter.api.Assertions.assertThrows;

import com.lbg.crosscuttinglib.constants.ApiHeader;
import com.lbg.crosscuttinglib.security.util.JwtVerificationUtil;

import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;

@ExtendWith(MockitoExtension.class)
class JwtAuthenticatorTest {

    @Mock
    private JwtVerificationUtil jwtVerificationUtil;

    @InjectMocks
    private JwtAuthenticator instance;

    @Test
    void invalidJwtFails() {
        Map<String, String> headers = new HashMap<>();
        headers.put(ApiHeader.AUTHORIZATION.name(), "eyJ0eXAiOiJKV1");
        headers.put(ApiHeader.NEOM_CHANNEL.name(), "MOBILE");

        assertThrows(AccessDeniedException.class,
            () -> instance.authenticate(headers));
    }
}
