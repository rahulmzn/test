package com.lbg.crosscuttinglib.exception.errormapper;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.lbg.crosscuttinglib.proxy.checkout.CheckoutErrorMappings;
import com.lbg.crosscuttinglib.proxy.checkout.errormapper.CardServerClientErrorMapper;
import com.lbg.crosscuttinglib.client.checkout.dto.ErrorResponseDto;

import java.util.HashMap;
import java.util.List;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class CardServerClientErrorMapperTest {

    @Mock
    private CheckoutErrorMappings checkoutErrorMappings;

    @InjectMocks
    private CardServerClientErrorMapper cardServerClientErrorMapper;

    private HashMap<String, String> errorMappings;

    @BeforeEach
    void setUp() {
         errorMappings = new HashMap<>();
         errorMappings.put("request_invalid","NPAY_CC_10201");
         errorMappings.put("processing_error","NPAY_CC_10201");
         errorMappings.put("service_unavailable","NPAY_CC_10201");
         errorMappings.put("token_type_invalid","NPAY_CC_10201");
         errorMappings.put("token_data_invalid","NPAY_CC_10201");
    }

    @NotNull
    private ErrorResponseDto getErrorResponseDto(String errorType) {
        ErrorResponseDto errorResponseDto = new ErrorResponseDto();
        errorResponseDto.setErrorType(errorType);
        errorResponseDto.setErrorCodes(List.of("payment_source_required"));
        return errorResponseDto;
    }

    @ParameterizedTest(name = "responseStatus:{0}, expected:{1}")
    @CsvSource({
        "BAD_REQUEST, true",
        "ACCEPTED, false"
    })
    @DisplayName("Test isValid for different status codes")
    void isValid(HttpStatus responseStatus, boolean expected) {
        boolean isValid = cardServerClientErrorMapper.isApplicable(new ErrorResponseDto(), responseStatus);

        if (expected){
            assertTrue(isValid);
        } else {
            assertFalse(isValid);
        }
    }

    @ParameterizedTest(name = "errorCode:{0}")
    @CsvSource({
        "request_invalid",
        "processing_error",
        "service_unavailable",
        "token_data_invalid",
        "token_type_invalid"
    })
    void map(String errorCode) {
        String genericCardErrorCode = "NPAY_CC_10201";

        when(checkoutErrorMappings.getCardErrorCode(errorCode)).thenReturn(genericCardErrorCode);

        Mono<ClientResponse> map = cardServerClientErrorMapper.processError(getErrorResponseDto(
            errorCode),HttpStatus.BAD_REQUEST);

        assertNotNull(map);
    }
}