package com.lbg.crosscuttinglib.security.util;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.lbg.crosscuttinglib.client.keycloak.client.KeycloakClient;
import com.lbg.crosscuttinglib.exception.ServiceException.BadInput;
import io.jsonwebtoken.JwtException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;

@ExtendWith(MockitoExtension.class)
class JwtVerificationUtilTest {

    @Mock
    private KeycloakClient keycloakClient;

    @InjectMocks
    private JwtVerificationUtil jwtVerificationUtil;

    @Test
    void expiredTokenInValidFormatThrowsException() {
        assertThatThrownBy(() ->
            jwtVerificationUtil.verifyToken(
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJGb3JnZXJvY2siLCJpc3MiOiJuZW9tcGF5IiwiZXhwIjoxNjM5NDk2NzQ2LCJpYXQiOjE2Mzk0OTYxNDYsImp0aSI6ImFhMDNkZDZhLTEzYjYtNGRlOS1iYWE0LWI2ZmJkMzllYTU2ZCJ9.oInL847eqnwqbvb6oli3IsmW67EJZpa8NXuOigt1pS8")
        ).isInstanceOf(JwtException.class);
    }

    @Test
    void expiredIdpTokenTest() {
        assertThatThrownBy(() ->
            jwtVerificationUtil.verifyIdpToken(
                "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJyd0Q5MGNtUmpPRTQxbTV6QldTOENQZ2RodmU5TWxiNm9VZG1USWRfN1hBIn0.eyJleHAiOjE2NDk5NDIzNTYsImlhdCI6MTY0OTk0MjA1NiwianRpIjoiNzcxMzU0NWUtNjQ1Mi00ZGE4LWI0MzItZTE1NjVhN2JmY2FiIiwiaXNzIjoiaHR0cHM6Ly9rZXljbG9hay5ibGQtbmVvbXBheS5mc3MubmVvbW9zLm9ubGluZS9hdXRoL3JlYWxtcy9jdXN0b21lciIsInN1YiI6Ijg4YTYxOTlkLTMzMGMtNGUzMS05ZmZjLTM4MDI2MTE4MmIwZSIsInR5cCI6IkJlYXJlciIsImF6cCI6ImFkbWluLWNsaSIsInNlc3Npb25fc3RhdGUiOiJiYjg4YjdiMi0xNTI1LTQ0NzgtYTAwMC1mNDc2NThhNThlNzYiLCJhY3IiOiIxIiwic2NvcGUiOiJwcm9maWxlIGVtYWlsIiwic2lkIjoiYmI4OGI3YjItMTUyNS00NDc4LWEwMDAtZjQ3NjU4YTU4ZTc2IiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiRk4tVEJDIExOLVRDQyIsInByZWZlcnJlZF91c2VybmFtZSI6IjkzMTIzNDUyMTIiLCJ1c2VyUm9sZSI6IkN1c3RvbWVyIiwiZ2l2ZW5fbmFtZSI6IkZOLVRCQyIsImZhbWlseV9uYW1lIjoiTE4tVENDIiwiZGV2aWNlSWQiOiIzNzQ1anMtc2RmLTEyMy05OTkxMTkxIn0.MJpoWW3DG8njvsYjPU4rKHioaqymZnBSItuY3B_d6RtB5QJQK-Kx7j8OqnGT1uD-m80dWXe3ez3WQU0eGcYtdBjfXDSt_k6l8-IE5njwhG9g_cNoFcLXazqoAq29-t_dKbO7bHAhdx-My79BvhM7RijswlsxufQBHkAB9Uejk0UBh6PKYq9JTZcjkQ-smJP5hpFqrk2TPIVEe5BZOnILxB1khYtHIdxb3t7aRBUxDw3TVe7_lIOd0iqKAIJXW625j7h0CN0wWr1YCF_Ju1VbHcrNAGTsqjUsD1SDQ77E80yhMuSkQgzKIfFEUiUGxm9SXhxysgD_7eAjrO22TpKitA","CUSTOMER")
        ).isInstanceOf(BadInput.class);
    }

    @Test
    @DisplayName("Convert JWT Epoch time to Local datetime of system")
    void convertJwtEpochToLocalDateTime(){
          long epoch = 1653321022;
        LocalDateTime localDateTimeFromJwtEpoch = jwtVerificationUtil.getLocalDateTimeFromJwtEpoch(epoch);
        assertEquals(2022,localDateTimeFromJwtEpoch.getYear());
        }
}
