package com.lbg.crosscuttinglib.exception.errormapper;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.lbg.crosscuttinglib.proxy.checkout.CheckoutErrorMappings;
import com.lbg.crosscuttinglib.proxy.checkout.errormapper.PaymentsCreatedErrorMapper;

import java.io.IOException;
import java.net.URL;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class PaymentsCreatedErrorMapperTest {

    @Mock
    private CheckoutErrorMappings checkoutErrorMappings;

    @InjectMocks
    private PaymentsCreatedErrorMapper paymentsCreatedErrorMapper;


    private ObjectNode objectNode;

    @BeforeEach
    void setUp() throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        URL url = new URL("file:src/test/resources/payments-created-response-test.JSON");
        objectNode = (ObjectNode) mapper.readTree(url);
    }

    @AfterEach
    void tearDown() {
    }

    @ParameterizedTest(name = "responseStatus:{0}, approved:{1}")
    @CsvSource({
        "BAD_REQUEST,false, false",
        "CREATED,false, true",
        "CREATED,true, false"
    })
    @DisplayName("Test isValid for different status codes and approved values")
    void isValid(HttpStatus responseStatus,boolean approved, boolean expected) {
        objectNode.put("approved",approved);

        boolean isValid = paymentsCreatedErrorMapper.isApplicable(objectNode, responseStatus);

        if (expected){
            assertTrue(isValid);
        } else {
            assertFalse(isValid);
        }
    }

    @ParameterizedTest(name = "responseStatus:{0}, expected:{1}")
    @CsvSource({
        "CREATED, 20005,NPAY_PYMT_10201",
        "CREATED, 20012,NPAY_PYMT_10202",
        "CREATED, 20014,NPAY_PYMT_10203",
        "CREATED, 20051,NPAY_PYMT_10204",
        "CREATED, 20087,NPAY_PYMT_10205",
        "CREATED, 20062,NPAY_PYMT_10206",
        "CREATED, 20063,NPAY_PYMT_10207",
        "CREATED, 20068,NPAY_PYMT_10208",
        "CREATED, 20150,NPAY_PYMT_10209",
        "CREATED, 20153,NPAY_PYMT_10210",
        "CREATED, 20154,NPAY_PYMT_10211",
        "CREATED, 30033,NPAY_PYMT_10212",
        "CREATED, 40101,NPAY_PYMT_10213",
        "CREATED, 40108,NPAY_PYMT_10214",
        "CREATED, 200R1,NPAY_PYMT_10215",
        "CREATED, 200R3,NPAY_PYMT_10216",
    })
    @DisplayName("Test map for different response codes")
    void map(HttpStatus responseStatus,String responseCode, String neomCode) {
        objectNode.put("response_code",responseCode);

        String genericPaymentErrorCode = "NPAY_PYMT_10137";
        when(checkoutErrorMappings.getPaymentErrorCode(responseCode)).thenReturn(neomCode);

        Mono<ClientResponse> map = paymentsCreatedErrorMapper.processError(objectNode, responseStatus);

        assertNotNull(map);
    }
}