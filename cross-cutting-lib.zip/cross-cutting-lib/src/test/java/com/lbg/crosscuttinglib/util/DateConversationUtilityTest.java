package com.lbg.crosscuttinglib.util;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DateConversationUtilityTest {

    @Test
    void localDateTimeToEpochMilliSeconds() {
        long expected = 1648632039;
        long epochMilliSeconds = DateConversationUtility.localDateTimeToEpochMilliSeconds(LocalDateTime.of(2022, 3, 30, 9, 20, 39));
        assertEquals(expected, epochMilliSeconds);
    }

    @Test
    void epochMilliSecondsToLocalDateTime() {
        //Epoch point of time is Wednesday, March 30, 2022 9:20:39 AM
        long epochMilliSeconds = 1648632039;
        LocalDateTime localDateTime = DateConversationUtility.epochMilliSecondsToLocalDateTime(epochMilliSeconds);
        assertEquals(2022, localDateTime.getYear());
        assertEquals(3, localDateTime.getMonth().getValue());
        assertEquals(30, localDateTime.getDayOfMonth());
        assertEquals(9, localDateTime.getHour());
        assertEquals(20, localDateTime.getMinute());
        assertEquals(39, localDateTime.getSecond());
    }
}