package com.lbg.crosscuttinglib.idempotency;

import com.lbg.crosscuttinglib.util.YmlPropertySourceFactory;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.validation.annotation.Validated;

@Configuration
@EnableRedisRepositories
@PropertySource(value = "classpath:service-config.yml", factory = YmlPropertySourceFactory.class)
@ConfigurationProperties(prefix = "idempotency")
@Validated
@Getter
@Setter
class IdempotencyConfig {

    private List<String> requestsPattern = new ArrayList<>();

}
