package com.lbg.crosscuttinglib.client.keycloak.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.ArrayList;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class KeyDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String kid;
    private String kty;
    private String alg;
    private String use;
    private String n;
    private String e;
    private ArrayList<String> x5c;
    private String x5t;
    @JsonProperty("x5t#S256")
    private String x5tS256;
}
