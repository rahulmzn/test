package com.lbg.crosscuttinglib.proxy.checkout;

import com.lbg.crosscuttinglib.exception.ServiceException;
import com.lbg.crosscuttinglib.proxy.ClientErrorFactory;
import com.lbg.crosscuttinglib.proxy.GenericErrorProcessor;
import com.lbg.crosscuttinglib.exception.Error;
import com.lbg.crosscuttinglib.exception.ErrorResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Flogger
@RequiredArgsConstructor
@Component
public class CheckoutClientErrorProcessor implements GenericErrorProcessor {

    private final ClientErrorFactory clientErrorMappings;

    private final static String MESSAGE= "Something went wrong in Checkout";

    @Value("${services.checkout.return-error-in-response:true}")
    private boolean showCheckoutErrorMessage;


    @Override
    public boolean isApplicable(List<Error> response, HttpStatus httpStatus) {
        return httpStatus.is4xxClientError() || httpStatus.is5xxServerError();
    }

    @Override
    public Mono<ClientResponse> processError(List<Error> response, HttpStatus httpStatus)  {
        String errorCodes = String.join(",", response.stream().map(error -> clientErrorMappings.getCheckoutServiceErrorMappingByErrorCode(error.getReasonCode())).collect(Collectors.toSet()));
        if(Objects.nonNull(response.get(0)) && errorCodes.equals(ClientErrorFactory.CHECKOUT_DEFAULT_ERROR_CODE)){
            ErrorResponse errorResponse = new ErrorResponse();
            Error error  = showCheckoutErrorMessage ? new Error(errorCodes, MESSAGE.concat(" - ").concat(response.get(0).getMessage())) : new Error(errorCodes, MESSAGE);
            errorResponse.addError(error);
            return Mono.error(new ServiceException.WebClientError(errorResponse,httpStatus));
        }
        return Mono.error(new ServiceException.WebClientError(errorCodes, httpStatus));
    }

}
