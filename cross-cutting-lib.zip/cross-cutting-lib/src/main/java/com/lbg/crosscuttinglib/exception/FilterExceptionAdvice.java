package com.lbg.crosscuttinglib.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Set;

import static java.lang.String.format;

/**
 * Exception Handling For Filters.
 */
@Component
@RequiredArgsConstructor
@Flogger
public class FilterExceptionAdvice {

    private final ObjectMapper objectMapper;

    /**
     * Custom error handler to process exception by filter
     */
    public void handleAccessDeniedException(HttpServletResponse response, String txnId, String errorCode, String errorMessage) throws IOException {
        log.atSevere().log(format("handleAccessDeniedException processing filter exception code: %s and message: %s", errorCode, errorMessage));
        ErrorResponse errorResponse = new ErrorResponse(txnId,Set.of(new Error(errorCode,errorMessage)));
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        try {
            response.getWriter().write(objectMapper.writeValueAsString(errorResponse));
        } catch (IOException e) {
            log.atSevere().log(format("handleAccessDeniedException error deserialization failed: %s", e.getMessage()));
            throw  e;
        }
    }

}
