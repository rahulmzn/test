package com.lbg.crosscuttinglib.proxy.comviva;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.crosscuttinglib.client.comviva.dto.ErrorResponseDto;
import com.lbg.crosscuttinglib.exception.ServiceException;
import com.lbg.crosscuttinglib.proxy.ClientErrorFactory;
import com.lbg.crosscuttinglib.proxy.ErrorResponseDeserializer;
import com.lbg.crosscuttinglib.proxy.ParsedClientResponse;
import com.lbg.crosscuttinglib.exception.Error;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@RequiredArgsConstructor
@Component
@Flogger
public class ComvivaResponseDeserializer implements ErrorResponseDeserializer {

    private final ObjectMapper objectMapper;

    @Override
    public Mono<List<Error>> getErrorCodes(ClientResponse response) {
         return  response.bodyToMono(String.class).map(errorBody -> {
            var errorResponse = new ErrorResponseDto();
            try {
                log.atSevere().log("Comviva Web Client Error Body Received: %s", errorBody);
                errorResponse = objectMapper.readValue(errorBody, ErrorResponseDto.class);
                if(CollectionUtils.isEmpty(errorResponse.getErrors())){
                    return List.of(new Error(errorResponse.getStatus(),errorResponse.getError()+"-"+errorResponse.getMessage()));
                }else{
                    return errorResponse.getErrors().stream().map(errorDto -> new Error(errorDto.getCode(),errorDto.getMessage())).collect(Collectors.toList());
                }
            } catch (JsonProcessingException e) {
                throw new ServiceException.ServerError("Failed to deserialize Comviva Client Response: " + e.getMessage());
            }catch (NullPointerException e){
                return List.of(new Error(ClientErrorFactory.COMVIVA_DEFAULT_ERROR_CODE,"Unexpected null value received error response"));
            }
        });

    }

    @Override
    public Mono<ParsedClientResponse> deserializeSuccessBody(ClientResponse response) {
        return response.bodyToMono(String.class).defaultIfEmpty("{}").map(body -> {
            try {
                return new ParsedClientResponse(body, objectMapper.readTree(body));
            } catch (JsonProcessingException e) {
                throw new ServiceException.ServerError("Failed to deserialize Comviva Client Response: " + e.getMessage());
            }
        });
    }
}
