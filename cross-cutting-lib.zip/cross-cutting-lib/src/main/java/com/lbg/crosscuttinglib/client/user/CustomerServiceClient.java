package com.lbg.crosscuttinglib.client.user;

import com.lbg.crosscuttinglib.client.user.dto.CustomerDto;
import com.lbg.crosscuttinglib.client.user.dto.KsaCitizenDto;
import com.lbg.crosscuttinglib.client.user.dto.WalletProviderTokenDto;
import com.lbg.crosscuttinglib.client.user.dto.ExpatCitizenDto;
import com.lbg.crosscuttinglib.exception.ServiceException.NoData;
import com.lbg.crosscuttinglib.exception.ServiceException.ServerError;
import com.lbg.crosscuttinglib.proxy.WebRequestSender;
import com.lbg.crosscuttinglib.util.HeaderUtil;
import java.util.HashMap;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@RequiredArgsConstructor
public class CustomerServiceClient {

    private static final String CUSTOMER_V2_0_GET_TOKEN = "/customers/v2.0/token/{mobileNo}";
    private static final String CUSTOMER_V3_0_GET_CUSTOMER = "/customers/v3.0/customer/{mobileNo}";
    private static final String CUSTOMER_V1_0_GET_KSA_CITIZEN = "/customers/v1.0/citizen/ksa";
    private static final String CUSTOMER_V1_0_GET_EXPAT_CITIZEN = "/customers/v1.0/citizen/expat";
    private final WebRequestSender webRequestSender;

    private static final String MISSING_URL_ERROR = "Customer service address not configured";

    @Value("${services.customer.service-address:}")
    private String customerServiceAddress;

    public WalletProviderTokenDto getWalletProviderToken(String mobileNo) {

        if (!StringUtils.hasText(customerServiceAddress)) {
            throw new ServerError(MISSING_URL_ERROR);
        }

        ParameterizedTypeReference<WalletProviderTokenDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        var pathParams = new HashMap<String, String>();
        pathParams.put("mobileNo", mobileNo);

        var getTokenUri = UriComponentsBuilder
            .fromHttpUrl(customerServiceAddress + CUSTOMER_V2_0_GET_TOKEN)
            .buildAndExpand(pathParams)
            .toUri();
        var httpHeaders = HeaderUtil.getNeomHttpHeaders();

        WalletProviderTokenDto tokenDto = webRequestSender.sendGetRequest(getTokenUri, httpHeaders,
            parameterizedTypeReference);
        if (null == tokenDto || !StringUtils.hasText(tokenDto.getToken())) {
            throw new NoData("Failed to fetch Wallet Provider Auth Token for Customer Mobile No: " + mobileNo);
        }
        return tokenDto;
    }

    public CustomerDto getCustomerByMobileNumber(String mobileNo) {

        if (!StringUtils.hasText(customerServiceAddress)) {
            throw new ServerError(MISSING_URL_ERROR);
        }

        ParameterizedTypeReference<CustomerDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        var pathParams = new HashMap<String, String>();
        pathParams.put("mobileNo", mobileNo);

        var uri = UriComponentsBuilder
            .fromHttpUrl(customerServiceAddress + CUSTOMER_V3_0_GET_CUSTOMER)
            .buildAndExpand(pathParams)
            .toUri();
        var httpHeaders = HeaderUtil.getNeomHttpHeaders();

        CustomerDto customerDto = webRequestSender.sendGetRequest(uri, httpHeaders,
            parameterizedTypeReference);
        if (null == customerDto || !StringUtils.hasText(customerDto.getCustomerId())) {
            throw new NoData("Failed to fetch Customer by Mobile No: " + mobileNo);
        }
        return customerDto;
    }

    public KsaCitizenDto getKsaCitizen(String iqamaId, String birthDate) {

        if (!StringUtils.hasText(customerServiceAddress)) {
            throw new ServerError(MISSING_URL_ERROR);
        }

        ParameterizedTypeReference<KsaCitizenDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };

        var uri = UriComponentsBuilder
            .fromHttpUrl(customerServiceAddress + CUSTOMER_V1_0_GET_KSA_CITIZEN)
            .queryParam("iqamaId", iqamaId)
            .queryParam("birthDate", birthDate)
            .build()
            .toUri();
        var httpHeaders = HeaderUtil.getNeomHttpHeaders();

        return webRequestSender.sendGetRequest(uri, httpHeaders, parameterizedTypeReference);
    }

    public ExpatCitizenDto getExpatCitizen(String iqamaId, String birthDate) {

        if (!StringUtils.hasText(customerServiceAddress)) {
            throw new ServerError(MISSING_URL_ERROR);
        }

        ParameterizedTypeReference<ExpatCitizenDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };

        var uri = UriComponentsBuilder
            .fromHttpUrl(customerServiceAddress + CUSTOMER_V1_0_GET_EXPAT_CITIZEN)
            .queryParam("iqamaId", iqamaId)
            .queryParam("birthDate", birthDate)
            .build()
            .toUri();
        var httpHeaders = HeaderUtil.getNeomHttpHeaders();

        return webRequestSender.sendGetRequest(uri, httpHeaders, parameterizedTypeReference);
    }
}
