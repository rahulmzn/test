package com.lbg.crosscuttinglib.proxy.checkout.errormapper;

import com.lbg.crosscuttinglib.proxy.ErrorProcessor;
import com.lbg.crosscuttinglib.client.checkout.dto.ErrorResponseDto;
import org.springframework.web.reactive.function.client.ClientResponse;

/**
 * Error Mapper for token and instruments endpoint for Checkout
 */
@Deprecated
public interface CheckoutCardErrorMapper extends ErrorProcessor<ErrorResponseDto, ClientResponse> {

}
