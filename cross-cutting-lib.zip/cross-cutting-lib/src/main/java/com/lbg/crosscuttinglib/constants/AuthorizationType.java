package com.lbg.crosscuttinglib.constants;

public enum AuthorizationType {
    PASSWORD,
    SMS_OTP,
    EMAIL_OTP
}
