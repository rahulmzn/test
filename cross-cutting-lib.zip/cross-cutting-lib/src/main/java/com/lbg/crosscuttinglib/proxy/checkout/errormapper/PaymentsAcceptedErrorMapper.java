package com.lbg.crosscuttinglib.proxy.checkout.errormapper;

import com.fasterxml.jackson.databind.JsonNode;
import com.lbg.crosscuttinglib.proxy.checkout.CheckoutErrorMappings;
import com.lbg.crosscuttinglib.exception.ServiceException.WebClientError;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@Flogger
@RequiredArgsConstructor
@Component
@Deprecated
public class PaymentsAcceptedErrorMapper implements CheckoutPaymentsSuccessErrorMapper {

    public static final String PENDING = "Pending";
    private final CheckoutErrorMappings checkoutErrorMappings;

    @Override
    public boolean isApplicable(JsonNode response, HttpStatus httpStatus) {
        return httpStatus == HttpStatus.ACCEPTED &&
            !PENDING.equalsIgnoreCase(response.get(STATUS).asText());
    }

    @Override
    public Mono<ClientResponse> processError(JsonNode response, HttpStatus httpStatus) {
        log.atSevere().log("Checkout Error: Status %s, Response: %s", httpStatus, response);
        return Mono.error(new WebClientError(checkoutErrorMappings.getGenericPaymentErrorCode(), httpStatus));
    }
}
