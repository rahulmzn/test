package com.lbg.crosscuttinglib.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum KeycloakConstant {
    AUTHORISATION("Authorisation"),
    USER("user"),
    USERNAME("username"),
    ADMIN("admin"),
    PIN("password"),
    CLIENT_ID("client_id"),
    CLIENT_SECRET("client_secret"),
    GRANT_TYPE("grant_type");

    private final String value;
}