package com.lbg.crosscuttinglib.model.stepup.constants;

public enum StepUpAuthorizationStatus {
    INITIATED,
    VERIFIED,
    COMPLETED
}
