package com.lbg.crosscuttinglib.client.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MerchantDto {

    private String merchantId;
    private char[] mobileNumber;
}
