package com.lbg.crosscuttinglib.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.cache.RedisCacheManagerBuilderCustomizer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;

import java.time.Duration;

@Configuration
@EnableCaching
public class RedisCacheConfig {

    @Value("${caching.ttl-minutes.keycloak:300}")
    private Integer ttlMinutesKeycloak;

    @Value("${caching.ttl-minutes.loggedIn-user:10}")
    private Integer ttlMinutesLoginDevice;


    @Bean
    public RedisCacheManagerBuilderCustomizer redisCacheManagerBuilderCustomizerKeycloakCerts() {
        return builder -> builder
            .withCacheConfiguration("keycloakCertsCache",
                RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofMinutes(ttlMinutesKeycloak)));
    }

    @Bean
    public RedisCacheManagerBuilderCustomizer redisCacheManagerBuilderCustomizerMultipleLogin() {
        return builder -> builder
                .withCacheConfiguration("loggedInUserCacheWithDeviceId",
                        RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofMinutes(ttlMinutesLoginDevice)));
    }
}
