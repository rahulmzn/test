package com.lbg.crosscuttinglib.logging;

import com.lbg.crosscuttinglib.util.YmlPropertySourceFactory;

import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.validation.annotation.Validated;

@Configuration
@PropertySource(value = "classpath:crossCuttingConfig.yml", factory = YmlPropertySourceFactory.class)
@ConfigurationProperties(prefix = "logging")
@Validated
@Getter
@Setter
public class LoggingConfig {

    @NotBlank
    private String requestsPattern;

    private List<String> excludeProxyMethodsPattern = new ArrayList<>();

}
