package com.lbg.crosscuttinglib.security.util;

import com.lbg.crosscuttinglib.security.constants.JwtConstants;
import com.lbg.crosscuttinglib.constants.ApiHeader;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import org.springframework.web.util.WebUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class AuthUtil {

    public static LocalDateTime getCurrentDateTimeInUTC() {
        return LocalDateTime.now(ZoneOffset.UTC);
    }

    public static String retrieveJWTToken(String bearerToken) {
        String[] parts = bearerToken.split(JwtConstants.SPACE_AS_STRING.getValue());
        String token = bearerToken;
        if (parts.length == 2) {
            token = parts[1];
        }
        return token;
    }

    public static String getAccessTokenFromRequest(HttpServletRequest req) {
        String header = req.getHeader(ApiHeader.AUTHORIZATION.getHeaderName());
        if (header != null && header.startsWith(JwtConstants.AUTH_BEARER.getValue())) {
            return header.substring(7);
        }

        Cookie secureCookie = WebUtils.getCookie(req, JwtConstants.JWT_COOKIE_NAME.getValue());
        return secureCookie != null ? secureCookie.getValue() : null;
    }
}
