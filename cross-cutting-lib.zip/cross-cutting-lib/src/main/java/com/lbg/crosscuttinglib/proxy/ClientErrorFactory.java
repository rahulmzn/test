package com.lbg.crosscuttinglib.proxy;

import com.lbg.crosscuttinglib.exception.ServiceException;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;
import java.util.Objects;


/**
 * Provides Client error codes mapping for
 * <p>Neom Internal Microservice</p>
 * <p>Comviva Api's</p>
 * <p>Checkout Api's</p>
 * <p>Keycloak Api's</p>
 */
@Getter
@Setter
public class ClientErrorFactory {

    public static final String GENERIC_KEY = "UNKNOWN_ERRORS";
    public static final String COMVIVA_DEFAULT_ERROR_CODE = "NPAY_CMV_10500";
    public static final String CHECKOUT_DEFAULT_ERROR_CODE = "NPAY_CHK_10500";
    public static final String IDP_DEFAULT_ERROR_CODE = "NPAY_IDP_10500";

    private Map<String, String> default_error;
    private Map<String, String> comviva;
    private Map<String, String> checkout;
    private Map<String, String> keycloak;

    public String getGenericErrorCode() {
        if(Objects.isNull(default_error)){
            throw new ServiceException.ServerError("Can not default API error code in clients-error-mapping.json mapping file, Please add default error code, ref. {\"default_error\": {\"UNKNOWN_ERRORS\": \"MS DEFAULT ERROR CODE\"} ");
        }
        return default_error.getOrDefault(GENERIC_KEY, "NEOM_INTERAL_SERVICE_ERROR");
    }


    /**
     *  Returns NEOM Internal Microservice services client error code mapping from clients-error-mapping.json attached to specific microservice
     *  By default it will return respective microservice default code configured in mapping file.
     * @param errorCode : Client error code which need to be converted with Neom internal error code
     * @return  : NEOM internal error code against given client error code
     */
    public String getInternalServiceErrorMappingByErrorCode(String errorCode) {return default_error.getOrDefault(errorCode, getGenericErrorCode());}

    /**
     *  Returns comviva client error code mapping from clients-error-mapping.json attached to specific microservice
     *  By default it will return respective microservice default code configured in mapping file.
     * @param errorCode : Client error code which need to be converted with Neom internal error code
     * @return  : NEOM internal error code against given client error code
     */
    public String getComvivaServiceErrorMappingByErrorCode(String errorCode) {
        if(Objects.isNull(comviva)){
            comviva = Map.of();
        }
        return comviva.getOrDefault(errorCode, COMVIVA_DEFAULT_ERROR_CODE);
    }


    /**
     *  Returns Checkout client error code mapping from clients-error-mapping.json attached to specific microservice
     *  By default it will return respective microservice default code configured in mapping file.
     * @param errorCode : Client error code which need to be converted with Neom internal error code
     * @return  : NEOM internal error code against given client error code
     */
    public String getCheckoutServiceErrorMappingByErrorCode(String errorCode) {
        if(Objects.isNull(checkout)){
            checkout = Map.of();
        }
        return checkout.getOrDefault(errorCode, CHECKOUT_DEFAULT_ERROR_CODE);
    }


    /**
     *  Returns Keycloak client error code mapping from clients-error-mapping.json attached to specific microservice
     *  By default it will return respective microservice default code configured in mapping file.
     * @param errorCode : Client error code which need to be converted with Neom internal error code
     * @return  : NEOM internal error code against given client error code
     */
    public String getKeycloakServiceErrorMappingByErrorCode(String errorCode) {
        if(Objects.isNull(keycloak)){
            keycloak = Map.of();
        }
        return keycloak.getOrDefault(errorCode, IDP_DEFAULT_ERROR_CODE);
    }

}
