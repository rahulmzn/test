package com.lbg.crosscuttinglib.security.mapper;

import com.lbg.crosscuttinglib.security.model.CachedUser;
import com.lbg.crosscuttinglib.security.model.KeycloakSystemUser;
import com.lbg.crosscuttinglib.security.model.KeycloakUser;
import com.lbg.crosscuttinglib.security.model.User;
import com.lbg.crosscuttinglib.constants.UserType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface KeycloakUserMapper {

    @Mapping(target = "firstName", source = "givenName")
    @Mapping(target = "lastName", source = "familyName")
    @Mapping(target = "mobileNo", source = "preferredUsername")
    @Mapping(target = "userType", source = "userRole", qualifiedByName = "mapUserRole")
    @Mapping(target = "idpUserId", source = "idpUserId")
    @Mapping(target = "deviceId", source = "deviceId")
    @Mapping(target = "tokenIssuedAt", source = "iat")
    User toNeomUser(KeycloakUser request);

    @Named("mapUserRole")
    default UserType mapUserRole(String userRole) {
        return UserType.find(userRole);
    }

    @Mapping(target = "firstName", constant = "System")
    @Mapping(target = "lastName", constant = "User")
    @Mapping(target = "mobileNo", constant = "0")
    @Mapping(target = "userType", expression = "java(systemUserRole())")
    @Mapping(target = "idpUserId", source = "idpUserId")
    @Mapping(target = "tokenIssuedAt", source = "iat")
    User toNeomSystemUser(KeycloakSystemUser request);

    default UserType systemUserRole() {
        return UserType.find("system");
    }

    @Mapping(target = "tokenIssuedAt", source = "iat")
    @Mapping(target = "tokenExpiryAt", source = "exp")
    @Mapping(target = "sessionId", source = "sid")
    CachedUser toUserDetail(KeycloakUser keycloakUser);
}
