package com.lbg.crosscuttinglib.proxy;


import lombok.extern.flogger.Flogger;
import org.springframework.context.annotation.Configuration;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

@Configuration
@Flogger
public class HttpClientConfig {
    public HttpClient buildHttpClient(Integer maxConnections, boolean keepAlive){
        HttpClient nettyHttpClient = null;
        try {
            ConnectionProvider connProvider = ConnectionProvider
                .builder("checkout-webclient-conn-pool")
                .maxConnections(maxConnections)
                /*.maxIdleTime()
                .maxLifeTime()
                .pendingAcquireMaxCount()*/
                .build();

            log.atInfo().log("ConnectionProvider instantiated with max connections : {} and ", maxConnections);

            nettyHttpClient = HttpClient
                .create(connProvider)
                .keepAlive(keepAlive)
                .wiretap(Boolean.TRUE);


        } catch (Exception ex) {
            log.atSevere().log("Unable to instantiate Netty based HttpClient. Error Message : {}, Error Cause : {}, Stracktrace : {}",
                ex.getMessage(), ex.getCause(), ex.getStackTrace());
            throw ex;
        }
        return nettyHttpClient;

    }

}
