package com.lbg.crosscuttinglib.client.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerDto {

    private String customerId;
    private char[] mobileNumber;
}
