package com.lbg.crosscuttinglib.proxy;

import com.lbg.crosscuttinglib.exception.Error;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
public interface ErrorResponseDeserializer {
    Mono<List<Error>> getErrorCodes(ClientResponse response);
    Mono<ParsedClientResponse> deserializeSuccessBody(ClientResponse response);
}
