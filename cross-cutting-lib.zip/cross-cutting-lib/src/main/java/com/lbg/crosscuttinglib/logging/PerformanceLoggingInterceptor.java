package com.lbg.crosscuttinglib.logging;

import java.util.Arrays;
import lombok.extern.flogger.Flogger;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.springframework.aop.interceptor.AbstractMonitoringInterceptor;
import org.springframework.util.StopWatch;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

/**
 * Intercepts each request for measuring the performance
 */
@Flogger
public class PerformanceLoggingInterceptor extends AbstractMonitoringInterceptor {

    public PerformanceLoggingInterceptor(boolean useDynamicLogger) {
        setUseDynamicLogger(useDynamicLogger);
    }

    @Override
    protected Object invokeUnderTrace(MethodInvocation methodInvocation, Log logger)
        throws Throwable {
        String methodName = createInvocationTraceName(methodInvocation);
        String requestUrl = this.getRequestUrlInfo(methodName, methodInvocation);
        String targetUrl = "";
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        try {
            return methodInvocation.proceed();
        } finally {
            stopWatch.stop();

            if (methodName.contains(".WebClientService.")) {
                var targetUrlOptional = Arrays.stream(methodInvocation.getArguments()).findFirst();
                if (targetUrlOptional.isPresent()) {
                    targetUrl = targetUrlOptional.get().toString();
                }
            }
            log.atInfo()
                .log("[PERFTMSTMP|%s|%s|%s|%d]", requestUrl, methodName, targetUrl, stopWatch.getTotalTimeMillis());
        }
    }

    @Override
    protected boolean isInterceptorEnabled(MethodInvocation invocation, Log logger) {
        return true;
    }

    private String getRequestUrlInfo(String methodName, MethodInvocation methodInvocation) {
        if(methodName.contains(".WebClientService.") && methodInvocation.getArguments().length > 0) {
            Object[] arguments = methodInvocation.getArguments();
            Object value = arguments[arguments.length-1];
            if((value instanceof Boolean) && ((Boolean) value).booleanValue()) {
                return "non_http_url";
            } else {
                return ServletUriComponentsBuilder.fromCurrentRequestUri().toUriString();
            }
        } else {
            return ServletUriComponentsBuilder.fromCurrentRequestUri().toUriString();
        }

    }
}
