package com.lbg.crosscuttinglib.proxy;

import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

public interface ErrorMapper<T, R> {

    boolean isApplicable(T response, HttpStatus httpStatus);

    Mono<R> map(T response, HttpStatus httpStatus);

}
