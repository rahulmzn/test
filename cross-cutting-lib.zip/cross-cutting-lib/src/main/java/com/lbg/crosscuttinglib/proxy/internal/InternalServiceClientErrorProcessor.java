package com.lbg.crosscuttinglib.proxy.internal;

import com.lbg.crosscuttinglib.exception.ServiceException;
import com.lbg.crosscuttinglib.proxy.GenericErrorProcessor;
import com.lbg.crosscuttinglib.exception.Error;
import com.lbg.crosscuttinglib.exception.ErrorResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.util.HashSet;
import java.util.List;

@Flogger
@RequiredArgsConstructor
@Component
public class InternalServiceClientErrorProcessor implements GenericErrorProcessor {

    @Override
    public boolean isApplicable(List<Error> response, HttpStatus httpStatus) {
        return httpStatus.is4xxClientError() || httpStatus.is5xxServerError();
    }

    @Override
    public Mono<ClientResponse> processError(List<Error> response, HttpStatus httpStatus)  {
        ErrorResponse errorResponse = new ErrorResponse(new HashSet<>(response));
        return Mono.error(new ServiceException.WebClientError(errorResponse, httpStatus));
    }

}
