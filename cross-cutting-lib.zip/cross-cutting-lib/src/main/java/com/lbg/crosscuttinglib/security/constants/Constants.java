package com.lbg.crosscuttinglib.security.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum Constants {
    INFO_MESSAGE_ONE("Keycloak user details %s"),
    INFO_MESSAGE_TWO("Processing Identity token with keycloak"),
    INVALID_ACCESS_TOKEN("Invalid Access Token"),
    INVALID_LOGIN_DEVICE("NPAY_IDAUTH_10124");

    private String value;

}
