package com.lbg.crosscuttinglib.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.web.reactive.function.client.ClientResponse;

/**
 * Error Mapper for payments endpoint for Checkout
 */
public interface BusinessFailureRuleProcessor extends ErrorProcessor<JsonNode, ClientResponse> {

}
