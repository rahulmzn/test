package com.lbg.crosscuttinglib.model.stepup;

import com.lbg.crosscuttinglib.constants.AuthorizationType;
import com.lbg.crosscuttinglib.constants.NeomChannelType;
import com.lbg.crosscuttinglib.constants.UserType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.lbg.crosscuttinglib.model.stepup.constants.StepUpAuthorizationStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StepUpAuthTransaction {

    @NotBlank
    @NotNull
    private String transactionId;
    @NotNull
    private AuthorizationType authorizationType;
    @NotNull
    private StepUpAuthorizationStatus authorizationStatus;
    @NotNull
    private String serviceType;
    @NotNull
    private String serviceReference;
    @NotNull
    private NeomChannelType channel;
    @NotNull
    @NotBlank
    private String userId;
    @NotNull
    private UserType userType;

}
