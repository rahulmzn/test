package com.lbg.crosscuttinglib.proxy.checkout.errormapper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.lbg.crosscuttinglib.proxy.checkout.CheckoutErrorMappings;
import com.lbg.crosscuttinglib.exception.ServiceException.WebClientError;

import java.util.ArrayList;
import java.util.List;

import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@Flogger
@RequiredArgsConstructor
@Component
@Deprecated
public class PaymentsOkErrorMapper implements CheckoutPaymentsSuccessErrorMapper {

    private final CheckoutErrorMappings checkoutErrorMappings;

    @Override
    public boolean isApplicable(JsonNode response, HttpStatus httpStatus) {
        var isApproved = response.get(APPROVED);
        boolean obj = null != isApproved && isApproved.asBoolean();
        return httpStatus == HttpStatus.OK && Boolean.FALSE.equals(obj);
    }

    @Override
    public Mono<ClientResponse> processError(JsonNode response, HttpStatus httpStatus) {
        log.atSevere().log("Checkout Error: Status %s, Response: %s", httpStatus, response);
        return Mono.error(new WebClientError(String.join(",", extractErrors(response)), httpStatus));
    }

    private List<String> extractErrors(JsonNode jsonNode) {
        var errors = new ArrayList<String>();

        ArrayNode actions = (ArrayNode) jsonNode.get(ACTIONS);
        if (null != actions) {
            var itr = actions.elements();
            while (itr.hasNext()) {
                errors.add(getNeomErrorCode(itr.next()));
            }
        }
        return errors;
    }

    private String getNeomErrorCode(JsonNode jsonNode) {
        var responseCode = jsonNode.get(RESPONSE_CODE);
        return checkoutErrorMappings.getPaymentErrorCode(null != responseCode ? responseCode.asText() : "");
    }
}
