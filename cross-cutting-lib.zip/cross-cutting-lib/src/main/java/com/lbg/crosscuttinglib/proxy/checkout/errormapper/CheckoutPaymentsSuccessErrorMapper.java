package com.lbg.crosscuttinglib.proxy.checkout.errormapper;

import com.fasterxml.jackson.databind.JsonNode;
import com.lbg.crosscuttinglib.proxy.ErrorProcessor;
import org.springframework.web.reactive.function.client.ClientResponse;

/**
 * Error Mapper for payments endpoint for Checkout
 */
@Deprecated
public interface CheckoutPaymentsSuccessErrorMapper extends ErrorProcessor<JsonNode, ClientResponse> {

    String APPROVED = "approved";
    String RESPONSE_SUMMARY = "response_summary";
    String RESPONSE_CODE = "response_code";
    String ACTIONS = "actions";
    String STATUS = "status";
}
