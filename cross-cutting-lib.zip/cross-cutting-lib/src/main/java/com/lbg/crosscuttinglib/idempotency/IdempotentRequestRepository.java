package com.lbg.crosscuttinglib.idempotency;

import org.springframework.data.repository.CrudRepository;

interface IdempotentRequestRepository extends CrudRepository<IdempotentRequest, String> {

}
