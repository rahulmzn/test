package com.lbg.crosscuttinglib.security.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class KeycloakSystemUser {
    @JsonProperty("email_verified")
    private boolean emailVerified;
    private String clientId;
    @JsonProperty("preferred_username")
    private String preferredUsername;
    private String idpUserId;
    private long iat;
}
