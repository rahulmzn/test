package com.lbg.crosscuttinglib.idempotency;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Objects;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.TimeToLive;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;

@RedisHash(value = "idempotentRequestCache")
@NoArgsConstructor
@Getter
@Setter
class IdempotentRequest implements Serializable {

    @Id
    private String id;

    @TimeToLive
    private Long cacheTtl;

    private String requestMethod;
    private Map<String, String[]> requestParams;
    private String requestPath;
    private LocalDateTime createdAt;

    private int responseCode;
    private byte[] responseBody;
    private String responseContentType;
    private LocalDateTime updatedAt;
    private LocalDateTime lockedAt;
    private RequestStatus status;

    public IdempotentRequest(String id, String requestMethod, Map<String, String[]> requestParams,
        String requestPath, Long cacheTtl) {
        this.id = id;
        this.requestMethod = requestMethod;
        this.requestParams = requestParams;
        this.requestPath = requestPath;

        this.status = RequestStatus.INITIATED;
        this.createdAt = LocalDateTime.now();
        this.lockedAt = LocalDateTime.now();
        this.cacheTtl = cacheTtl;
    }

    public void setCompleted(int responseCode, String responseContentType) {
        this.responseCode = responseCode;

        if (StringUtils.hasText(responseContentType)) {
            this.responseContentType = responseContentType;
        } else {
            this.responseContentType = MediaType.APPLICATION_JSON_VALUE;
        }

        this.status = RequestStatus.COMPLETED;
        this.lockedAt = LocalDateTime.MAX;
        this.updatedAt = LocalDateTime.now();
    }

    public boolean isWorkInProgress() {
        return !hasCompleted() &&
            lockedAt.isBefore(LocalDateTime.now());
    }

    public boolean hasCompleted() {
        return status.equals(RequestStatus.COMPLETED);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        IdempotentRequest that = (IdempotentRequest) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
