package com.lbg.crosscuttinglib.proxy.comviva.errormapper;

import com.lbg.crosscuttinglib.proxy.comviva.ComvivaErrorMappings;
import com.lbg.crosscuttinglib.client.comviva.dto.ErrorResponseDto;
import com.lbg.crosscuttinglib.exception.ServiceException.WebClientError;

import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@Flogger
@RequiredArgsConstructor
@Component
@Deprecated
public class ComvivaPaymentClientErrorMapper implements ComvivaPaymentsErrorMapper {

    private final ComvivaErrorMappings comvivaErrorMappings;

    @Override
    public boolean isApplicable(ErrorResponseDto response, HttpStatus httpStatus) {

        return httpStatus.is4xxClientError() || httpStatus.is5xxServerError();
    }

    @Override
    public Mono<ClientResponse> processError(ErrorResponseDto response, HttpStatus httpStatus) {
        log.atSevere().log("Comviva Error: Status %s, Response: %s", httpStatus, response);

        var errors = response.getErrors().stream()
            .map(error -> getNeomErrorCode(error.getCode()))
            .collect(Collectors.joining(","));

        return Mono.error(new WebClientError(errors, httpStatus));
    }

    private String getNeomErrorCode(String code) {
        return comvivaErrorMappings.getPaymentErrorCode(code);
    }

}
