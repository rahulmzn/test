package com.lbg.crosscuttinglib.logging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.crosscuttinglib.exception.ServiceException;
import java.util.Arrays;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Flogger
@RequiredArgsConstructor
public class DiagnosticLoggingAdvice {

    private final ObjectMapper objectMapper;
    private final LoggingConfig loggingConfig;

    @Around(value = "execution(public * com.neom.fss.neompay..client..*Client*.*(..))")
    public Object logClientProxyLayerRequestResponseDetails(ProceedingJoinPoint joinPoint) throws Throwable {
        var className = joinPoint.getTarget().getClass().getSimpleName();
        var methodName = joinPoint.getSignature().getName();

        var excludedOperation = loggingConfig.getExcludeProxyMethodsPattern()
            .stream()
            .filter(methodName::matches)
            .findAny();

        if (excludedOperation.isPresent()) {
            return joinPoint.proceed();
        }

        var args = Arrays.stream(joinPoint.getArgs())
            .map(e -> {
                try {
                    if (null != e) {
                        return objectMapper.writeValueAsString(e);
                    }
                    return null;
                } catch (JsonProcessingException ex) {
                    throw new ServiceException.ServerError(ex.getMessage());
                }
            })
            .collect(Collectors.toList());
        log.atFine().log("Proxy invoked: %s:%s (%s)", className, methodName, String.join(", ", args));

        var result = joinPoint.proceed();

        log.atFine().log("Proxy returned: %s:%s (%s)", className, methodName,
            (null != result) ? objectMapper.writeValueAsString(result) : null);
        return result;
    }


    @Around(value = "execution(public * com.neom.fss.neompay..service..*ServiceImpl.*(..))")
    public Object logServiceLayerRequestResponseKeyInfo(ProceedingJoinPoint joinPoint) throws Throwable {
        var className = joinPoint.getTarget().getClass().getSimpleName();
        var methodName = joinPoint.getSignature().getName();

        var args = Arrays.stream(joinPoint.getArgs())
            .map(e -> {
                if (null != e) {
                    return e.toString();
                }
                return null;
            })
            .collect(Collectors.toList());
        log.atInfo().log("Operation invoked: %s:%s (%s)", className, methodName, String.join(", ", args));

        var result = joinPoint.proceed();

        log.atInfo().log("Operation returned: %s:%s (%s)", className, methodName,
            (null != result) ? objectMapper.writeValueAsString(result) : null);
        return result;
    }
}
