package com.lbg.crosscuttinglib.proxy.comviva.errormapper;

import com.lbg.crosscuttinglib.proxy.ErrorProcessor;
import com.lbg.crosscuttinglib.client.comviva.dto.ErrorResponseDto;
import org.springframework.web.reactive.function.client.ClientResponse;
@Deprecated
public interface ComvivaWalletErrorMapper extends ErrorProcessor<ErrorResponseDto, ClientResponse> {

}
