package com.lbg.crosscuttinglib.proxy.internal;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lbg.crosscuttinglib.proxy.ErrorResponseDeserializer;
import com.lbg.crosscuttinglib.proxy.ParsedClientResponse;
import com.lbg.crosscuttinglib.exception.Error;
import com.lbg.crosscuttinglib.exception.ErrorResponse;
import com.lbg.crosscuttinglib.exception.ServiceException.ServerError;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@RequiredArgsConstructor
@Component
@Flogger
public class InternalServiceResponseDeserializer implements ErrorResponseDeserializer {

    private final ObjectMapper objectMapper;

    @Override
    public Mono<List<Error>> getErrorCodes(ClientResponse response) {
        return response.bodyToMono(String.class).map(errorBody -> {
            var errorResponse = new ErrorResponse();
            try {
                log.atSevere().log("Internal Service Client Error Body Received: %s ", errorBody);
                errorResponse = objectMapper.readValue(errorBody, ErrorResponse.class);
                return new ArrayList<>(errorResponse.getErrors());
            } catch (JsonProcessingException e) {
                throw new ServerError("Failed to deserialize Internal Service Client Response: " + e.getMessage());
            }
        });

    }

    @Override
    public Mono<ParsedClientResponse> deserializeSuccessBody(ClientResponse response) {
        return response.bodyToMono(String.class).defaultIfEmpty("{}").map(body -> {
            try {
                return new ParsedClientResponse(body, objectMapper.readTree(body));
            } catch (JsonProcessingException e) {
                throw new ServerError("Failed to deserialize Internal Service  Client Response: " + e.getMessage());
            }
        });
    }
}
