package com.lbg.crosscuttinglib.proxy;

import com.lbg.crosscuttinglib.exception.Error;
import org.springframework.web.reactive.function.client.ClientResponse;

import java.util.List;

/**
 *  Error Processor to handle integration client error scenarios
 */
public interface GenericErrorProcessor extends ErrorProcessor<List<Error>, ClientResponse> {

}
