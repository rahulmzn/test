package com.lbg.crosscuttinglib.util;

import static com.lbg.crosscuttinglib.security.util.HeaderUtil.getRequestHeader;

import com.lbg.crosscuttinglib.constants.ApiHeader;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class HeaderUtil {

    public static final String SERVICE_NAME = "SERVICE_NAME";

    public static Map<String, String> getRequestHeaders(HttpServletRequest request) {
        var headers = new HashMap<String, String>();
        var headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = headerNames.nextElement().toLowerCase();
            String value = request.getHeader(key);
            headers.put(key, value);
        }
        return headers;
    }

    public static HttpHeaders getNeomHttpHeaders() {

        var headers = new HttpHeaders();
        getNeomHeaders().forEach(headers::add);
        return headers;
    }

    public static Map<String, String> getNeomHeaders() {
        var headers = new HashMap<String, String>();

        var bearerToken = getRequestHeader(ApiHeader.AUTHORIZATION.getHeaderName());
        headers.put(ApiHeader.AUTHORIZATION.getHeaderName(), bearerToken);
        headers.put(ApiHeader.CORRELATION_ID.getLcHeaderName(),
            MDC.getMDCAdapter().get(ApiHeader.CORRELATION_ID.name()));
        headers.put(ApiHeader.NEOM_CHANNEL.getLcHeaderName(), MDC.getMDCAdapter().get(ApiHeader.NEOM_CHANNEL.name()));

        var idempotencyId = MDC.getMDCAdapter().get(ApiHeader.IDEMPOTENCY_KEY.name());
        if (StringUtils.hasText(idempotencyId)) {
            headers.put(ApiHeader.IDEMPOTENCY_KEY.getLcHeaderName(), idempotencyId);
        }

        var aliasName = MDC.getMDCAdapter().get(ApiHeader.DEVICE_ALIAS.name());
        if (StringUtils.hasText(aliasName)) {
            headers.put(ApiHeader.DEVICE_ALIAS.getLcHeaderName(), aliasName);
        }

        var appName = MDC.getMDCAdapter().get(ApiHeader.APP_NAME.name());
        if (StringUtils.hasText(appName)) {
            headers.put(ApiHeader.APP_NAME.getLcHeaderName(), appName);
        }

        var appVersion = MDC.getMDCAdapter().get(ApiHeader.APP_VERSION.name());
        if (StringUtils.hasText(appVersion)) {
            headers.put(ApiHeader.APP_VERSION.getLcHeaderName(), appVersion);
        }

        var appPlatform = MDC.getMDCAdapter().get(ApiHeader.APP_PLATFORM.name());
        if (StringUtils.hasText(appPlatform)) {
            headers.put(ApiHeader.APP_PLATFORM.getLcHeaderName(), appPlatform);
        }

        var clientIp = MDC.getMDCAdapter().get(ApiHeader.CLIENT_IP.name());
        if (StringUtils.hasText(clientIp)) {
            headers.put(ApiHeader.CLIENT_IP.getLcHeaderName(), clientIp);
        }

        var userAgent = MDC.getMDCAdapter().get(ApiHeader.USER_AGENT.name());
        if (StringUtils.hasText(userAgent)) {
            headers.put(ApiHeader.USER_AGENT.getLcHeaderName(), userAgent);
        }

        return headers;
    }

    public static void mdcRequestHeaders(Map<String, String> headers) {

        var correlationId = headers.get(ApiHeader.CORRELATION_ID.getLcHeaderName());
        if (StringUtils.hasText(correlationId)) {
            MDC.getMDCAdapter().put(ApiHeader.CORRELATION_ID.name(), correlationId);
        } else {
            MDC.getMDCAdapter().put(ApiHeader.CORRELATION_ID.name(), UUID.randomUUID().toString());
        }

        var idempotencyId = headers.get(ApiHeader.IDEMPOTENCY_KEY.getLcHeaderName());
        if (StringUtils.hasText(idempotencyId)) {
            MDC.getMDCAdapter().put(ApiHeader.IDEMPOTENCY_KEY.name(), idempotencyId);
        }

        var aliasName = headers.get(ApiHeader.DEVICE_ALIAS.getLcHeaderName());
        if (StringUtils.hasText(aliasName)) {
            MDC.getMDCAdapter().put(ApiHeader.DEVICE_ALIAS.name(), aliasName);
        }

        var appName = headers.get(ApiHeader.APP_NAME.getLcHeaderName());
        if (StringUtils.hasText(appName)) {
            MDC.getMDCAdapter().put(ApiHeader.APP_NAME.name(), appName);
        }

        var appVersion = headers.get(ApiHeader.APP_VERSION.getLcHeaderName());
        if (StringUtils.hasText(appVersion)) {
            MDC.getMDCAdapter().put(ApiHeader.APP_VERSION.name(), appVersion);
        }

        var appPlatform = headers.get(ApiHeader.APP_PLATFORM.getLcHeaderName());
        if (StringUtils.hasText(appPlatform)) {
            MDC.getMDCAdapter().put(ApiHeader.APP_PLATFORM.name(), appPlatform);
        }

        var clientIp = headers.get(ApiHeader.CLIENT_IP.getLcHeaderName());
        if (StringUtils.hasText(clientIp)) {
            MDC.getMDCAdapter().put(ApiHeader.CLIENT_IP.name(), clientIp);
        }

        var userAgent = headers.get(ApiHeader.USER_AGENT.getLcHeaderName());
        if (StringUtils.hasText(userAgent)) {
            MDC.getMDCAdapter().put(ApiHeader.USER_AGENT.name(), userAgent);
        }

        var neomChannel = headers.get(ApiHeader.NEOM_CHANNEL.getLcHeaderName());
        if (StringUtils.hasText(neomChannel)) {
            MDC.getMDCAdapter().put(ApiHeader.NEOM_CHANNEL.name(), neomChannel);
        }

        var serviceName = headers.get(SERVICE_NAME);
        if (StringUtils.hasText(serviceName)) {
            MDC.getMDCAdapter().put(SERVICE_NAME, serviceName);
        }
    }

    public static HttpHeaders getApplicationJsonHeader() {
        var httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return httpHeaders;
    }

    public static String getAppNameFromRequestHeader(HttpServletRequest req) {
        return req.getHeader(ApiHeader.APP_NAME.getHeaderName());
    }


}
