package com.lbg.crosscuttinglib.idempotency;

public enum RequestStatus {

    INITIATED,
    COMPLETED
}
