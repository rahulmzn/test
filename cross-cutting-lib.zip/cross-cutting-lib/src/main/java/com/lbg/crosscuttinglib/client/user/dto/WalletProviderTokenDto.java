package com.lbg.crosscuttinglib.client.user.dto;

import lombok.Data;

@Data
public class WalletProviderTokenDto {

    private String mobileNo;

    private String token;

    private String expiresIn;

    private String refreshToken;
}
