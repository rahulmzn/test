package com.lbg.crosscuttinglib.security.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TokenVerificationResponse {

    private boolean validated;
    private String jwtTokenRequest;
    private User user;
}
