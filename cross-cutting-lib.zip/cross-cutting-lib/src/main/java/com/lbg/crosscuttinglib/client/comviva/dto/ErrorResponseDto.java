package com.lbg.crosscuttinglib.client.comviva.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class ErrorResponseDto {

    private String txnStatus;
    private String status;
    private String language;
    private String mfsTenantId;
    private String message;
    private List<ErrorDto> errors;
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime transactionTimeStamp;
    private String traceId;
    private String step;
    private String errorCode;
    private String error;
    private String errorUserMsg;
    private String transactionId;
    private String referenceId;
}
