package com.lbg.crosscuttinglib.util;

import com.lbg.crosscuttinglib.exception.ServiceException.BadInput;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Objects;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
@Component
public class PasscodeValidator {

    public static void validatePasscode(String passcode, String confirmPasscode, String dateOfBirth, String errorCode)
        throws ParseException {
        if (!passcode.equals(confirmPasscode)) {
            throw new BadInput(errorCode);
        }
        sequenceCheck(passcode, errorCode);
        repeatCheck(passcode, errorCode);
        if(Objects.nonNull(dateOfBirth)){
            birthDateCheck(passcode, dateOfBirth, errorCode);
        }
    }

    /**
     * Check if User Pin is in a Sequence like '123456'
     *
     * @param passcode
     */
    private static void sequenceCheck(String passcode, String errorCode) {
        boolean flag = false;
        Integer pinNumber = Integer.parseInt(passcode);
        int currDigit = pinNumber % 10;
        pinNumber = pinNumber / 10;

        while (pinNumber > 0) {
            if ((currDigit - 1) != (pinNumber % 10)) {
                flag = true;
                break;
            }
            currDigit = pinNumber % 10;
            pinNumber = pinNumber / 10;
        }

        if (!flag) {
            throw new BadInput(errorCode);
        }
    }

    /**
     * Check if User Pin has repeated values like '111111'
     *
     * @param passcode
     */
    private static void repeatCheck(String passcode, String errorCode) {
        boolean flag = false;
        Integer pinNumber = Integer.parseInt(passcode);
        int currDigit = pinNumber % 10;
        pinNumber = pinNumber / 10;

        while (pinNumber != 0) {
            if (currDigit != (pinNumber % 10)) {
                flag = true;
                break;
            }
            currDigit = pinNumber % 10;
            pinNumber = pinNumber / 10;
        }

        if (!flag) {
            throw new BadInput(errorCode);
        }

    }

    /**
     * Check if User Pin is same as that of DOB
     *
     * @param passcode
     * @param dateOfBirth
     * @throws ParseException
     */
    private static void birthDateCheck(String passcode, String dateOfBirth, String errorCode) throws ParseException {
        SimpleDateFormat conversionFormat = new SimpleDateFormat("ddMMyy");
        SimpleDateFormat receivedFormat = new SimpleDateFormat("yyyy-MM-dd");
        String convertedDobAsPin = conversionFormat.format(receivedFormat.parse(dateOfBirth));

        if (passcode.equals(convertedDobAsPin)) {
            throw new BadInput(errorCode);
        }
    }

}
