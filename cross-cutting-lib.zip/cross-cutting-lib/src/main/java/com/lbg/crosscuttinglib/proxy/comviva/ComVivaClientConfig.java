package com.lbg.crosscuttinglib.proxy.comviva;

import com.lbg.crosscuttinglib.config.UnauthorizedServicesConfig;
import com.lbg.crosscuttinglib.proxy.HttpClientConfig;
import com.lbg.crosscuttinglib.proxy.WebClientService;
import com.lbg.crosscuttinglib.proxy.WebRequestSender;
import com.lbg.crosscuttinglib.util.HeaderUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Configuration
@RequiredArgsConstructor
@Flogger
public class ComVivaClientConfig {

    private static final String ENVIRONMENT_NAME_HEADER = "x-neom-env";

    private final List<ComvivaClientErrorProcessor> comvivaClientErrorProcessors;
    private final ComvivaResponseDeserializer comvivaResponseDeserializer;

    private final HttpClientConfig httpClientConfig;
    private final UnauthorizedServicesConfig unauthorizedServicesConfig;

    private final List<String> skipHeaders = List.of("X-IDP-Token", "x-idp-token");

    @Value("${api.environment:BLD}")
    String environmentName;

    @Value("${services.comviva.webclient.max-connections:500}")
    Integer maxConnections;

    @Value("${services.comviva.webclient.keep-alive-connection:true}")
    Boolean keepAlive;


    @Bean
    public WebRequestSender comvivaWebRequestSender() {
        return new WebClientService(WebClient.builder().clientConnector(new ReactorClientHttpConnector(httpClientConfig.buildHttpClient(maxConnections,keepAlive))).filter(applyHeaders()).build(), comvivaResponseDeserializer, comvivaClientErrorProcessors);
    }
    private ExchangeFilterFunction applyHeaders() {
        return (clientRequest, nextFilter) -> {
            ClientRequest.Builder requestBuilder = ClientRequest.from(clientRequest);
            boolean shouldSkipAuthorizationHeader = unauthorizedServicesConfig.getApiPaths().stream().anyMatch(s -> s.equalsIgnoreCase(clientRequest.url().getPath()));
            log.atSevere().log("Path has been found in unauthorized paths list %s", shouldSkipAuthorizationHeader );

            if (shouldSkipAuthorizationHeader) {
                return nextFilter.exchange(requestBuilder.build());
            }
            requestBuilder.header(ENVIRONMENT_NAME_HEADER, this.environmentName);
            HeaderUtil.getNeomHeaders().forEach((key, value) -> {
                if(!skipHeaders.contains(key)){
                    requestBuilder.header(key,value);
                }
            });
            return nextFilter.exchange(requestBuilder.build());
        };
    }

}
