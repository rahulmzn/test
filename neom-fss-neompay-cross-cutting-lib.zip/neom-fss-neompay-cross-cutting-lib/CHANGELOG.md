# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.0.3](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/compare/v0.0.2...v0.0.3) (2022-03-16)


### Features

* NFS-4510: Added comviva error mappings ([#65](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/65)) ([d66007b](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/d66007b491946535191b36278f4528896f8dd4cd))


### Bug Fixes

* NFS-4377 Auto version using samver ([4df9972](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/4df99725bc79e9138953fecd922bc44b1879cc99))
* NFS-4377 Auto version using samver ([ec5b2fc](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/ec5b2fcf5fc632cdbf9fc2626b2966efd4ffe398))
* NFS-4377 Merge branch 'NFS-4377-auto-version' ([cdf5b00](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/cdf5b00fb33c096a5fab3a7bcd53712745967c2e))
* NFS-4510 fix add swagger filter ([#66](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/66)) ([e587dc2](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/e587dc28428ad1dcb65ed737d93b5a31d036cc93))

### [0.0.3](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/compare/v0.0.2...v0.0.3) (2022-03-15)


### Features

* NFS-4510: Added comviva error mappings ([#65](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/65)) ([d66007b](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/d66007b491946535191b36278f4528896f8dd4cd))


### Bug Fixes

* NFS-4377 Auto version using samver ([4df9972](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/4df99725bc79e9138953fecd922bc44b1879cc99))
* NFS-4377 Auto version using samver ([ec5b2fc](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/ec5b2fcf5fc632cdbf9fc2626b2966efd4ffe398))
* NFS-4377 Merge branch 'NFS-4377-auto-version' ([cdf5b00](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/cdf5b00fb33c096a5fab3a7bcd53712745967c2e))

### [0.0.2](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/compare/v0.0.1...v0.0.2) (2022-03-15)


### Bug Fixes

* NFS-4377 Auto version using samver ([96b0e8a](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/96b0e8a752f3897021fd8f1e6c2c7f4f6b5f5e96))

### 0.0.1 (2022-03-15)


### Features

* NFS-1320: cross cutting lib migration to sandbox ([804e297](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/804e2978da40d28215b5d83804614f165d5a1119))
* NFS-1320: replaced https to http for nexus url ([8a1492b](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/8a1492b3f6708ad7be1ced6f9e1096180f7cd5fe))
* NFS-1364: build and publish only when master ([51e939e](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/51e939e0b7a44c5257a93e3d79cbe8fdd71ad896))
* NFS-1364: making password related changes in jenkins file ([d055ce2](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/d055ce293aa1ef804ea2b1ab0fce24ee34d5408c))
* NFS-1364: password removal from application ([c6d9fa5](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/c6d9fa5949b06b5eafb88d993d24140d79631133))
* NFS-1364: removing access and login key ([cf7a718](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/cf7a7186f59ff4fcec6cfa922f6833f9dcd74db0))
* NFS-1417 resolving the import issue ([967f842](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/967f8425ae1ef8fd8a4545da8a192ae4ccf96e7a))
* NFS-1417 updated the nexus url ([7513582](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/7513582f589d7d4a103f3dc829ae698ca5679e14))
* NFS-1500 added kafka utils ([#26](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/26)) ([419fba0](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/419fba0be855beb9a00381a9ea71c6dfbde4a859))
* Nfs-1500 feat kafka events ([#27](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/27)) ([4ccc5f0](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/4ccc5f0f85e08c38ece78cc427a5939ea68b6ef7))
* NFS-1501: add changes for JWT decoding and verification ([996d812](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/996d812addcfd77b9e862c486a85a9ad770bffd7))
* NFS-1549 add default message If errorcode not found in message.properties file ([f0c082f](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/f0c082f6684082b85b782d8e660a6ad431e06817))
* NFS-1549 add domain specific error code in exception messages ([1292e59](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/1292e59d155d84ad247de4664ff08cae1f9f6558))
* NFS-1549 add domain specific error code in exception messages ([24f9a06](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/24f9a068a0d800d301fec9c9723e923908da6136))
* NFS-1549 added common Message Source as it will be getting used by all domain services ([7d3cdb6](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/7d3cdb6c9604059a94ae5e5e89b5e65cb9e6c8a1))
* NFS-1549 added generic error msges for missing hedaer/body ([6a0d0c8](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/6a0d0c80bfbe0e0c6d51a3f93137aab46c19bcd9))
* NFS-1549 added more exception handler ([ac4f694](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/ac4f69457e1e966d79deee1fdf31e3a34b285837))
* NFS-1549 handle errorcode and fields in invalid argument exception ([2fd11b0](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/2fd11b07f3a288deccb28829a7371a5c47752e96))
* NFS-1549 handle errorcode for missing request body ([3aff03b](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/3aff03bc887e16ed5b22c5c4a7712d39e8f16894))
* NFS-1549 handle mismatched input ([fd2657a](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/fd2657a4ba0c76d2ceb0f152469532d44cbbc383))
* NFS-1549 handle unspecified failure ([10a896e](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/10a896ef676b43551b51e26a5d5bdc3d03364e01))
* NFS-1549 handle WebclientError to get all error details from downstream call ([633aeef](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/633aeef870a83e11031c496cb12557534f583cfe))
* NFS-1549 handleMethodArgumentNotValid refined to have field info. ([0312190](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/0312190dfcc3b43079de1e2f196bbfba4bef7aa6))
* NFS-1549 upgraded cross-lib version ([157369d](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/157369d43f22e6d3c521633de243c4408d25838a))
* NFS-1550 validate and default request headers ([#30](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/30)) ([c737e13](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/c737e13a97c347840718487099389b48b0a338a7))
* NFS-1659 moved security code to common ([#19](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/19)) ([905b0d6](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/905b0d638c1fa8232bf4cd17865a6b61096e2d1c))
* NFS-1659-Adding the token to MDC and creating a new version of the lib ([0755d85](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/0755d85b5714db3634bd98cd3f47adea129d6f67))
* NFS-1782 fixed unused logs while logging error message ([abd602e](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/abd602ea63a9ae17b4b76f0793388dcf4b6fa4f2))
* NFS-1782 fixed unused logs while logging error message ([30fe73f](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/30fe73f776fc42c7c831485820fb79b16ef07671))
* NFS-1957 adding support for PATCH operation ([2be94b9](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/2be94b95e6ee40a143140b582cee44d04fecf781))
* NFS-1964 providing additional behaviour on User ([#28](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/28)) ([1185c43](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/1185c43dfef41bcfbffafe3da7fd07edfa3699c5))
* NFS-1964 version change ([#29](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/29)) ([bcda383](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/bcda3834df9aabb415b0dd8ae1d08891de438ffa))
* NFS-2873 add user null validation , config for comviva & checkout ([3f7e74b](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/3f7e74b31a959384b8cdc6f15384b6cba675d866))
* NFS-2873 env vars added ([#36](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/36)) ([e81993e](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/e81993ead4f3436ac470bef986f459831463cef2))
* NFS-2873 fetch cached comviva tokens ([#31](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/31)) ([7d08646](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/7d086469241758ad0a39a69929962549432f07f6))
* NFS-2944 - added default customer/merchant API url for local testing ([#37](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/37)) ([6a60e09](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/6a60e091b78fc6a9cc5a995b1b2309f666c881c2))
* NFS-3278 added Checkout error mapping ([#53](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/53)) ([bddeb8e](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/bddeb8e060b9a6f52295389d507a6e810a142ab2))
* NFS-3278 Checkout Error Mapping ([55b54f1](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/55b54f1b872ce50b5554992413f467f90eeeb3f7))
* NFS-3278 Checkout Error Mapping ([b0a3688](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/b0a368830d506fe5f406b300f838fb95334542fc))
* NFS-3278 Checkout Error Mapping ([bd4922b](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/bd4922b0597a2d6fcb2f6f24fbabc1cffaedcecd))
* NFS-3278 Checkout Error Mapping ([82c6e04](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/82c6e0409183e4338144d3c9e5a9ac142d7dec3b))
* NFS-3278 Checkout Error Mapping ([fbd1e88](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/fbd1e8894dc0d86be27998b1dc8a4c5b9598ce0f))
* NFS-3278 code formating ([c0897e5](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/c0897e595808e8a10bd81100b33cb2317fe8a8b6))
* NFS-3278 code formating ([618ceaa](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/618ceaa2a3732b83650e65e20c3f1bd422b4bf81))
* NFS-3278 upated version to 0.0.32 ([2270490](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/227049044c73ae519414e6b421eceb7f7841201c))
* NFS-3318: Added client/proxy and service layer request/response… ([#41](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/41)) ([9949abf](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/9949abf678ab2c9872f12440fdeb8168eb81aa53))
* NFS-3318: added diagnostic logging using AOP ([#44](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/44)) ([521ad98](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/521ad982cf4a654e8fc88c6a67a542297cbb2e57))
* NFS-3731: Added comviva error mappings ([#63](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/63)) ([437b64a](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/437b64a70c0aa69db7c56fd6e2f258cd8174b234))
* NFS-3734: added common idempotency interceptor ([#49](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/49)) ([2d1d666](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/2d1d6663bee444345b79420dd5aee0530707b47b))
* NFS-3747 ignore additional error properties of comviva and checkout ([532b400](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/532b400f74c0b55ffa8b3648651d7ef9dc71471a))
* NFS-3747 ignore additional error properties of comviva and checkout ([e0ec084](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/e0ec084b596d854f7212a28375ec4d69a5375e13))
* NFS-3748 added json helper and HMAC encryption using SHA-256 utility ([2e67535](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/2e675354dd49e2657bb2c588a82578915bda2b91))
* NFS-4320 OCI URLs update ([cbe0ad1](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/cbe0ad1358ec77fe3eddedb01292d4b3889c6a71))


### Bug Fixes

* NFS-1064: added Application file in exclusion ([78e8924](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/78e8924dffacd2d6e32cd0c319ecfe1ab7ff5166))
* NFS-1064: excluding packages for sonar check ([def5f66](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/def5f66f7a4cc27453e831c28db9cca33c90c615))
* NFS-1064: taking out proxy from exclusion ([ce0fa25](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/ce0fa2521f2b8857d42764b8cef09d0fc437dc5e))
* NFS-1064: updated sonar exclusions ([9cc3346](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/9cc3346a993ceeccdb64a9b09e025055fd516f48))
* NFS-1064: updated stage for sonar qube ([0d6bdcd](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/0d6bdcd0ec4ad2f9e9d6e9d1e978cf05970e712f))
* Nfs-1550 fix rollback header validations ([#55](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/55)) ([086d4a9](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/086d4a9294daf5135e7908fd2baec5f28ad5414d))
* NFS-1550 resume header validations ([#52](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/52)) ([ccd25cf](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/ccd25cf87bd727e686e0226c00970d77907fb18b))
* NFS-1550: headers ([#61](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/61)) ([103a69d](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/103a69d0b7b41c9211d6e8433a933c34b11d81e2))
* NFS-1550: rolled back header validation temp ([#54](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/54)) ([1fd26a1](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/1fd26a190fec536f0589c143b7ad61eb8175bf33))
* NFS-3278 error handling ([#56](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/56)) ([b03adfb](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/b03adfbaf1e2fcb8c05f38a29c282019cf82a26b))
* NFS-3278 error handling ([#57](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/57)) ([e486078](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/e4860783dccb7b25dc6270bda6718a9e202e27b0))
* NFS-3278 error handling ([#58](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/58)) ([963592a](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/963592a9c1daf96f6bcca072dbac6bb847207f67))
* NFS-3278 error handling ([#59](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/59)) ([1eef53f](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/1eef53f16086fee5b76acb5f0ea794493b223424))
* Nfs-3278 error handling ([#60](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/60)) ([85a7944](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/85a7944a164cedfb913a55e8c6ee75069eaca75a))
* NFS-3278: fix error mappings ([#62](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/62)) ([c95b4f9](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/c95b4f96a8f9ad3f8aba2b6948493efea11cd777))
* NFS-3731 fixed to display error messages ([#64](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/issues/64)) ([1d4068f](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/1d4068f6cad0bc915dcb63d4c3d92d92a3fc8a2f))
* NFS-3748 added message parameter for logging ([e2fe5a9](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/e2fe5a97a0dd48ea32d903b4bb59ba1ce71acfc8))
* NFS-3748 increased version of lib ([f3bf749](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/f3bf749fd0b082a091e03d49137e89d467679457))
* NFS-3748 review comments fixed ([0ea47ae](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/0ea47ae211e7f7130b04bc7e2e1048e75628ed79))
* NFS-4320  hard coded db details ([d9c40da](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/d9c40da64b03546cb14c55baa31402b568072ace))
* NFS-4320 changed image repo changes ([3a07e1b](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/3a07e1bc4e69e07649730b523cd279b156ab6ba1))
* NFS-4320 changed image repo changes ([c13d2fc](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/c13d2fc826db678ff9f8690f97f90e6d2a6a9244))
* NFS-4320 reverted push changes when only master ([4fe2ba6](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/4fe2ba62599361b55a95584a83f0b039e69e5b58))
* NFS-4377 Auto version using samver ([349942e](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/349942e3101076e38e8b3cbd48820a1ab07febc0))
* NFS-4377 Auto version using samver ([a7382f4](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/a7382f46c5a3edaa14d957f0487584efd78d5882))
* NFS-4377 Auto version using samver ([7a81fa4](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/7a81fa4da0885fa7f0eef423fc35dfb40d77de8f))
* no-ticket sonar issue fix ([0abd66a](https://github.com/NEOM-KSA/neom-fss-neompay-cross-cutting-lib/commit/0abd66a918bced1c45d853a827a1601c9c96776d))
