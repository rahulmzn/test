package com.neom.fss.neompay.crosscuttinglib.proxy.internal;

import com.neom.fss.neompay.crosscuttinglib.exception.Error;
import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponse;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.proxy.ClientErrorFactory;
import com.neom.fss.neompay.crosscuttinglib.proxy.GenericErrorProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

@Flogger
@RequiredArgsConstructor
@Component
public class InternalServiceClientErrorProcessor implements GenericErrorProcessor {

    @Override
    public boolean isApplicable(List<Error> response, HttpStatus httpStatus) {
        return httpStatus.is4xxClientError() || httpStatus.is5xxServerError();
    }

    @Override
    public Mono<ClientResponse> processError(List<Error> response, HttpStatus httpStatus)  {
        ErrorResponse errorResponse = new ErrorResponse(new HashSet<>(response));
        return Mono.error(new ServiceException.WebClientError(errorResponse, httpStatus));
    }

}
