package com.neom.fss.neompay.crosscuttinglib.constants;

import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum AppPlatformType {
    ANDROID("Android"),
    IOS("iOS");

    private final String name;

    public static Optional<AppPlatformType> valueOfLabel(String label) {
        AppPlatformType value = null;
        for (AppPlatformType e : values()) {
            if (e.getName().equalsIgnoreCase(label)) {
                value = e;
                break;
            }
        }
        return Optional.ofNullable(value);
    }
}
