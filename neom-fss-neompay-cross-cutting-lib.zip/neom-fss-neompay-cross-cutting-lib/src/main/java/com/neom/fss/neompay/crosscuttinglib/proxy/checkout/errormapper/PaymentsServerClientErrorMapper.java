package com.neom.fss.neompay.crosscuttinglib.proxy.checkout.errormapper;

import com.neom.fss.neompay.crosscuttinglib.client.checkout.dto.ErrorResponseDto;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.WebClientError;
import com.neom.fss.neompay.crosscuttinglib.proxy.checkout.CheckoutErrorMappings;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@Flogger
@RequiredArgsConstructor
@Component
@Deprecated
public class PaymentsServerClientErrorMapper implements CheckoutPaymentsErrorMapper {

    private final CheckoutErrorMappings checkoutErrorMappings;

    @Override
    public boolean isApplicable(ErrorResponseDto response, HttpStatus httpStatus) {
        return httpStatus.is4xxClientError() || httpStatus.is5xxServerError();
    }

    @Override
    public Mono<ClientResponse> processError(ErrorResponseDto response, HttpStatus httpStatus) {
        log.atSevere().log("Checkout Error: Status %s, Response: %s", httpStatus, response);
        return Mono.error(new WebClientError(checkoutErrorMappings.getGenericPaymentErrorCode(), httpStatus));
    }
}
