package com.neom.fss.neompay.crosscuttinglib.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ApiHeader {
    DEVICE_ALIAS("Alias-Name", "alias-name", false, true, "Device Brand Name, example iPhone", "iPhone",
        new ArrayList<>()),
    APP_NAME("App-Name", "app-name", true, true, "Application Type", ApplicationType.CUSTOMER.name(),
        Arrays.stream(ApplicationType.values()).map(ApplicationType::name).collect(Collectors.toList())),
    APP_VERSION("App-Version", "app-version", false, true, "Application Version", "1.0.0", new ArrayList<>()),
    APP_PLATFORM("App-Platform", "app-platform", true, true, "Operating Platform", "iOS",
        Arrays.stream(AppPlatformType.values()).map(AppPlatformType::name).collect(Collectors.toList())),
    CLIENT_IP("X-Forwarded-For", "x-forwarded-for", false, true, "Client IP Address", null, new ArrayList<>()),
    USER_AGENT("User-Agent", "user-agent", false, true, null, "User Browser", new ArrayList<>()),
    AUTHORIZATION("Authorization", "authorization", false, false, "Bearer Token", null, new ArrayList<>()),
    NEOM_CHANNEL("X-Neom-Channel", "x-neom-channel", true, true, "Channel Type", NeomChannelType.MOBILE.name(),
        Arrays.stream(NeomChannelType.values()).map(NeomChannelType::name).collect(Collectors.toList())),
    CORRELATION_ID("X-Correlation-ID", "x-correlation-id", false, true, "Unique ID to correlate requests", null,
        new ArrayList<>()),
    IDEMPOTENCY_KEY("X-Idempotency-Key", "x-idempotency-key", false, true,
        "Unique ID to avoid duplicate request processing", null,
        new ArrayList<>()),

    STEP_UP_AUTH_KEY("X-fapi-interaction-id", "x-fapi-interaction-id", false, true,
            "Step Up authorisation", null, new ArrayList<>()),
    SERVICE_TYPE("X-Service-type", "X-Service-type", false, true,
                             "Service type for step up request", null, new ArrayList<>())
    ;

    private final String headerName;
    private final String lcHeaderName;
    private final boolean isMandatory;
    private final boolean isVisible;
    private final String description;
    private final String defaultOption;
    private final List<String> options;

    public static Optional<ApiHeader> valueOfLabel(String label) {
        ApiHeader value = null;
        for (ApiHeader e : values()) {
            if (e.getHeaderName().equalsIgnoreCase(label)) {
                value = e;
                break;
            }
        }
        return Optional.ofNullable(value);
    }
}
