package com.neom.fss.neompay.crosscuttinglib.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ParsedClientResponse {

    private String responseStr;

    private JsonNode responseJsonNode;
}
