package com.neom.fss.neompay.crosscuttinglib.client.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerDto {

    private String customerId;
    private char[] mobileNumber;
}
