package com.neom.fss.neompay.crosscuttinglib.constants;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Arrays;
@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum UserType {
    CUSTOMER("customer"),
    MERCHANT("merchant"),
    TOURIST("tourist"),
    SYSTEM("system");

    private String value;

    public static UserType find(String val) {
        return Arrays.stream(UserType.values())
                .filter(e -> e.getValue().equals(val))
                .findAny()
                .orElseThrow(() -> new ServiceException.BadInput(String.format("Invalid User Role %s.", val)));
    }
}
