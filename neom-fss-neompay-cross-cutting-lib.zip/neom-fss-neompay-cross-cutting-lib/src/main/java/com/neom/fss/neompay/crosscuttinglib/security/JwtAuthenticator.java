package com.neom.fss.neompay.crosscuttinglib.security;

import com.neom.fss.neompay.crosscuttinglib.constants.ApiHeader;
import com.neom.fss.neompay.crosscuttinglib.security.constants.JwtConstants;
import com.neom.fss.neompay.crosscuttinglib.security.model.TokenVerificationResponse;
import com.neom.fss.neompay.crosscuttinglib.security.model.User;
import com.neom.fss.neompay.crosscuttinglib.security.util.AuthUtil;
import com.neom.fss.neompay.crosscuttinglib.security.util.JwtVerificationUtil;
import com.neom.fss.neompay.crosscuttinglib.util.HeaderUtil;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@RequiredArgsConstructor
@Component
@Flogger
public class JwtAuthenticator {

    private final JwtVerificationUtil jwtVerificationUtil;

    @Value("${api.public-api-path}")
    private String apiPublicBaseUrl;

    public void authenticate(Map<String, String> headers) {
        var jwtToken = headers.get(ApiHeader.AUTHORIZATION.getHeaderName());

        if (jwtToken != null && jwtToken.startsWith(JwtConstants.AUTH_BEARER.getValue())) {
            String authToken = jwtToken.substring(7);

            var appName = headers.get(ApiHeader.APP_NAME.getHeaderName());
            UsernamePasswordAuthenticationToken authentication = getAuthentication(authToken, Boolean.toString(Boolean.TRUE), appName);
            if (null != authentication) {
                SecurityContextHolder.getContext().setAuthentication(authentication);
                MDC.getMDCAdapter().put(ApiHeader.AUTHORIZATION.name(), authToken);
                headers.put(HeaderUtil.SERVICE_NAME, apiPublicBaseUrl);
                HeaderUtil.mdcRequestHeaders(headers);
                log.atInfo().log("Token validation successful");
            } else {
                log.atInfo().log("Token validation failed");
            }
        } else {
            log.atSevere().log("Token not present in the event");
            throw new AccessDeniedException("Invalid Token - User or identifiers missing");
        }
    }

    private UsernamePasswordAuthenticationToken getAuthentication(String bearerTokenValue, String idpHeader,
        String appName) {
        log.atInfo().log("Checking authorisation");
        try {
            String token = AuthUtil.retrieveJWTToken(bearerTokenValue);
            User user = null;

            if (Objects.nonNull(idpHeader) && !idpHeader.isBlank() && "TRUE".equalsIgnoreCase(
                idpHeader)) {
                log.atInfo().log("Identity Token Received. Validating token from Keycloak");
                user = jwtVerificationUtil.verifyIdpToken(token, appName);

            } else {
                throw new AccessDeniedException("Api does not support token other than IDP");
            }

            if (Objects.isNull(user) || !StringUtils.hasText(user.getMobileNo())) {
                throw new AccessDeniedException("Invalid Token - User or identifiers missing");
            }

            MDC.getMDCAdapter().put("USER_TYPE", user.getUserType().name());
            MDC.getMDCAdapter().put("USER_ID", user.getUserId());
            MDC.getMDCAdapter().put("MOBILE_NO", user.getMobileNo());
            return new UsernamePasswordAuthenticationToken(user, null, Collections.emptyList());

        } catch (Exception ex) {
            log.atInfo().log("The request is not authorized - %s", ex);
        }

        return null;
    }

}
