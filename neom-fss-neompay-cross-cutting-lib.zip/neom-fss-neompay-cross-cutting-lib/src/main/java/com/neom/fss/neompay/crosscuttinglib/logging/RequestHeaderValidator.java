package com.neom.fss.neompay.crosscuttinglib.logging;

import com.neom.fss.neompay.crosscuttinglib.constants.ApiHeader;
import com.neom.fss.neompay.crosscuttinglib.constants.AppPlatformType;
import com.neom.fss.neompay.crosscuttinglib.constants.ApplicationType;
import com.neom.fss.neompay.crosscuttinglib.constants.NeomChannelType;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.InvalidHeaders;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
@Flogger
public class RequestHeaderValidator {

    /**
     * Validates request for invalid or missing headers
     *
     * @param headersInfo Request headers key-value map
     */
    public boolean validate(Map<String, String> headersInfo) {

        log.atInfo().log("Validating Request Headers: %s", String.join(", ", headersInfo.keySet()));

        var errors = new ArrayList<String>();

        List<String> missingMandatoryHeaders = checkMandatoryHeaders(headersInfo);
        if (!missingMandatoryHeaders.isEmpty()) {
            errors.add("Mandatory Request Headers missing: " + String.join(", ", missingMandatoryHeaders));
        }

        List<String> invalidValueHeaders = checkInvalidHeaders(headersInfo);
        if (!invalidValueHeaders.isEmpty()) {
            errors.add("Invalid Request Header values: " + String.join(", ", invalidValueHeaders));
        }

        if (!errors.isEmpty()) {
            throw new InvalidHeaders(String.join(". ", errors));
        }

        log.atFine().log("Header validation successful");
        return true;
    }

    private List<String> checkMandatoryHeaders(Map<String, String> headersInfo) {

        return Arrays.stream(ApiHeader.values())
            .filter(e -> e.isMandatory() && !headersInfo.containsKey(e.getHeaderName().toLowerCase()))
            .map(ApiHeader::getHeaderName)
            .collect(Collectors.toList());
    }

    private List<String> checkInvalidHeaders(Map<String, String> headersInfo) {

        return headersInfo.entrySet().stream()
            .filter(e -> {
                var apiHeaderOptional = ApiHeader.valueOfLabel(e.getKey());
                return apiHeaderOptional.isPresent();
            })
            .map(e -> checkHeaderValue(ApiHeader.valueOfLabel(e.getKey()).get(), e.getKey(), e.getValue()))
            .flatMap(Optional::stream)
            .collect(Collectors.toList());
    }

    private Optional<String> checkHeaderValue(ApiHeader apiHeader, String headerName, String headerValue) {

        String invalidHeaderValue = null;

        if (StringUtils.hasText(headerValue)) {
            switch (apiHeader) {
                case NEOM_CHANNEL:
                    if (NeomChannelType.valueOfLabel(headerValue).isEmpty()) {
                        invalidHeaderValue = headerName + " (" + headerValue + ")";
                    }
                    break;
                case APP_NAME:
                    if (ApplicationType.valueOfLabel(headerValue).isEmpty()) {
                        invalidHeaderValue = headerName + " (" + headerValue + ")";
                    }
                    break;
                case APP_PLATFORM:
                    if (AppPlatformType.valueOfLabel(headerValue).isEmpty()) {
                        invalidHeaderValue = headerName + " (" + headerValue + ")";
                    }
                    break;
                default:
                    break;
            }
        } else {
            if (apiHeader.isMandatory()) {
                invalidHeaderValue = headerName;
            }
        }

        return Optional.ofNullable(invalidHeaderValue);
    }
}
