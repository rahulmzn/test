package com.neom.fss.neompay.crosscuttinglib.security.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class KeycloakUser {

    @JsonProperty("email_verified")
    private boolean emailVerified;
    private String name;
    private String mobileNo;
    @JsonProperty("preferred_username")
    private String preferredUsername;
    private String userRole;
    @JsonProperty("given_name")
    private String givenName;
    @JsonProperty("family_name")
    private String familyName;
    private String deviceId;
    private String userId;
    private String idpUserId;
    private long iat;
    private String email;
    private long exp;
    private String sid;
}
