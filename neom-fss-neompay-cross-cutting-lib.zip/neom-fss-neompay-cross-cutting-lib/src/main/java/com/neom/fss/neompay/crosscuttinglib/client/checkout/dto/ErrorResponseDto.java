package com.neom.fss.neompay.crosscuttinglib.client.checkout.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class ErrorResponseDto {

    @JsonProperty("request_id")
    private String requestId;

    @JsonProperty("error_type")
    private String errorType;

    @JsonProperty("error_codes")
    private List<String> errorCodes;

    private String status;
    private String error;
    private String message;



}
