package com.neom.fss.neompay.crosscuttinglib.config;


import com.neom.fss.neompay.crosscuttinglib.util.YmlPropertySourceFactory;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.validation.annotation.Validated;

import java.util.ArrayList;
import java.util.List;

@Configuration
@PropertySource(value = "classpath:service-config.yml", factory = YmlPropertySourceFactory.class)
@ConfigurationProperties(prefix = "unauthorized")
@Validated
@Getter
public class UnauthorizedServicesConfig {
    private final List<String> apiPaths = new ArrayList<>();
}
