package com.neom.fss.neompay.crosscuttinglib.proxy.checkout.errormapper;

import com.neom.fss.neompay.crosscuttinglib.client.checkout.dto.ErrorResponseDto;
import com.neom.fss.neompay.crosscuttinglib.proxy.ErrorProcessor;
import org.springframework.web.reactive.function.client.ClientResponse;

/**
 * Error Mapper for payments endpoint for Checkout
 */
@Deprecated
public interface CheckoutPaymentsErrorMapper extends ErrorProcessor<ErrorResponseDto, ClientResponse> {

}
