package com.neom.fss.neompay.crosscuttinglib.proxy;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

public interface ErrorProcessor<T, R> {

    boolean isApplicable(T response, HttpStatus httpStatus);
    Mono<R> processError(T response, HttpStatus httpStatus) ;

}
