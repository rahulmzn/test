package com.neom.fss.neompay.crosscuttinglib.proxy;

import com.neom.fss.neompay.crosscuttinglib.exception.Error;
import com.neom.fss.neompay.crosscuttinglib.proxy.ParsedClientResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
public interface ErrorResponseDeserializer {
    Mono<List<Error>> getErrorCodes(ClientResponse response);
    Mono<ParsedClientResponse> deserializeSuccessBody(ClientResponse response);
}
