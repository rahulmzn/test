package com.neom.fss.neompay.crosscuttinglib.proxy;

import java.net.URI;
import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;

public interface WebRequestSender {

    /**
     * Allows sending GET request
     *
     * @param uriPath    of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T> T sendGetRequest(URI uriPath, ParameterizedTypeReference<T> returnType);

    /**
     * Allows sending GET request with custom headers
     *
     * @param uriPath    of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T> T sendGetRequest(URI uriPath, HttpHeaders headers, ParameterizedTypeReference<T> returnType);

    /**
     * Allows sending GET request with custom headers and custom processing of business failure/error in case of success response
     *
     * @param uriPath    of the request
     * @param returnType requested return type
     * @param headers    of the request
     * @param businessFailureRules : rules to process 2xx response with client provided business error
     * @return result of the rest call
     */
    <T> T sendGetRequest(URI uriPath, HttpHeaders headers, ParameterizedTypeReference<T> returnType, List<BusinessFailureRuleProcessor> businessFailureRules);



    /**
     * Allows sending DELETE request
     *
     * @param uriPath    of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T> T sendDeleteRequest(URI uriPath, ParameterizedTypeReference<T> returnType);

    /**
     * Allows sending DELETE request with custom headers
     *
     * @param uriPath    of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T> T sendDeleteRequest(URI uriPath, HttpHeaders headers, ParameterizedTypeReference<T> returnType);

    /**
     * Allows sending POST request
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T, K> T sendPostRequest(URI uriPath, K body, ParameterizedTypeReference<T> returnType);

    /**
     * Allows sending POST request with custom headers
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T, K> T sendPostRequest(URI uriPath, K body, HttpHeaders headers, ParameterizedTypeReference<T> returnType);

    /**
     * Allows sending POST request with custom headers and custom processing of business failure/error in case of success response
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param businessFailureRules : rules to process 2xx response with client provided business error                   *
     * @return result of the rest call
     */
    <T, K> T sendPostRequest(URI uriPath, K body, HttpHeaders headers, ParameterizedTypeReference<T> returnType, List<BusinessFailureRuleProcessor> businessFailureRules);


    /**
     * Allows sending PUT request
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T, K> T sendPutRequest(URI uriPath, K body, ParameterizedTypeReference<T> returnType);

    /**
     * Allows sending PUT request with custom headers
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T, K> T sendPutRequest(URI uriPath, K body, HttpHeaders headers,
                            ParameterizedTypeReference<T> returnType);

    /**
     * Allows sending PUT request with custom headers and custom processing of business failure/error in case of success response
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param businessFailureRules : rules to process 2xx response with client provided business error
     * @return result of the rest call
     */
    <T, K> T sendPutRequest(URI uriPath, K body, HttpHeaders headers,
                            ParameterizedTypeReference<T> returnType,List<BusinessFailureRuleProcessor> businessFailureRules);


    /**
     * Allows sending PATCH request
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T, K> T sendPatchRequest(URI uriPath, K body, ParameterizedTypeReference<T> returnType);

    /**
     * Allows sending PATCH request with custom headers
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @return result of the rest call
     */
    <T, K> T sendPatchRequest(URI uriPath, K body, HttpHeaders headers,
                              ParameterizedTypeReference<T> returnType);
    /**
     * Allows sending PATCH request with custom headers and custom processing of business failure/error in case of success response
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param businessFailureRules : rules to process 2xx response with client provided business error
     * @return result of the rest call
     */
    <T, K> T sendPatchRequest(URI uriPath, K body, HttpHeaders headers,
                              ParameterizedTypeReference<T> returnType,List<BusinessFailureRuleProcessor> businessFailureRules);





    /**
     * Allows sending GET request
     *
     * @param uriPath    of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T> T sendGetRequest(URI uriPath, ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);

    /**
     * Allows sending GET request with custom headers
     *
     * @param uriPath    of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T> T sendGetRequest(URI uriPath, HttpHeaders headers, ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);

    /**
     * Allows sending GET request with custom headers and custom processing of business failure/error in case of success response
     *
     * @param uriPath    of the request
     * @param returnType requested return type
     * @param headers    of the request
     * @param businessFailureRules : rules to process 2xx response with client provided business error
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T> T sendGetRequest(URI uriPath, HttpHeaders headers, ParameterizedTypeReference<T> returnType, List<BusinessFailureRuleProcessor> businessFailureRules, boolean isFromNonHttpFlow);



    /**
     * Allows sending DELETE request
     *
     * @param uriPath    of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T> T sendDeleteRequest(URI uriPath, ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);

    /**
     * Allows sending DELETE request with custom headers
     *
     * @param uriPath    of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T> T sendDeleteRequest(URI uriPath, HttpHeaders headers, ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);

    /**
     * Allows sending POST request
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T, K> T sendPostRequest(URI uriPath, K body, ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);

    /**
     * Allows sending POST request with custom headers
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T, K> T sendPostRequest(URI uriPath, K body, HttpHeaders headers, ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);

    /**
     * Allows sending POST request with custom headers and custom processing of business failure/error in case of success response
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param businessFailureRules : rules to process 2xx response with client provided business error                   *
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T, K> T sendPostRequest(URI uriPath, K body, HttpHeaders headers, ParameterizedTypeReference<T> returnType, List<BusinessFailureRuleProcessor> businessFailureRules, boolean isFromNonHttpFlow);


    /**
     * Allows sending PUT request
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T, K> T sendPutRequest(URI uriPath, K body, ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);

    /**
     * Allows sending PUT request with custom headers
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T, K> T sendPutRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);

    /**
     * Allows sending PUT request with custom headers and custom processing of business failure/error in case of success response
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param businessFailureRules : rules to process 2xx response with client provided business error
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T, K> T sendPutRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType,List<BusinessFailureRuleProcessor> businessFailureRules, boolean isFromNonHttpFlow);


    /**
     * Allows sending PATCH request
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T, K> T sendPatchRequest(URI uriPath, K body, ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);

    /**
     * Allows sending PATCH request with custom headers
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T, K> T sendPatchRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow);
    /**
     * Allows sending PATCH request with custom headers and custom processing of business failure/error in case of success response
     *
     * @param uriPath    of the request
     * @param body       of the request
     * @param headers    of the request
     * @param returnType requested return type
     * @param businessFailureRules : rules to process 2xx response with client provided business error
     * @param isFromNonHttpFlow Identifier for flow origin & start point
     * @return result of the rest call
     */
    <T, K> T sendPatchRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType,List<BusinessFailureRuleProcessor> businessFailureRules, boolean isFromNonHttpFlow);

}