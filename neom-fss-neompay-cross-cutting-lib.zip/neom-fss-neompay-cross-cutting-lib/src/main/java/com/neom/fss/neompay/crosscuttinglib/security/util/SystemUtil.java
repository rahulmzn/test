package com.neom.fss.neompay.crosscuttinglib.security.util;

import com.neom.fss.neompay.crosscuttinglib.security.constants.JwtConstants;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.UnknownHostException;

@Component
public class SystemUtil {


    public String getClientIp(HttpServletRequest request) throws UnknownHostException {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (!StringUtils.hasText(ipAddress) || JwtConstants.UNKNOWN.getValue()
                .equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("Proxy-Client-IP");
        }

        if (!StringUtils.hasText(ipAddress) || JwtConstants.UNKNOWN.getValue()
                .equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("WL-Proxy-Client-IP");
        }

        if (!StringUtils.hasText(ipAddress) || JwtConstants.UNKNOWN.getValue()
                .equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
            if (JwtConstants.LOCALHOST_IPV4.getValue().equals(ipAddress)
                    || JwtConstants.LOCALHOST_IPV6.getValue().equals(ipAddress)) {
                InetAddress inetAddress = InetAddress.getLocalHost();
                ipAddress = inetAddress.getHostAddress();
            }
        }

        if (StringUtils.hasText(ipAddress) && ipAddress.indexOf(",") != 0
                && ipAddress.length() > 15) {
            ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
        }

        return ipAddress;
    }
}
