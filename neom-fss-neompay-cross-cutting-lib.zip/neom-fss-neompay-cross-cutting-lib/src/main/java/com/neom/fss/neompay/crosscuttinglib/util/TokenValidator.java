package com.neom.fss.neompay.crosscuttinglib.util;

import com.neom.fss.neompay.crosscuttinglib.security.util.JwtVerificationUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

@Component
@Flogger
public class TokenValidator {

    public static boolean hasTokenExpired(long expEpochTime) {
        log.atSevere().log("Current system time : %s :", LocalDateTime.now());
        LocalDateTime tokenExpTime = getLocalDateTimeFromJwtEpoch(expEpochTime);
        LocalDateTime currentSystemTime = LocalDateTime.now().atOffset(ZoneOffset.UTC).toLocalDateTime();
        log.atSevere().log("Current system time at UTC: %s and Token time at UTC: %s ", currentSystemTime, tokenExpTime);
        Duration between = Duration.between(currentSystemTime,tokenExpTime);
        return between.isNegative();
    }

    private static LocalDateTime getLocalDateTimeFromJwtEpoch(long jwtEpochTime){
        log.atSevere().log("Processing epoch time from token %s ", jwtEpochTime);
        LocalDateTime toLocalDateTime = LocalDateTime.ofEpochSecond(jwtEpochTime, 0, ZoneOffset.UTC);
        log.atSevere().log("Processing date time after parsing %s ", toLocalDateTime);
        return toLocalDateTime;
    }
}
