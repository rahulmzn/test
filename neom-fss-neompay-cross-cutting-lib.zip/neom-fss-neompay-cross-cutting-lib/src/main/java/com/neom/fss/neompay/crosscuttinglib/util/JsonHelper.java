package com.neom.fss.neompay.crosscuttinglib.util;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.ServerError;
import java.io.IOException;
import java.io.InputStream;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * @author rahkumar32
 */

@Component
@RequiredArgsConstructor
public class JsonHelper {

    private final ObjectMapper objectMapper;

    /**
     * Read Json file from resources and convert into given object type.
     *
     * @param jsonFileName : name of JSON file example - testing.json etc.
     * @param classz       : Class of expected object type
     * @param <T>          : Type of expected class
     * @return : Populated object of given Class<T>  from given json file data.
     * @throws IOException :
     */
    public <T> T objectFromJsonFile(String jsonFileName, Class<T> classz) throws IOException {
        InputStream is = classz.getClassLoader().getResourceAsStream(jsonFileName);
        return objectMapper.readValue(is, classz);
    }

    /**
     * Convert object into JSON string
     *
     * @param obj : Object to be converted
     * @return : JSON String of given object
     * @throws ServerError             :
     * @throws JsonProcessingException :
     */

    public String objectAsJsonData(final Object obj) throws ServerError, JsonProcessingException {
        return objectMapper.writeValueAsString(obj);
    }

}
