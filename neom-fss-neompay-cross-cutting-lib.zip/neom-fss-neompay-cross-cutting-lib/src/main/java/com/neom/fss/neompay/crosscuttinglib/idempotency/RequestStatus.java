package com.neom.fss.neompay.crosscuttinglib.idempotency;

public enum RequestStatus {

    INITIATED,
    COMPLETED
}
