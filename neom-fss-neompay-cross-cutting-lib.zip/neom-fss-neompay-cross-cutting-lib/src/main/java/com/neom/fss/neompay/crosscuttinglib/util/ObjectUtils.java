package com.neom.fss.neompay.crosscuttinglib.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ObjectUtils {

    private final ObjectMapper objectMapper;

    public byte[] serialize(Object obj) throws IOException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        objectMapper.writeValue(os, obj);

        return os.toByteArray();
    }
}
