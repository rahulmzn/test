package com.neom.fss.neompay.crosscuttinglib.proxy;

import java.net.URI;
import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.fasterxml.jackson.databind.node.TextNode;
import io.netty.handler.ssl.SslHandshakeTimeoutException;
import io.netty.handler.timeout.ReadTimeoutException;
import io.netty.handler.timeout.WriteTimeoutException;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.apache.kafka.common.errors.TimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
@Flogger
public class WebClientService implements WebRequestSender {

    private WebClient webClient;
    private ErrorResponseDeserializer responseBodyDeserializer;
    private List<? extends GenericErrorProcessor> errorProcessors;

    @Autowired
    public WebClientService(WebClient webClient, ErrorResponseDeserializer responseBodyDeserializer, List<? extends GenericErrorProcessor> commonErrorMappers) {
        this.webClient = webClient;
        this.responseBodyDeserializer = responseBodyDeserializer;
        this.errorProcessors = commonErrorMappers;
    }

    @Override
    public <T> T sendGetRequest(URI uriPath, ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.GET, uriPath, null, null, returnType, null);
    }

    @Override
    public <T> T sendGetRequest(URI uriPath, HttpHeaders headers, ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.GET, uriPath, null, headers, returnType, null);
    }

    @Override
    public <T> T sendGetRequest(URI uriPath, HttpHeaders headers, ParameterizedTypeReference<T> returnType, List<BusinessFailureRuleProcessor> businessFailureRules) {
        return sendRequest(HttpMethod.GET, uriPath, null, headers, returnType, businessFailureRules);
    }

    @Override
    public <T> T sendDeleteRequest(URI uriPath, ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.DELETE, uriPath, null, null, returnType, null);
    }

    @Override
    public <T> T sendDeleteRequest(URI uriPath, HttpHeaders headers,
                                   ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.DELETE, uriPath, null, headers, returnType, null);
    }

    @Override
    public <T, K> T sendPostRequest(URI uriPath, K body,
                                    ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.POST, uriPath, body, null, returnType, null);
    }

    @Override
    public <T, K> T sendPostRequest(URI uriPath, K body, HttpHeaders headers,
                                    ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.POST, uriPath, body, headers, returnType, null);
    }

    @Override
    public <T, K> T sendPostRequest(URI uriPath, K body, HttpHeaders headers, ParameterizedTypeReference<T> returnType, List<BusinessFailureRuleProcessor> businessFailureRules) {
        return sendRequest(HttpMethod.POST, uriPath, body, headers, returnType, businessFailureRules);
    }

    @Override
    public <T, K> T sendPutRequest(URI uriPath, K body,
                                   ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.PUT, uriPath, body, null, returnType, null);
    }

    @Override
    public <T, K> T sendPutRequest(URI uriPath, K body, HttpHeaders headers,
                                   ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.PUT, uriPath, body, headers, returnType, null);
    }

    @Override
    public <T, K> T sendPutRequest(URI uriPath, K body, HttpHeaders headers, ParameterizedTypeReference<T> returnType, List<BusinessFailureRuleProcessor> businessFailureRules) {
        return sendRequest(HttpMethod.PUT, uriPath, body, headers, returnType, businessFailureRules);
    }

    @Override
    public <T, K> T sendPatchRequest(URI uriPath, K body,
                                     ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.PATCH, uriPath, body, null, returnType, null);
    }

    @Override
    public <T, K> T sendPatchRequest(URI uriPath, K body, HttpHeaders headers,
                                     ParameterizedTypeReference<T> returnType) {
        return sendRequest(HttpMethod.PATCH, uriPath, body, headers, returnType, null);
    }

    @Override
    public <T, K> T sendPatchRequest(URI uriPath, K body, HttpHeaders headers, ParameterizedTypeReference<T> returnType, List<BusinessFailureRuleProcessor> businessFailureRules) {
        return sendRequest(HttpMethod.PATCH, uriPath, body, headers, returnType, businessFailureRules);
    }

    /** New Specifications Start From Here**/
    @Override
    public <T> T sendGetRequest(URI uriPath, ParameterizedTypeReference<T> returnType,
        boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.GET, uriPath, null, null, returnType, null);
    }

    @Override
    public <T> T sendGetRequest(URI uriPath, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.GET, uriPath, null, headers, returnType, null);
    }

    @Override
    public <T> T sendGetRequest(URI uriPath, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType,
        List<BusinessFailureRuleProcessor> businessFailureRules, boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.GET, uriPath, null, headers, returnType, businessFailureRules);
    }

    @Override
    public <T> T sendDeleteRequest(URI uriPath, ParameterizedTypeReference<T> returnType,
        boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.DELETE, uriPath, null, null, returnType, null);
    }

    @Override
    public <T> T sendDeleteRequest(URI uriPath, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.DELETE, uriPath, null, headers, returnType, null);
    }

    @Override
    public <T, K> T sendPostRequest(URI uriPath, K body, ParameterizedTypeReference<T> returnType,
        boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.POST, uriPath, body, null, returnType, null);
    }

    @Override
    public <T, K> T sendPostRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.POST, uriPath, body, headers, returnType, null);
    }

    @Override
    public <T, K> T sendPostRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType,
        List<BusinessFailureRuleProcessor> businessFailureRules, boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.POST, uriPath, body, headers, returnType, businessFailureRules);
    }

    @Override
    public <T, K> T sendPutRequest(URI uriPath, K body, ParameterizedTypeReference<T> returnType,
        boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.PUT, uriPath, body, null, returnType, null);
    }

    @Override
    public <T, K> T sendPutRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.PUT, uriPath, body, headers, returnType, null);
    }

    @Override
    public <T, K> T sendPutRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType,
        List<BusinessFailureRuleProcessor> businessFailureRules, boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.PUT, uriPath, body, headers, returnType, businessFailureRules);
    }

    @Override
    public <T, K> T sendPatchRequest(URI uriPath, K body, ParameterizedTypeReference<T> returnType,
        boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.PATCH, uriPath, body, null, returnType, null);
    }

    @Override
    public <T, K> T sendPatchRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType, boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.PATCH, uriPath, body, headers, returnType, null);
    }

    @Override
    public <T, K> T sendPatchRequest(URI uriPath, K body, HttpHeaders headers,
        ParameterizedTypeReference<T> returnType,
        List<BusinessFailureRuleProcessor> businessFailureRules, boolean isFromNonHttpFlow) {
        return sendRequest(HttpMethod.PATCH, uriPath, body, headers, returnType, businessFailureRules);
    }
    /** New Specifications End From Here**/

    private <T, K> T sendRequest(HttpMethod httpMethod, URI uriPath, K body, HttpHeaders headers, ParameterizedTypeReference<T> returnType, List<BusinessFailureRuleProcessor> businessErrorMapper) {
        log.atFine().log("Sending %s request to %s", httpMethod, uriPath);
        webClient = configureErrorMapper(businessErrorMapper);
        var requestBodySpecification = webClient.method(httpMethod).uri(uriPath);

        Optional.ofNullable(headers).ifPresent(httpHeaders ->
                requestBodySpecification
                        .headers(headersConsumer -> headersConsumer.addAll(httpHeaders)));

        Optional.ofNullable(body).ifPresent(requestBodySpecification::bodyValue);

        T respobse = requestBodySpecification.retrieve()
                .bodyToMono(returnType)
                .timeout(Duration.ofSeconds(12))
                .onErrorMap(ReadTimeoutException.class, ex -> new HttpTimeoutException("Cross-Lib ReadTimeout"))
                .doOnError(WriteTimeoutException.class, ex -> log.atSevere().log("Cross-Lib WriteTimeout"))
                .onErrorResume(Mono::error)
                .block();
        log.atFine().log("Completed Sending %s request to %s", httpMethod, uriPath);
        return respobse;
    }

    private WebClient configureErrorMapper(List<BusinessFailureRuleProcessor> businessErrorMappers) {
        businessErrorMappers = Objects.isNull(businessErrorMappers) ? Collections.emptyList() : businessErrorMappers;
        return webClient.mutate().filter(errorHandlingFilter(businessErrorMappers)).build();
    }

    private ExchangeFilterFunction errorHandlingFilter(final List<BusinessFailureRuleProcessor> businessErrorMappers) {
        return ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
            HttpStatus httpStatus = clientResponse.statusCode();
            var parsedClientResponseMono = this.responseBodyDeserializer.deserializeSuccessBody(clientResponse);
            if (httpStatus.is2xxSuccessful()) {
                return parsedClientResponseMono
                        .flatMap(response -> Flux.fromIterable(businessErrorMappers)
                                .filter(errorMapper -> errorMapper.isApplicable(response.getResponseJsonNode(), httpStatus))
                                .next()
                                .flatMap(errorMapper -> errorMapper.processError(response.getResponseJsonNode(), httpStatus))
                                .doOnError(throwable -> log.atSevere().withCause(throwable).log(throwable.getMessage()))
                                .defaultIfEmpty(
                                        ClientResponse.create(httpStatus)
                                                .body(response.getResponseStr())
                                                .headers(headers -> headers.remove(HttpHeaders.CONTENT_TYPE))
                                                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                .build()));
            } else {
                return responseBodyDeserializer.getErrorCodes(clientResponse)
                        .flatMap(jsonNode -> Flux.fromIterable(errorProcessors)
                                .filter(errorMapper -> errorMapper.isApplicable(jsonNode, httpStatus)).next()
                                .flatMap(errorMapper -> errorMapper.processError(jsonNode, httpStatus))
                                .doOnError(throwable -> log.atSevere().withCause(throwable).log(throwable.getMessage())));
            }
        });
    }
}
