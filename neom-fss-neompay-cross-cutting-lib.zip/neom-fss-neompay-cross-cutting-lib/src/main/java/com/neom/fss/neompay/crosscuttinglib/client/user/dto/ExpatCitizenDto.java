package com.neom.fss.neompay.crosscuttinglib.client.user.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExpatCitizenDto {

    private String logId;
    private String firstName;
    private String secondName;
    private String thirdName;
    private String lastName;
    private String englishFirstName;
    private String englishSecondName;
    private String englishThirdName;
    private String englishLastName;

    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDate dateOfBirthG;

    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDate iqamaExpiryDateG;

    private String occupationDesc;
    private String sponsorName;
    private String iqamaIssuePlaceDesc;
    private String gender;
    private String nationalityCode;
}
