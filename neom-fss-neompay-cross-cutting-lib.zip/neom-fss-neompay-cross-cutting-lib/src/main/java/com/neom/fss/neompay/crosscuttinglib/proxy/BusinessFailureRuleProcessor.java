package com.neom.fss.neompay.crosscuttinglib.proxy;

import com.fasterxml.jackson.databind.JsonNode;
import com.neom.fss.neompay.crosscuttinglib.exception.Error;
import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponse;
import com.neom.fss.neompay.crosscuttinglib.proxy.ErrorProcessor;
import org.springframework.web.reactive.function.client.ClientResponse;

import java.util.List;

/**
 * Error Mapper for payments endpoint for Checkout
 */
public interface BusinessFailureRuleProcessor extends ErrorProcessor<JsonNode, ClientResponse> {

}
