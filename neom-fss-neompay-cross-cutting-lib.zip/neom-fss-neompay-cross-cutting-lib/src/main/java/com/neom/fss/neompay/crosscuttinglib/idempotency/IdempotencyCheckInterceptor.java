package com.neom.fss.neompay.crosscuttinglib.idempotency;

import com.neom.fss.neompay.crosscuttinglib.constants.ApiHeader;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.NoData;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.ServerError;
import com.neom.fss.neompay.crosscuttinglib.util.ObjectUtils;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

@Component
@ControllerAdvice
@Flogger
@RequiredArgsConstructor
public class IdempotencyCheckInterceptor implements HandlerInterceptor, ResponseBodyAdvice<Object> {

    private final IdempotencyConfig idempotencyConfig;
    private final IdempotentRequestRepository idempotentRequestRepository;
    private final ObjectUtils objectUtils;

    private final List<String> idempotentMethods = Arrays.asList("POST", "PUT", "PATCH", "DELETE");

    @Value("${caching.ttl-seconds.idempotent-request:300}")
    private Long cacheTtl;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
        throws IOException {

        var processRequest = true;
        if (handler instanceof HandlerMethod) {
            var requestMethod = request.getMethod();
            var requestPath = request.getRequestURI();
            var idempotencyKey = request.getHeader(ApiHeader.IDEMPOTENCY_KEY.getHeaderName());

            if (StringUtils.hasText(idempotencyKey) && idempotencyCheckRequired(requestMethod, requestPath)) {
                processRequest = handleDuplicateRequest(request, response);
            }
        }

        return processRequest;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
        Exception ex) {

        if (handler instanceof HandlerMethod) {
            var requestMethod = request.getMethod();
            var requestPath = request.getRequestURI();
            var idempotencyKey = request.getHeader(ApiHeader.IDEMPOTENCY_KEY.getHeaderName());

            if (StringUtils.hasText(idempotencyKey) && idempotencyCheckRequired(requestMethod, requestPath)) {
                completeIdempotentRequest(idempotencyKey, requestMethod, requestPath, response.getStatus(),
                    response.getContentType());
            }
        }
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
        Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest req,
        ServerHttpResponse resp) {

        HttpServletRequest request = ((ServletServerHttpRequest) req).getServletRequest();
        var requestMethod = request.getMethod();
        var requestPath = request.getRequestURI();
        var idempotencyKey = request.getHeader(ApiHeader.IDEMPOTENCY_KEY.getHeaderName());

        byte[] responseBody;
        try {
            responseBody = objectUtils.serialize(body);
        } catch (IOException e) {
            throw new ServerError("Failed to serialize Idempotent Request's response: " + e.getMessage());
        }

        if (StringUtils.hasText(idempotencyKey) && idempotencyCheckRequired(requestMethod, requestPath)) {
            setIdempotentResponseBody(idempotencyKey, responseBody);
        }

        return body;
    }

    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    private boolean handleDuplicateRequest(HttpServletRequest request, HttpServletResponse response)
        throws IOException {
        var requestMethod = request.getMethod();
        var requestPath = request.getRequestURI();
        var requestParams = request.getParameterMap();
        var idempotencyKey = request.getHeader(ApiHeader.IDEMPOTENCY_KEY.getHeaderName());
        var cachedRequestOptional = idempotentRequestRepository.findById(idempotencyKey);

        if (cachedRequestOptional.isPresent()) {
            var cachedRequest = cachedRequestOptional.get();

            if (cachedRequest.hasCompleted()) {
                log.atInfo().log("Idempotent Request %s %s has executed already - returning cached response",
                    request.getMethod(), request.getRequestURI());
                if (null != cachedRequest.getResponseBody()) {
                    response.getOutputStream().write(cachedRequest.getResponseBody());
                }
                response.setStatus(cachedRequest.getResponseCode());
                response.setContentType(cachedRequest.getResponseContentType());
                return false;
            }

            if (cachedRequest.isWorkInProgress()) {
                log.atInfo().log("Idempotent Request %s %s - execution in progress", request.getMethod(),
                    request.getRequestURI());
                response.sendError(HttpServletResponse.SC_ACCEPTED,
                    "Request has been accepted for processing - try again later to get the response");
                response.setContentType(cachedRequest.getResponseContentType());
                return false;
            }

            log.atWarning().log("Idempotent Request %s %s reusing expired key", request.getMethod(),
                request.getRequestURI());
        }

        cacheIdempotentRequest(idempotencyKey, requestMethod, requestParams, requestPath);
        return true;
    }

    private boolean idempotencyCheckRequired(String requestMethod, String requestPath) {

        if (idempotentMethods.contains(requestMethod)) {
            return idempotencyConfig.getRequestsPattern()
                .stream()
                .anyMatch(requestPath::matches);
        }

        return false;
    }

    private void cacheIdempotentRequest(String idempotencyKey, String requestMethod,
        Map<String, String[]> requestParams, String requestPath) {

        log.atFine().log("Caching Idempotent Request %s %s", requestMethod, requestPath);

        idempotentRequestRepository.save(
            new IdempotentRequest(idempotencyKey, requestMethod, requestParams, requestPath, cacheTtl));
    }

    private void setIdempotentResponseBody(String idempotencyKey, byte[] responseBody) {

        log.atFine().log("Setting Idempotent Request body - length %s", responseBody.length);

        var idempotentRequestOptional = idempotentRequestRepository.findById(idempotencyKey);
        if (idempotentRequestOptional.isEmpty()) {
            throw new NoData("Failed to find cached Idempotent Request Key: " + idempotencyKey);
        }

        var idempotentRequest = idempotentRequestOptional.get();
        idempotentRequest.setResponseBody(responseBody);
        idempotentRequestRepository.save(idempotentRequest);
    }

    private void completeIdempotentRequest(String idempotencyKey, String requestMethod, String requestPath,
        int responseCode, String responseContentType) {

        log.atFine().log("Completing Idempotent Request %s %s", requestMethod, requestPath);

        var idempotentRequestOptional = idempotentRequestRepository.findById(idempotencyKey);
        if (idempotentRequestOptional.isEmpty()) {
            throw new NoData("Failed to find cached Idempotent Request Key: " + idempotencyKey);
        }

        var idempotentRequest = idempotentRequestOptional.get();
        idempotentRequest.setCompleted(responseCode, responseContentType);
        idempotentRequestRepository.save(idempotentRequest);
    }

}
