package com.neom.fss.neompay.crosscuttinglib.security.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CachedUser implements Serializable {

    private String userId;
    private String idpUserId;
    private long tokenExpiryAt;
    private long tokenIssuedAt;
    private String mobileNo;
    private String deviceId;
    private String sessionId;
    private String createdAt;
    private String status;

}
