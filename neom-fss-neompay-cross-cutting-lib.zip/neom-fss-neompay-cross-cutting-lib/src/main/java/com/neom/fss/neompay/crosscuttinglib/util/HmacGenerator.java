package com.neom.fss.neompay.crosscuttinglib.util;


import com.google.common.flogger.StackSize;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.Formatter;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.apache.logging.log4j.util.Strings;

/**
 * @author rahkumar32
 */

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Flogger
public class HmacGenerator {

    private static final String HASH_ALGORITHM = "HmacSHA256";

    /**
     * Encryption of a given text using the provided secretKey
     *
     * @param dataForHmacGeneration : text data to be encrypted
     * @param secretKey             : secret key to be used for encryption
     * @return the encoded string
     * @throws SignatureException : HMAC generation failed due to mismatch of encryption policy
     */
    public static String generateHMACBySHA256(String dataForHmacGeneration, String secretKey)
        throws SignatureException {
        if (Strings.isBlank(dataForHmacGeneration)) {
            return Strings.EMPTY;
        }
        try {
            Key sk = new SecretKeySpec(secretKey.getBytes(), HASH_ALGORITHM);
            Mac mac = Mac.getInstance(sk.getAlgorithm());
            mac.init(sk);
            final byte[] hmac = mac.doFinal(dataForHmacGeneration.getBytes());
            return toHexString(hmac);
        } catch (NoSuchAlgorithmException e1) {
            // throw an exception or pick a different encryption method
            throw new SignatureException(
                "error building signature, no such algorithm in device " + HASH_ALGORITHM);
        } catch (InvalidKeyException e) {
            throw new SignatureException(
                "error building signature, invalid key " + HASH_ALGORITHM);
        }
    }


    private static String toHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        try (Formatter formatter = new Formatter(sb)) {
            for (byte b : bytes) {
                formatter.format("%02x", b);
            }
        } catch (Exception exception) {
            log.atSevere().withStackTrace(StackSize.SMALL)
                .log("HMAC Generation failed - ", exception.getMessage());
            throw exception;
        }
        return sb.toString();
    }

}
