package com.neom.fss.neompay.crosscuttinglib.proxy.checkout.errormapper;

import com.neom.fss.neompay.crosscuttinglib.client.checkout.dto.ErrorResponseDto;
import com.neom.fss.neompay.crosscuttinglib.proxy.ErrorProcessor;
import org.springframework.web.reactive.function.client.ClientResponse;

/**
 * Error Mapper for token and instruments endpoint for Checkout
 */
@Deprecated
public interface CheckoutCardErrorMapper extends ErrorProcessor<ErrorResponseDto, ClientResponse> {

}
