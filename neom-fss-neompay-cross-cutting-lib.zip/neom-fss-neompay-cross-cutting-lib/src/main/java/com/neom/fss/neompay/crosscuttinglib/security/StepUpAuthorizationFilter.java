package com.neom.fss.neompay.crosscuttinglib.security;

import com.neom.fss.neompay.crosscuttinglib.client.stepup.StepUpAuthServiceClient;
import com.neom.fss.neompay.crosscuttinglib.constants.ApiHeader;
import com.neom.fss.neompay.crosscuttinglib.constants.AuthorizationType;
import com.neom.fss.neompay.crosscuttinglib.constants.NeomChannelType;
import com.neom.fss.neompay.crosscuttinglib.exception.FilterExceptionAdvice;
import com.neom.fss.neompay.crosscuttinglib.model.stepup.StepUpAuthTransaction;
import com.neom.fss.neompay.crosscuttinglib.security.model.User;
import com.neom.fss.neompay.crosscuttinglib.security.util.AuthUtil;
import com.neom.fss.neompay.crosscuttinglib.security.util.JwtVerificationUtil;
import com.neom.fss.neompay.crosscuttinglib.util.HeaderUtil;
import com.neom.fss.neompay.crosscuttinglib.util.UniqueIdGenerator;
import liquibase.repackaged.org.apache.commons.lang3.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.flogger.Flogger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.file.AccessDeniedException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.neom.fss.neompay.crosscuttinglib.constants.AuthorizationType.PASSWORD;
import static com.neom.fss.neompay.crosscuttinglib.constants.NeomChannelType.MOBILE;
import static com.neom.fss.neompay.crosscuttinglib.model.stepup.constants.StepUpAuthorizationStatus.*;

@RequiredArgsConstructor
@Component
@Flogger
public class StepUpAuthorizationFilter extends OncePerRequestFilter {

    @Value("${stepup-auth.apply-on.urls:}#{T(java.util.Collections).emptyList()}")
    private final List<String> applyStepUpFor;
    @Value("${stepup-auth.apply-on.service-types:}#{T(java.util.Collections).emptyList()}")
    private final List<String> allowedServiceType;
    private final StepUpAuthServiceClient stepUpAuthServiceClient;
    private final UniqueIdGenerator uniqueIdGenerator;
    private final JwtVerificationUtil jwtVerificationUtil;
    private final FilterExceptionAdvice exceptionByFilterHandler;
    @Value("${stepup-auth.ttl:0}")
    private Integer allowedTTLInSeconds;

    @SneakyThrows
    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull FilterChain chain) {
        boolean hasTransactionVerified = false;
        String contextPath = request.getServletContext().getContextPath();
        boolean isStepUpEnable = Boolean.parseBoolean(request.getHeader("X-neom-step-up"));
        String transactionIdToAuthenticate = request.getHeader(ApiHeader.STEP_UP_AUTH_KEY.getHeaderName());
        List<String> inclusionPaths = applyStepUpFor.stream().map(contextPath::concat).collect(Collectors.toList());
        if (inclusionPaths.contains(request.getRequestURI()) && isStepUpEnable) {
            String token = AuthUtil.getAccessTokenFromRequest(request);
            String appName = HeaderUtil.getAppNameFromRequestHeader(request);
            var headers = HeaderUtil.getRequestHeaders(request);
            HeaderUtil.mdcRequestHeaders(headers);
            String serviceType = request.getHeader(ApiHeader.SERVICE_TYPE.getHeaderName());
            if (!allowedServiceType.contains(serviceType)) {
                log.atSevere().log("Service type does not match in allowed service type : %s", serviceType);
                log.atFine().log("Allowed service type : %s", allowedServiceType.toArray());
                throw new AccessDeniedException(ErrorCodes.JWT_EXPIRED.message);
            }

            NeomChannelType neomChannelType = NeomChannelType.valueOf(request.getHeader(ApiHeader.NEOM_CHANNEL.getHeaderName()));
            if (Objects.isNull(serviceType) || serviceType.length() <= 0) {
                exceptionByFilterHandler.handleAccessDeniedException(response, StringUtils.EMPTY, ErrorCodes.MISSING_SERVICE_TYPE_HEADER.code, ErrorCodes.MISSING_SERVICE_TYPE_HEADER.message);
            }
            User user = jwtVerificationUtil.getUserByAuthTokenType(token, "TRUE", appName);

            if (Strings.isBlank(transactionIdToAuthenticate)) {
                String transactionId = uniqueIdGenerator.getRandomAlphabeticStartWithGivenAndHyphen("txn", 10);
                StepUpAuthTransaction stepUpAuthTransaction = buildStepUpAuth(request, transactionId, user, serviceType, neomChannelType);
                stepUpAuthServiceClient.initiateTransaction(stepUpAuthTransaction);
                if (PASSWORD.equals(stepUpAuthTransaction.getAuthorizationType())) {
                    exceptionByFilterHandler.handleAccessDeniedException(response, transactionId, ErrorCodes.MISSING_INTERACTION_HEADER_PASSWORD.code, ErrorCodes.MISSING_INTERACTION_HEADER_PASSWORD.message);
                } else {
                    exceptionByFilterHandler.handleAccessDeniedException(response,transactionId, ErrorCodes.MISSING_INTERACTION_HEADER_OTP.code, ErrorCodes.MISSING_INTERACTION_HEADER_OTP.message);
                }
                return;
            } else {
                StepUpAuthTransaction existingTransaction = stepUpAuthServiceClient.getTransactionById(transactionIdToAuthenticate);
                if (this.hasTokenExpired(user.getTokenIssuedAt()) && hasTransactionVerifiedOrCompleted(existingTransaction)) {
                    log.atSevere().log("Transaction status already : %s", existingTransaction.getAuthorizationStatus());
                    throw new AccessDeniedException(StepUpAuthorizationFilter.ErrorCodes.JWT_EXPIRED.message);
                }
                if (existingTransaction.getAuthorizationStatus().equals(INITIATED) &&
                        existingTransaction.getChannel().equals(neomChannelType) &&
                        existingTransaction.getUserType().equals(user.getUserType())) {
                    stepUpAuthServiceClient.updateTransaction(transactionIdToAuthenticate, VERIFIED.name());
                    hasTransactionVerified = Boolean.TRUE;
                }
            }
        }
        chain.doFilter(request, response);
        if (hasTransactionVerified) {
            stepUpAuthServiceClient.updateTransaction(transactionIdToAuthenticate, COMPLETED.name());
        }
    }

    private StepUpAuthTransaction buildStepUpAuth(HttpServletRequest request, String transactionId, User user, String serviceType, NeomChannelType neomChannelType) {
        AuthorizationType authorizationType = AuthorizationType.SMS_OTP;
        if (neomChannelType.equals(MOBILE)) authorizationType = PASSWORD;
        return new StepUpAuthTransaction(transactionId, authorizationType, INITIATED, serviceType, request.getRequestURI(), neomChannelType, user.getUserId(), user.getUserType());
    }

    @Getter
    @AllArgsConstructor
    private enum ErrorCodes {
        MISSING_INTERACTION_HEADER_PASSWORD("NPAY_AUTH_10401", "Step up authorization initiated for password"),
        MISSING_INTERACTION_HEADER_OTP("NPAY_AUTH_10402", "Step up authorization initiated for Otp"),
        MISSING_SERVICE_TYPE_HEADER("NPAY_AUTH_10404", "Request Header does not match specifications"),
        JWT_EXPIRED("NPAY_AUTH_10403", "Token expired");

        private final String code;
        private final String message;
    }

    public boolean hasTokenExpired(long epochTime) {
        log.atSevere().log("Current system time : %s :", LocalDateTime.now());
        LocalDateTime tokenTime = jwtVerificationUtil.getLocalDateTimeFromJwtEpoch(epochTime);
        LocalDateTime currentSystemTime = LocalDateTime.now().atOffset(ZoneOffset.UTC).toLocalDateTime();
        log.atSevere().log("Current system time at UTC: %s and Token time at UTC: %s ", currentSystemTime, tokenTime);
        Duration between = Duration.between(tokenTime, currentSystemTime);
        log.atSevere().log("Time diff between token and now in sec is: %s and allowed TTL seconds are: %s ", between.getSeconds(), allowedTTLInSeconds);
        return  allowedTTLInSeconds < between.getSeconds();
    }


    private boolean hasTransactionVerifiedOrCompleted(StepUpAuthTransaction existingTransaction){
        if(Objects.isNull(existingTransaction)){
            return true;
        }
        return existingTransaction.getAuthorizationStatus().equals(VERIFIED) || existingTransaction.getAuthorizationStatus().equals(COMPLETED);
    }
}
