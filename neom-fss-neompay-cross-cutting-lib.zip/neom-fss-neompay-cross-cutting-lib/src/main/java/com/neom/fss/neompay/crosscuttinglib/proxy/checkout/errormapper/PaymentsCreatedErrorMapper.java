package com.neom.fss.neompay.crosscuttinglib.proxy.checkout.errormapper;

import com.fasterxml.jackson.databind.JsonNode;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.WebClientError;
import com.neom.fss.neompay.crosscuttinglib.proxy.checkout.CheckoutErrorMappings;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@Flogger
@RequiredArgsConstructor
@Component
@Deprecated
public class PaymentsCreatedErrorMapper implements CheckoutPaymentsSuccessErrorMapper {

    private final CheckoutErrorMappings checkoutErrorMappings;

    @Override
    public boolean isApplicable(JsonNode response, HttpStatus httpStatus) {
        var isApproved = response.get(APPROVED);
        boolean obj = null != isApproved && isApproved.asBoolean();
        return httpStatus == HttpStatus.CREATED
            && Boolean.FALSE.equals(obj);
    }

    @Override
    public Mono<ClientResponse> processError(JsonNode response, HttpStatus httpStatus) {
        log.atSevere().log("Checkout Error: Status %s, Response: %s", httpStatus, response);
        return Mono.error(new WebClientError(getNeomErrorCode(response), httpStatus));
    }

    private String getNeomErrorCode(JsonNode jsonNode) {
        var responseCode = jsonNode.get(RESPONSE_CODE);
        return checkoutErrorMappings.getPaymentErrorCode(null != responseCode ? responseCode.asText() : "");
    }
}
