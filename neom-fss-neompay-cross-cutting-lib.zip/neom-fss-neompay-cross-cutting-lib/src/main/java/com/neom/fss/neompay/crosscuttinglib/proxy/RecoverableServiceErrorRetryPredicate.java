package com.neom.fss.neompay.crosscuttinglib.proxy;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.WebClientError;
import java.util.function.Predicate;
import org.springframework.http.HttpStatus;

public class RecoverableServiceErrorRetryPredicate implements Predicate<WebClientError> {

    @Override
    public boolean test(WebClientError webClientError) {
        if (webClientError.getHttpStatus() != null) {
            return HttpStatus.BAD_GATEWAY.equals(webClientError.getHttpStatus()) ||
                HttpStatus.GATEWAY_TIMEOUT.equals(webClientError.getHttpStatus());
        }
        return false;
    }
}
