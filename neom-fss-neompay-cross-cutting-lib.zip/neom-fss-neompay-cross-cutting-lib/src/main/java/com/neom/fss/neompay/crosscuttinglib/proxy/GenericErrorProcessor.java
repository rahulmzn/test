package com.neom.fss.neompay.crosscuttinglib.proxy;

import com.neom.fss.neompay.crosscuttinglib.exception.Error;
import com.neom.fss.neompay.crosscuttinglib.proxy.ErrorProcessor;
import org.springframework.web.reactive.function.client.ClientResponse;

import java.util.List;

/**
 *  Error Processor to handle integration client error scenarios
 */
public interface GenericErrorProcessor extends ErrorProcessor<List<Error>, ClientResponse> {

}
