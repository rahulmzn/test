package com.neom.fss.neompay.crosscuttinglib.constants;

import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ApplicationType {
    CUSTOMER("CUSTOMER"),
    MERCHANT("MERCHANT");

    private final String name;

    public static Optional<ApplicationType> valueOfLabel(String label) {
        ApplicationType value = null;
        for (ApplicationType e : values()) {
            if (e.getName().equalsIgnoreCase(label)) {
                value = e;
                break;
            }
        }
        return Optional.ofNullable(value);
    }
}
