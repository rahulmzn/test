package com.neom.fss.neompay.crosscuttinglib.client.keycloak.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.neom.fss.neompay.crosscuttinglib.client.comviva.dto.ErrorDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class ErrorResponseDto {
    private String errorMessage;
    private List<ErrorDto> errors;
    private String error;
    @JsonProperty("error_description")
    private String errorDescription;

}
