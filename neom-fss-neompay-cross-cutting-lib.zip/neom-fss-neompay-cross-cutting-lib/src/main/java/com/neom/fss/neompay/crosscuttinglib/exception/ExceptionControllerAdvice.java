package com.neom.fss.neompay.crosscuttinglib.exception;

import static java.lang.String.format;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Exception Handling advice.
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
@RequiredArgsConstructor
@Flogger
public class ExceptionControllerAdvice extends ResponseEntityExceptionHandler {

    private final ErrorResponseBuilder errorResponseBuilder;

    /**
     * Catch-all generic exception triggered when no others are
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleServerException(Exception e) {
        log.atSevere().withCause(e).log(format("handleServerException: %s", e.getMessage()));
        return new ResponseEntity<>(
            errorResponseBuilder.addGenericError(GenericErrorCode.INTERNAL_ERROR.getValue(), ""),
            HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Custom service exceptions for input validation errors
     */
    @ExceptionHandler(ServiceException.BadInput.class)
    public ResponseEntity<ErrorResponse> handleServiceExceptionBadInput(ServiceException.BadInput e) {
        log.atSevere().withCause(e).log(format("handleServiceExceptionBadInput: %s", e.getMessage()));
        return new ResponseEntity<>(errorResponseBuilder.addError(e.getMessage()), HttpStatus.BAD_REQUEST);
    }

    /**
     * Custom service exceptions for client errors
     */
    @ExceptionHandler(ServiceException.ClientError.class)
    public ResponseEntity<ErrorResponse> handleServiceExceptionClientError(ServiceException.ClientError e) {
        log.atSevere().withCause(e).log(format("handleServiceExceptionClientError: %s", e.getMessage()));
        return new ResponseEntity<>(errorResponseBuilder.addError(e.getMessage()), HttpStatus.BAD_REQUEST);
    }

    /**
     * Custom service exception for request header validation errors
     */
    @ExceptionHandler(ServiceException.InvalidHeaders.class)
    public ResponseEntity<ErrorResponse> handleServiceExceptionInvalidHeaders(ServiceException.InvalidHeaders e) {
        log.atSevere().withCause(e).log(format("handleServiceExceptionInvalidHeaders: %s", e.getMessage()));
        return new ResponseEntity<>(
            errorResponseBuilder.addGenericError(GenericErrorCode.INVALID_HEADER_ERROR_CODE.getValue(), ""),
            HttpStatus.BAD_REQUEST);
    }

    /**
     * Custom service exception for Reactive Web Client errors Error responses are already built by respective third
     * party mappers
     */
    @ExceptionHandler(ServiceException.WebClientError.class)
    public ResponseEntity<ErrorResponse> handleWebClientError(ServiceException.WebClientError e) {
        log.atSevere().withCause(e).log(format("handleWebClientError: %s", e.getMessage()));

        if (null != e.getErrorResponse()) {
            e.getErrorResponse().getErrors()
                .forEach(error -> errorResponseBuilder.addStaticError(error.getReasonCode(), error.getMessage()));
        } else {
            Stream.of(Objects.requireNonNull(e.getMessage()).split(",", -1))
                .forEach(errorResponseBuilder::addError);
        }
        return new ResponseEntity<>(errorResponseBuilder.getErrorResponse(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Custom service exception for missing data
     */
    @ExceptionHandler(ServiceException.NoData.class)
    public ResponseEntity<ErrorResponse> handleServiceExceptionNoData(ServiceException.NoData e) {
        log.atSevere().withCause(e).log(format("handleServiceExceptionNoData: %s", e.getMessage()));
        return new ResponseEntity<>(errorResponseBuilder.addError(e.getMessage()), HttpStatus.NOT_FOUND);
    }

    /**
     * Custom service exception for unknown internal errors
     */
    @ExceptionHandler(ServiceException.ServerError.class)
    public ResponseEntity<ErrorResponse> handleServiceExceptionServerError(ServiceException.ServerError e) {
        log.atSevere().withCause(e).log(format("handleServiceExceptionServerError: %s", e.getMessage()));
        return new ResponseEntity<>(errorResponseBuilder.addError(e.getMessage()),
            HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleConstraintViolationException(ConstraintViolationException e) {
        log.atSevere().withCause(e).log(format("handleConstraintViolationException: %s", e.getMessage()));

        e.getConstraintViolations().stream()
            .map(ConstraintViolation::getPropertyPath)
            .forEach(field -> errorResponseBuilder.addError(field.toString()));

        return new ResponseEntity<>(errorResponseBuilder.getErrorResponse(), HttpStatus.BAD_REQUEST);
    }

    /**
     * URL path variable format errors
     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorResponse> handleMethodArgumentTypeMismatchException(
        MethodArgumentTypeMismatchException e) {
        log.atSevere().withCause(e).log(format("handleMethodArgumentTypeMismatchException: %s", e.getMessage()));
        return new ResponseEntity<>(
            errorResponseBuilder.addError(Objects.requireNonNull(e.getRootCause()).getMessage()),
            HttpStatus.BAD_REQUEST);
    }

    /**
     * Spring Bean validation failures due to annotations like not-blank, not-null Others being data format errors
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
        MethodArgumentNotValidException e, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.atSevere().withCause(e).log(format("handleMethodArgumentNotValid: %s", e.getMessage()));
        extractBindingErrors(e);
        return new ResponseEntity<>(errorResponseBuilder.getErrorResponse(), HttpStatus.BAD_REQUEST);
    }

    /**
     * Message binding errors like invalid boolean, numeric values
     */
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException e, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.atSevere().withCause(e).log(format("handleHttpMessageNotReadable: %s", e.getMessage()));

        Throwable exception = e.getMostSpecificCause();
        if (exception instanceof MismatchedInputException) {
            ((MismatchedInputException) exception).getPath().stream()
                    .map(JsonMappingException.Reference::getFieldName)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList()).forEach(fieldName -> errorResponseBuilder.addGenericError(GenericErrorCode.INVALID_BODY_ERROR_CODE.getValue(), fieldName));
        } else {
            errorResponseBuilder.addGenericError(GenericErrorCode.INVALID_BODY_ERROR_CODE.getValue(), "");
        }

        return new ResponseEntity<>(errorResponseBuilder.getErrorResponse(), HttpStatus.BAD_REQUEST);
    }

    /**
     * ServletRequestBindingException is triggered when a 'required' request header parameter is missing.
     */
    @Override
    protected ResponseEntity<Object> handleServletRequestBindingException(
        ServletRequestBindingException e, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.atSevere().withCause(e).log(format("handleServletRequestBindingException: %s", e.getMessage()));
        return new ResponseEntity<>(
            errorResponseBuilder.addError(GenericErrorCode.MISSING_HEADER_ERROR_CODE.getValue()),
            HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(
        MissingServletRequestParameterException e, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.atSevere().withCause(e).log(format("handleMissingServletRequestParameter: %s", e.getMessage()));
        return new ResponseEntity<>(errorResponseBuilder.addGenericError(GenericErrorCode.MISSING_QUERY_PARAMETER_ERROR_CODE.getValue(),
            e.getParameterName()), HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestPart(
        MissingServletRequestPartException e, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.atSevere().withCause(e).log(format("handleMissingServletRequestPart: %s", e.getMessage()));
        return new ResponseEntity<>(errorResponseBuilder.addError(e.getMessage()), HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleBindException(BindException e, HttpHeaders headers, HttpStatus status,
        WebRequest request) {
        log.atSevere().withCause(e).log(format("handleBindException: %s", e.getMessage()));
        extractBindingErrors(e);
        return new ResponseEntity<>(errorResponseBuilder.getErrorResponse(), HttpStatus.BAD_REQUEST);
    }

    private void extractBindingErrors(BindException e) {
        e.getBindingResult().getAllErrors().stream()
            .map(FieldError.class::cast)
            .forEach(errorResponseBuilder::addError);
    }
}
