package com.neom.fss.neompay.crosscuttinglib.proxy.comviva;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Deprecated
@Component
public class ComvivaErrorMappings{

    public static final String GENERIC_WLT_KEY = "10113";
    public static final String GENERIC_PYMT_KEY = "10137";

    private Map<String, String> wallet;
    private Map<String, String> payments;

    public String getGenericWalletErrorCode() {
        return wallet.getOrDefault(GENERIC_WLT_KEY, "NPAY_WLT_10113");
    }

    public String getGenericPaymentErrorCode() {
        return payments.getOrDefault(GENERIC_PYMT_KEY, "NPAY_PYMT_10137");
    }

    public String getWalletErrorCode(String key) {
        return wallet.getOrDefault(key, getGenericWalletErrorCode());
    }

    public String getPaymentErrorCode(String key) {
        return payments.getOrDefault(key, getGenericPaymentErrorCode());
    }

}
