package com.neom.fss.neompay.crosscuttinglib.proxy.checkout;

import com.neom.fss.neompay.crosscuttinglib.proxy.HttpClientConfig;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebClientService;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.crosscuttinglib.proxy.checkout.errormapper.CheckoutCardErrorMapper;
import com.neom.fss.neompay.crosscuttinglib.proxy.checkout.errormapper.CheckoutPaymentsErrorMapper;
import com.neom.fss.neompay.crosscuttinglib.proxy.checkout.errormapper.CheckoutPaymentsSuccessErrorMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.util.List;

@Configuration
@Flogger
@RequiredArgsConstructor
public class PaymentGatewayClientConfig {

    private final List<CheckoutClientErrorProcessor> checkoutErrorMappers;
    private final CheckoutResponseDeserializer responseBodyDeserializer;
    private final HttpClientConfig httpClientConfig;

    @Value("${api.environment:BLD}")
    String environmentName;

    @Value("${services.checkout.webclient.max-connections:500}")
    Integer maxConnections;

    @Value("${services.checkout.webclient.keep-alive-connection:true}")
    Boolean keepAlive;


    @Bean
    public WebRequestSender checkoutWebRequestSender() {
        return new WebClientService(WebClient.builder().clientConnector(new ReactorClientHttpConnector(httpClientConfig.buildHttpClient(maxConnections,keepAlive)))
                .build(), responseBodyDeserializer, checkoutErrorMappers);
    }


}
