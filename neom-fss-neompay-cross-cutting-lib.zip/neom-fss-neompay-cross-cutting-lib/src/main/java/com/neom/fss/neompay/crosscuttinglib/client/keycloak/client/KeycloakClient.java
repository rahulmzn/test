package com.neom.fss.neompay.crosscuttinglib.client.keycloak.client;

import com.neom.fss.neompay.crosscuttinglib.client.keycloak.dto.KeyResponseDto;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@RequiredArgsConstructor
public class KeycloakClient {

    @Value("#{ '${services.idp.useIdp:true}' ? '${services.idp.service-address:}' : '${services.mock.service-address:}' }")
    private String idpServiceAddress;

    @Value("${services.idp.keysUrl:}")
    private String keyUrl;

    @Qualifier("identityWebRequestSender")
    private final WebRequestSender webRequestSender;

    @Cacheable(value = "keycloakCertsCache")
    public KeyResponseDto getKey(String realm) {

        var keysUri = UriComponentsBuilder.fromHttpUrl(idpServiceAddress + keyUrl).buildAndExpand(realm).toUri();

        return webRequestSender.sendGetRequest(keysUri, null, new ParameterizedTypeReference<>() {
        });

    }
}
