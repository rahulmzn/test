package com.neom.fss.neompay.crosscuttinglib.security.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.util.StringUtils;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {

    private String userId;
    private UserType userType;

    private String firstName;
    private String lastName;

    private String mobileNo;
    private String email;
    private String companyName;
    private String companyType;
    private String deviceId;
    private String idpUserId;
    private long tokenIssuedAt;

    /**
     * Construction of email using mobile number
     *
     * @return
     */
    public String getUserEmailByMobileNo() {
        if (StringUtils.hasText(this.mobileNo)) {
            return this.mobileNo + "@neom.com";
        } else {
            Long number = (long) (Math.random() * 100000 + 3333300000L);
            return number + "@neom.com";
        }

    }

    /**
     * Construction of User's full name
     *
     * @return
     */
    public String getFullName() {
        if (StringUtils.hasText(this.firstName) || StringUtils.hasText(this.lastName)) {
            return this.firstName + " " + this.lastName;
        } else {
            return "NEOM Dummy User";
        }

    }
}
