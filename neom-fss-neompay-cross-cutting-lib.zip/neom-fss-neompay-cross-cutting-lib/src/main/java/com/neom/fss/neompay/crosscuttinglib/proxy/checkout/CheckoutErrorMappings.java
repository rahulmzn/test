package com.neom.fss.neompay.crosscuttinglib.proxy.checkout;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Deprecated
@Component
public class CheckoutErrorMappings {

    public static final String GENERIC_KEY = "10137";

    private Map<String, String> payments;
    private Map<String, String> card;

    public String getGenericPaymentErrorCode() {
        return payments.getOrDefault(GENERIC_KEY, "NPAY_PYMT_10137");
    }

    public String getGenericCardErrorCode() {
        return card.getOrDefault(GENERIC_KEY, "NPAY_CC_10137");
    }

    public String getPaymentErrorCode(String key) {
        return payments.getOrDefault(key, getGenericPaymentErrorCode());
    }

    public String getCardErrorCode(String key) {
        return card.getOrDefault(key, getGenericCardErrorCode());
    }
}
