package com.neom.fss.neompay.crosscuttinglib.proxy;

import com.neom.fss.neompay.crosscuttinglib.constants.ApiHeader;
import com.neom.fss.neompay.crosscuttinglib.constants.KeycloakConstant;
import com.neom.fss.neompay.crosscuttinglib.proxy.internal.InternalServiceClientErrorProcessor;
import com.neom.fss.neompay.crosscuttinglib.proxy.internal.InternalServiceResponseDeserializer;
import com.neom.fss.neompay.crosscuttinglib.security.util.HeaderUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

import static com.neom.fss.neompay.crosscuttinglib.security.constants.JwtConstants.AUTH_BEARER;

@Configuration
@Flogger
@RequiredArgsConstructor
public class WebClientConfig {

    private final List<InternalServiceClientErrorProcessor> neomClientErrorProcessor;
    private final InternalServiceResponseDeserializer responseBodyDeserializer;

    @Bean
    public WebRequestSender webRequestSender() {
        return new WebClientService(WebClient.builder().build(), responseBodyDeserializer, neomClientErrorProcessor);
    }

    private ExchangeFilterFunction applyHeaders() {
        return (clientRequest, nextFilter) -> {
            ClientRequest.Builder requestBuilder = ClientRequest.from(clientRequest).header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            var correlationId = HeaderUtil.getRequestHeader(ApiHeader.CORRELATION_ID.getHeaderName());
            requestBuilder.header(ApiHeader.CORRELATION_ID.getHeaderName(),correlationId);
            return nextFilter.exchange(requestBuilder.build());
        };
    }
}
