package com.neom.fss.neompay.crosscuttinglib.client.user.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KsaCitizenDto {

    private String logId;
    private String firstName;
    private String fatherName;
    private String grandFatherName;
    private String englishFirstName;
    private String englishSecondName;
    private String englishThirdName;

    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDate dateOfBirthH;

    private String gender;

    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDate idExpiryDate;

    private String jobDesc;
    private String idFirstIssuePlace;
}
