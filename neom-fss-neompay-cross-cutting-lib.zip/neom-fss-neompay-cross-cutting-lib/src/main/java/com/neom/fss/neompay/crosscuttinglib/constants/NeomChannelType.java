package com.neom.fss.neompay.crosscuttinglib.constants;

import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum NeomChannelType {
    MOBILE("MOBILE"),
    APPLICATION("APPLICATION");

    private String name;

    public static Optional<NeomChannelType> valueOfLabel(String label) {
        NeomChannelType value = null;
        for (NeomChannelType e : values()) {
            if (e.getName().equalsIgnoreCase(label)) {
                value = e;
                break;
            }
        }
        return Optional.ofNullable(value);
    }
}
