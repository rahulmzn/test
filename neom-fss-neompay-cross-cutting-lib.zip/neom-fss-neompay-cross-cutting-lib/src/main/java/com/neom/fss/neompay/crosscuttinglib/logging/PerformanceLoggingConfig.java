package com.neom.fss.neompay.crosscuttinglib.logging;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * Configuration for Performance Logs
 */
@Configuration
@EnableAspectJAutoProxy
@Aspect
public class PerformanceLoggingConfig {

    @Bean
    public PerformanceLoggingInterceptor performanceLoggingInterceptor() {
        return new PerformanceLoggingInterceptor(true);
    }

    @Pointcut("execution(public * com.neom.fss.neompay..controller.*Controller.*(..)) ||"
        + "execution(public * com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender.*(..))")
    public void performanceMonitor() {
        // Do nothing
    }

    @Bean
    public Advisor advisorPerformance() {
        AspectJExpressionPointcut aspectJExpressionPointcut = new AspectJExpressionPointcut();
        aspectJExpressionPointcut.setExpression(
            "com.neom.fss.neompay.crosscuttinglib.logging.PerformanceLoggingConfig.performanceMonitor()");
        return new DefaultPointcutAdvisor(aspectJExpressionPointcut,
            performanceLoggingInterceptor());

    }
}
