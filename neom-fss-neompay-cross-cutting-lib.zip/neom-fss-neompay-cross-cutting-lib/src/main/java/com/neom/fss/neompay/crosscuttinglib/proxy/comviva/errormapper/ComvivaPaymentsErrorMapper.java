package com.neom.fss.neompay.crosscuttinglib.proxy.comviva.errormapper;

import com.neom.fss.neompay.crosscuttinglib.client.comviva.dto.ErrorResponseDto;
import com.neom.fss.neompay.crosscuttinglib.proxy.ErrorProcessor;
import org.springframework.web.reactive.function.client.ClientResponse;
@Deprecated
public interface ComvivaPaymentsErrorMapper extends ErrorProcessor<ErrorResponseDto, ClientResponse> {

}
