package com.neom.fss.neompay.crosscuttinglib.util;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.MultipleLoginDeviceException;
import com.neom.fss.neompay.crosscuttinglib.security.constants.Constants;
import com.neom.fss.neompay.crosscuttinglib.security.model.CachedUser;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Component
@Flogger
public class MultipleLoginValidator {

    @Autowired
    RedisCacheManager cacheManager;
    public static final String ACTIVE = "ACTIVE";
    public static final String INACTIVE = "INACTIVE";
    public  static final String MULTIPLE_LOGIN_CACHE ="loggedInUserCacheWithDeviceId";
    public Cache cache;

    public void validateMultipleLogin(CachedUser cachedUser) {
        List<CachedUser> cachedUserList = fetch(cachedUser.getUserId());
        if (!CollectionUtils.isEmpty(cachedUserList)) {
            List<CachedUser> sameDeviceSameSessionActive = cachedUserList.stream()
                    .filter(user -> user.getDeviceId().equals(cachedUser.getDeviceId()) && user.getSessionId().equals(cachedUser.getSessionId()) && user.getStatus().equals(ACTIVE))
                    .collect(Collectors.toList());
            if (!sameDeviceSameSessionActive.isEmpty()) {
                log.atInfo().log("Same device with same active session in cache");
                return;
            }
            List<CachedUser> sameDeviceInactive = cachedUserList.stream()
                    .filter(user -> user.getDeviceId().equals(cachedUser.getDeviceId())  && user.getStatus().equals(INACTIVE))
                    .collect(Collectors.toList());

            if (!sameDeviceInactive.isEmpty()) {
                throw new MultipleLoginDeviceException(Constants.INVALID_LOGIN_DEVICE.getValue());
            }
            List<CachedUser> sameDeviceDifferentSession = cachedUserList.stream()
                    .filter(user -> user.getDeviceId().equals(cachedUser.getDeviceId()) && !user.getSessionId().equals(cachedUser.getSessionId()))
                    .collect(Collectors.toList());

            List<CachedUser> differentDevice = cachedUserList.stream()
                    .filter(user -> !user.getDeviceId().equals(cachedUser.getDeviceId()))
                    .collect(Collectors.toList());

            if (!sameDeviceDifferentSession.isEmpty() || !differentDevice.isEmpty()) {
                updateStatus(cachedUserList, cachedUser, ACTIVE);
            }
            //check for same device id if we have any inactive session, then remove it from cache
            removeInactiveEntryForSameDeviceId(cachedUser);
            List<CachedUser> userList = fetch(cachedUser.getUserId());
            if (!CollectionUtils.isEmpty(userList)) {
                removeInactiveEntryIfSessionIsExpired(cachedUser, userList);
            }
        } else {
            cachedUser.setStatus(ACTIVE);
            cache.put(cachedUser.getUserId(), List.of(cachedUser));
        }
    }

    private void removeInactiveEntryIfSessionIsExpired(CachedUser cachedUser, List<CachedUser> cachedUserList) {
        List<CachedUser> expiredSession = cachedUserList.stream().filter(user ->
                 user.getStatus().equals(INACTIVE) &&
                         TokenValidator.hasTokenExpired(user.getTokenExpiryAt())).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(expiredSession)) {
            log.atInfo().log("Removing expired session entry from cache");
            cachedUserList.removeAll(expiredSession);
            cache.put(cachedUser.getUserId(), cachedUserList);
        }
    }

    private void removeInactiveEntryForSameDeviceId(CachedUser cachedUser) {
        List<CachedUser> cachedUserList = null;
        if (Objects.nonNull(cache)) {
            cachedUserList = cache.get(cachedUser.getUserId(), List.class);
        }

        if (!CollectionUtils.isEmpty(cachedUserList)) {
            Map<String, List<CachedUser>> deviceSessionIdMap = cachedUserList.stream().collect(Collectors.groupingBy(CachedUser::getDeviceId));
            List<CachedUser> allEntries = deviceSessionIdMap.entrySet().stream().filter(b -> b.getKey().equals(cachedUser.getDeviceId())).map(a -> filterByStatus(a.getValue(), ACTIVE)).flatMap(List::stream).collect(Collectors.toList());
            List<CachedUser> diffDeviceEntry = deviceSessionIdMap.entrySet().stream().filter(b ->  !b.getKey().equals(cachedUser.getDeviceId())).map(a -> filterByStatus(a.getValue(),INACTIVE)).flatMap(List::stream).collect(Collectors.toList());
            allEntries.addAll(diffDeviceEntry);
            if (!allEntries.isEmpty()) {
                log.atInfo().log("Removing inactive entry from cache for same device id");
                cache.put(cachedUser.getUserId(), allEntries);
            }
        }
    }

    private List<CachedUser> filterByStatus(List<CachedUser> value, String status) {
            return value.stream().filter(user -> user.getStatus().equals(status)).collect(Collectors.toList());
    }

    private void updateStatus(List<CachedUser> userList, CachedUser cachedUser, String status) {
        List<CachedUser> users = userList.stream().filter(a -> a.getStatus().equals(status)).collect(Collectors.toList());
        users.forEach(a -> a.setStatus(INACTIVE));
        //ACTIVE this current entry
        cachedUser.setStatus(ACTIVE);
        ArrayList<CachedUser> cachedUsers = new ArrayList<>(userList);
        cachedUsers.add(cachedUser);
        log.atInfo().log("Updating status in cache");
        cache.put(cachedUser.getUserId(), cachedUsers);
    }

    private List<CachedUser> fetch(String userId) {
        log.atInfo().log("Fetching from cache");
        cache = cacheManager.getCache(MULTIPLE_LOGIN_CACHE);
        if (cache != null) {
            return cache.get(userId, List.class);
        }
        return Collections.emptyList();
    }
}
