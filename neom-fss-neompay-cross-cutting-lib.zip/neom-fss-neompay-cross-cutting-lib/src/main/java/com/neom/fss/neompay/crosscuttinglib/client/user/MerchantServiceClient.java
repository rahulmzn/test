package com.neom.fss.neompay.crosscuttinglib.client.user;

import com.neom.fss.neompay.crosscuttinglib.client.user.dto.MerchantDto;
import com.neom.fss.neompay.crosscuttinglib.client.user.dto.WalletProviderTokenDto;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.NoData;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.ServerError;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.crosscuttinglib.util.HeaderUtil;
import java.util.HashMap;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@RequiredArgsConstructor
public class MerchantServiceClient {

    private static final String MERCHANT_V2_0_GET_TOKEN = "/merchants/v2.0/token/{mobileNo}";
    private static final String MERCHANT_V3_0_GET_MERCHANT = "/merchants/v3.0/merchant/{mobileNo}";
    private final WebRequestSender webRequestSender;

    @Value("${services.merchant.service-address:}")
    private String merchantServiceAddress;

    public WalletProviderTokenDto getWalletProviderToken(String mobileNo) {

        if (!StringUtils.hasText(merchantServiceAddress)) {
            throw new ServerError("Merchant service address not configured");
        }

        ParameterizedTypeReference<WalletProviderTokenDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        var pathParams = new HashMap<String, String>();
        pathParams.put("mobileNo", mobileNo);

        var getTokenUri = UriComponentsBuilder
            .fromHttpUrl(merchantServiceAddress + MERCHANT_V2_0_GET_TOKEN)
            .buildAndExpand(pathParams)
            .toUri();
        var httpHeaders = HeaderUtil.getNeomHttpHeaders();

        WalletProviderTokenDto tokenDto = webRequestSender.sendGetRequest(getTokenUri, httpHeaders,
            parameterizedTypeReference);
        if (null == tokenDto || !StringUtils.hasText(tokenDto.getToken())) {
            throw new NoData("Failed to fetch Wallet Provider Auth Token for Merchant Mobile No: " + mobileNo);
        }
        return tokenDto;
    }

    public MerchantDto getMerchantByMobileNumber(String mobileNo) {

        if (!StringUtils.hasText(merchantServiceAddress)) {
            throw new ServerError("Merchant service address not configured");
        }

        ParameterizedTypeReference<MerchantDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        var pathParams = new HashMap<String, String>();
        pathParams.put("mobileNo", mobileNo);

        var uri = UriComponentsBuilder
            .fromHttpUrl(merchantServiceAddress + MERCHANT_V3_0_GET_MERCHANT)
            .buildAndExpand(pathParams)
            .toUri();
        var httpHeaders = HeaderUtil.getNeomHttpHeaders();

        MerchantDto merchantDto = webRequestSender.sendGetRequest(uri, httpHeaders,
            parameterizedTypeReference);
        if (null == merchantDto || !StringUtils.hasText(merchantDto.getMerchantId())) {
            throw new NoData("Failed to fetch Merchant by Mobile No: " + mobileNo);
        }
        return merchantDto;
    }

}
