package com.neom.fss.neompay.crosscuttinglib.proxy.keycloak;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.flogger.StackSize;
import com.neom.fss.neompay.crosscuttinglib.client.keycloak.dto.ErrorResponseDto;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.WebClientError;
import com.neom.fss.neompay.crosscuttinglib.proxy.GenericErrorProcessor;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebClientService;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.util.List;
import java.util.Objects;

@Configuration
@RequiredArgsConstructor
@Flogger
public class IdentityClientConfig {
    private final KeycloakResponseDeserializer responseBodyDeserializer;
    private final List<IdentityClientErrorProcessor> genericErrorProcessors;

    @Value("${api.environment:BLD}")
    String environmentName;

    @Value("${services.idp.webclient.max-connections:150}")
    Integer maxConnections;

    @Value("${services.idp.webclient.keep-alive-connection:true}")
    Boolean keepAlive;

    @Bean
    public WebRequestSender identityWebRequestSender() {
        return new WebClientService(
            WebClient.builder().clientConnector(new ReactorClientHttpConnector(getNettyBasedHttpClient()))
                .build(),responseBodyDeserializer,genericErrorProcessors);
    }
    private HttpClient getNettyBasedHttpClient() {
        HttpClient nettyHttpClient = null;
        try {
            ConnectionProvider connProvider = ConnectionProvider
                    .builder("commviva-webclient-conn-pool")
                    .maxConnections(maxConnections)
                    /*.maxIdleTime()
                    .maxLifeTime()
                    .pendingAcquireMaxCount()*/
                    .build();

            log.atInfo().log("ConnectionProvider instantiated with max connections : {} and ", maxConnections);

            nettyHttpClient = HttpClient
                    .create(connProvider)
                    .keepAlive(keepAlive)
                    .wiretap(Boolean.TRUE);


        } catch (Exception ex) {
            log.atSevere().log("Unable to instantiate Netty based HttpClient. Error Message : {}, Error Cause : {}, Stracktrace : {}",
                    ex.getMessage(), ex.getCause(), ex.getStackTrace());
            throw ex;
        }
        return nettyHttpClient;
    }
}
