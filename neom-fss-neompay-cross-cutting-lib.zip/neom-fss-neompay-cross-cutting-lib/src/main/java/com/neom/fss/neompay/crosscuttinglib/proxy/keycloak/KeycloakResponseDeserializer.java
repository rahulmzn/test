package com.neom.fss.neompay.crosscuttinglib.proxy.keycloak;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.client.keycloak.dto.ErrorResponseDto;
import com.neom.fss.neompay.crosscuttinglib.exception.Error;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.ServerError;
import com.neom.fss.neompay.crosscuttinglib.proxy.ClientErrorFactory;
import com.neom.fss.neompay.crosscuttinglib.proxy.ErrorResponseDeserializer;
import com.neom.fss.neompay.crosscuttinglib.proxy.ParsedClientResponse;
import java.util.List;
import java.util.Objects;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@Getter
@Setter
@RequiredArgsConstructor
@Component
@Flogger
public class KeycloakResponseDeserializer implements ErrorResponseDeserializer {

    private final ObjectMapper objectMapper;

    @Override
    public Mono<List<Error>> getErrorCodes(ClientResponse response) {
        return response.bodyToMono(String.class).map(errorBody -> {
            var errorResponse = new ErrorResponseDto();
            try {
                log.atSevere().log("Keycloak Web Client Error Body Received: %s", errorBody);
                errorResponse = objectMapper.readValue(errorBody, ErrorResponseDto.class);
                if (Objects.nonNull(errorResponse.getErrorMessage()) && errorResponse.getErrorMessage().length() > 0) {
                    return List.of(new Error(errorResponse.getErrorMessage(), errorResponse.getErrorMessage()));
                }
                return List.of(new Error(errorResponse.getError(), errorResponse.getErrorDescription()));
            } catch (JsonProcessingException e) {
                throw new ServerError("Failed to deserialize Keycloak Client Response: " + e.getMessage());
            }catch (NullPointerException exception){
                return List.of(new Error(ClientErrorFactory.IDP_DEFAULT_ERROR_CODE, "Unexpected null value received error response"));
            }
        });
    }

    @Override
    public Mono<ParsedClientResponse> deserializeSuccessBody(ClientResponse response) {
        return response.bodyToMono(String.class).defaultIfEmpty("{}").map(body -> {
            try {
                return new ParsedClientResponse(body, objectMapper.readTree(body));
            } catch (JsonProcessingException e) {
                throw new ServerError("Failed to deserialize Keycloak Client Response: " + e.getMessage());
            }
        });
    }
}


