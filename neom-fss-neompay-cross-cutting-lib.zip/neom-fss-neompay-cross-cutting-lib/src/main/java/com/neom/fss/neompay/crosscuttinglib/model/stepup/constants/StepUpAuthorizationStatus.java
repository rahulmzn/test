package com.neom.fss.neompay.crosscuttinglib.model.stepup.constants;

public enum StepUpAuthorizationStatus {
    INITIATED,
    VERIFIED,
    COMPLETED
}
