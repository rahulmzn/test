package com.neom.fss.neompay.crosscuttinglib.security.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.client.keycloak.client.KeycloakClient;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.crosscuttinglib.security.constants.Constants;
import com.neom.fss.neompay.crosscuttinglib.security.constants.JwtConstants;
import com.neom.fss.neompay.crosscuttinglib.security.mapper.KeycloakUserMapper;
import com.neom.fss.neompay.crosscuttinglib.security.model.*;
import com.neom.fss.neompay.crosscuttinglib.util.MultipleLoginValidator;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.jackson.io.JacksonDeserializer;
import io.jsonwebtoken.lang.Maps;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.crypto.SecretKey;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Base64;
import java.util.Map;
import java.util.Objects;

@RequiredArgsConstructor
@Component
@Flogger
public class JwtVerificationUtil {

    private static final String CERTIFICATE_INSTANCE = "X.509";
    private static final String KID = "kid";
    private final KeycloakClient keycloakClient;
    private final KeycloakUserMapper keycloakUserMapper;
    private final ObjectMapper mapper;
    private final MultipleLoginValidator deviceValidator;

    @Value("${multiple-plugin:true}")
    private Boolean multiplePlugin;

    public TokenVerificationResponse verifyToken(String token) {

        SecretKey key = Keys.hmacShaKeyFor(
                "testNeomPayIdAuthTokenDomainApiSecretKeyYesKey".getBytes(StandardCharsets.UTF_8));
        var user = Jwts.parserBuilder()
                .deserializeJsonWith(new JacksonDeserializer(Maps.of("user", User.class).build()))
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token.trim())
                .getBody()
                .get("user", User.class);
        return new TokenVerificationResponse(true, token, user);
    }

    public User verifyIdpToken(String token, String appName)
            throws JsonProcessingException, CertificateException {

        String jwtBody =  this.getJwsClaimsFromToken(token, appName);
        if(!jwtBody.contains(JwtConstants.JWT_BODY_FILTER_USER_ROLE.getValue())
            && !jwtBody.contains(JwtConstants.JWT_BODY_FILTER_USER_ID.getValue())){
            throw new BadInput(Constants.INVALID_ACCESS_TOKEN.getValue());
        }
        //API only have User Token
        KeycloakUser keycloakUser = mapper.readValue(jwtBody, KeycloakUser.class);
        log.atInfo().log(Constants.INFO_MESSAGE_ONE.getValue(), keycloakUser);
        if(Boolean.TRUE.equals(multiplePlugin)){
            CachedUser cachedUser = keycloakUserMapper.toUserDetail(keycloakUser);
            deviceValidator.validateMultipleLogin(cachedUser);
        }
        return keycloakUserMapper.toNeomUser(keycloakUser);
    }

    private RSAPublicKey searchPublicKeyByKeyId(String token, String appName)
            throws JsonProcessingException, CertificateException {

        String[] chunks = token.split("\\.");
        String header = new String(Base64.getUrlDecoder().decode(chunks[0]));

        ObjectMapper objectMapper = new ObjectMapper();
        var headerMap = objectMapper.readValue(header, new TypeReference<Map<String, String>>() {
        });

        if (Objects.isNull(headerMap.get(KID))) {
            throw new BadInput("Key Id not found in header");
        }
        var kid = headerMap.get(KID);
        var keys = keycloakClient.getKey(appName.toLowerCase());

        if (Objects.isNull(keys)) {
            throw new BadInput("No Keys found");
        }
        var key = keys.getKeys().stream().filter(keyDto -> keyDto.getKid().equalsIgnoreCase(kid)).findFirst();

        if (key.isEmpty()) {
            throw new BadInput("No Key found for kid: " + kid);
        }

        byte[] encodedCert = key.get().getX5c().get(0).getBytes(StandardCharsets.UTF_8);
        byte[] decodedCert = Base64.getDecoder().decode(encodedCert);
        CertificateFactory certFactory = CertificateFactory.getInstance(CERTIFICATE_INSTANCE);
        InputStream in = new ByteArrayInputStream(decodedCert);
        X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(in);
        return ((RSAPublicKey) certificate.getPublicKey());
    }

    public User getUserByAuthTokenType(String token, String idpHeader, String appName) throws CertificateException, JsonProcessingException {
        if (Strings.isNotBlank(idpHeader) && Strings.isNotBlank(appName)
            && StringUtils.hasText(idpHeader) && Boolean.TRUE.equals(Boolean.parseBoolean(idpHeader))) {
            log.atSevere().log(Constants.INFO_MESSAGE_TWO.getValue());
            return verifyIdpToken(token, appName);
        } else {
            log.atInfo().log("Processing v2 token");
            TokenVerificationResponse tokenResponse = verifyToken(token);
            return tokenResponse.getUser();
        }
    }

    public LocalDateTime getLocalDateTimeFromJwtEpoch(long jwtEpochTime){
        log.atSevere().log("Processing epoch time from token %s ", jwtEpochTime);
        LocalDateTime toLocalDateTime = LocalDateTime.ofEpochSecond(jwtEpochTime, 0, ZoneOffset.UTC);
        log.atSevere().log("Processing date time after parsing %s ", toLocalDateTime);
        return toLocalDateTime;
    }

    public User getUserBySystemAuthTokenType(String token, String idpHeader, String appName) throws CertificateException, JsonProcessingException {
        if (Strings.isNotBlank(idpHeader) && Strings.isNotBlank(appName)
            && StringUtils.hasText(idpHeader) && Boolean.TRUE.equals(Boolean.parseBoolean(idpHeader))) {
            log.atSevere().log(Constants.INFO_MESSAGE_TWO.getValue());
            return verifySystemIdpToken(token, appName);
        } else {
            throw new BadInput(Constants.INVALID_ACCESS_TOKEN.getValue());
        }
    }

    public User verifySystemIdpToken(String token, String appName)
        throws JsonProcessingException, CertificateException {

        String jwtBody = this.getJwsClaimsFromToken(token, appName);
        if(jwtBody.contains(JwtConstants.JWT_BODY_FILTER_USER_ROLE.getValue())
            && jwtBody.contains(JwtConstants.JWT_BODY_FILTER_USER_ID.getValue())) {
            throw new BadInput(Constants.INVALID_ACCESS_TOKEN.getValue());
        }
        //API only have System Token
        KeycloakSystemUser keycloakSystemUser = mapper.readValue(jwtBody, KeycloakSystemUser.class);
        log.atInfo().log(Constants.INFO_MESSAGE_ONE.getValue(), keycloakSystemUser);
        return keycloakUserMapper.toNeomSystemUser(keycloakSystemUser);
    }

    private String getJwsClaimsFromToken(String token, String appName)
        throws JsonProcessingException, CertificateException {
        //Provides RSA Public Key
        RSAPublicKey publicKey = searchPublicKeyByKeyId(token, appName);
        //Generates Claims
        Jws<Claims> jwt = Jwts.parserBuilder().setSigningKey(publicKey).build().parseClaimsJws(token);
        return mapper.writeValueAsString(jwt.getBody());
    }

    public User verifyTokenForDualAuthPolicy(String token, String idpHeader, String appName) throws CertificateException, JsonProcessingException {
        if (Strings.isNotBlank(idpHeader) && Strings.isNotBlank(appName)
            && StringUtils.hasText(idpHeader) && Boolean.TRUE.equals(Boolean.parseBoolean(idpHeader))) {
            log.atSevere().log(Constants.INFO_MESSAGE_TWO.getValue());

            String jwtBody = this.getJwsClaimsFromToken(token, appName);
            if(jwtBody.contains(JwtConstants.JWT_BODY_FILTER_USER_ROLE.getValue())
                && jwtBody.contains(JwtConstants.JWT_BODY_FILTER_USER_ID.getValue())) {
                //API having User Token
                KeycloakUser keycloakUser = mapper.readValue(jwtBody, KeycloakUser.class);
                log.atInfo().log(Constants.INFO_MESSAGE_ONE.getValue(), keycloakUser);
                if(Boolean.TRUE.equals(multiplePlugin)) {
                    CachedUser cachedUser = keycloakUserMapper.toUserDetail(keycloakUser);
                    deviceValidator.validateMultipleLogin(cachedUser);
                }
                return keycloakUserMapper.toNeomUser(keycloakUser);
            } else {
                //API having System Token
                KeycloakSystemUser keycloakSystemUser = mapper.readValue(jwtBody, KeycloakSystemUser.class);
                log.atInfo().log(Constants.INFO_MESSAGE_ONE.getValue(), keycloakSystemUser);
                return keycloakUserMapper.toNeomSystemUser(keycloakSystemUser);
            }
        } else {
            log.atInfo().log("Processing v2 token");
            TokenVerificationResponse tokenResponse = verifyToken(token);
            return tokenResponse.getUser();
        }
    }
}
