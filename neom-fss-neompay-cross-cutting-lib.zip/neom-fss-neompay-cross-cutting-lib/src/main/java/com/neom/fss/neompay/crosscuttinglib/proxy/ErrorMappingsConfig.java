package com.neom.fss.neompay.crosscuttinglib.proxy;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.util.YmlPropertySourceFactory;
import java.io.IOException;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.validation.annotation.Validated;


@Configuration
@PropertySource(value = "classpath:crossCuttingConfig.yml", factory = YmlPropertySourceFactory.class)
@ConfigurationProperties(prefix = "error-mappings")
@Getter
@Setter
@Validated
@RequiredArgsConstructor
public class ErrorMappingsConfig {

    private final ObjectMapper objectMapper;

    @Value("${services.error-mappings.checkout:false}")
    Boolean loadCheckoutErrorMappings;

    @Value("${services.error-mappings.comviva:false}")
    Boolean loadComvivaErrorMappings;

    @Value("${services.error-mappings.enable:false}")
    Boolean isErrorMappingEnabled;

    @NotNull
    private String errorMappingFile;

    @Bean
    public ClientErrorFactory errorMappings(ResourceLoader resourceLoader) throws IOException {
        if (Boolean.TRUE.equals(isErrorMappingEnabled)) {
            return objectMapper.readValue(resourceLoader.getResource(errorMappingFile).getInputStream(),
                    ClientErrorFactory.class);
        }
        return new ClientErrorFactory();
    }
}
