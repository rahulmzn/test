package com.neom.fss.neompay.crosscuttinglib.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.neom.fss.neompay.crosscuttinglib.config.SystemAuthenticationApiConfig;
import com.neom.fss.neompay.crosscuttinglib.constants.ApiHeader;
import com.neom.fss.neompay.crosscuttinglib.exception.FilterExceptionAdvice;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.security.constants.JwtConstants;
import com.neom.fss.neompay.crosscuttinglib.security.model.User;
import com.neom.fss.neompay.crosscuttinglib.security.util.AuthUtil;
import com.neom.fss.neompay.crosscuttinglib.security.util.JwtVerificationUtil;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.slf4j.MDC;
import org.springframework.lang.NonNull;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.cert.CertificateException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Component
@Flogger
public class JwtAuthorizationFilter extends OncePerRequestFilter {

    private static final List<String> EXCLUSION_LIST = Arrays.asList("/url", "/tokens");
    private final JwtVerificationUtil jwtVerificationUtil;
    private final SystemAuthenticationApiConfig systemAuthenticationApiConfig;
    private final FilterExceptionAdvice exceptionByFilterHandler;
    private boolean hasMultipleLoginFound;

    public String getClientIp(HttpServletRequest request) throws UnknownHostException {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (!StringUtils.hasText(ipAddress) || JwtConstants.UNKNOWN.getValue()
            .equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("Proxy-Client-IP");
        }

        if (!StringUtils.hasText(ipAddress) || JwtConstants.UNKNOWN.getValue()
            .equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("WL-Proxy-Client-IP");
        }

        if (!StringUtils.hasText(ipAddress) || JwtConstants.UNKNOWN.getValue()
            .equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
            if (JwtConstants.LOCALHOST_IPV4.getValue().equals(ipAddress)
                || JwtConstants.LOCALHOST_IPV6.getValue().equals(ipAddress)) {
                InetAddress inetAddress = InetAddress.getLocalHost();
                ipAddress = inetAddress.getHostAddress();
            }
        }

        if (StringUtils.hasText(ipAddress) && ipAddress.indexOf(",") != 0
            && ipAddress.length() > 15) {
            ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
        }

        return ipAddress;
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest req, @NonNull HttpServletResponse res, @NonNull FilterChain chain)
        throws IOException, ServletException {

        String contextPath = req.getServletContext().getContextPath();
        String path = req.getServletPath();

        List<String> exclusionList = EXCLUSION_LIST.stream().map(contextPath::concat).collect(Collectors.toList());

        if (!exclusionList.contains(req.getRequestURI())) {
            String token = AuthUtil.getAccessTokenFromRequest(req);

            if (Objects.nonNull(token)) {
                var appName = req.getHeader(ApiHeader.APP_NAME.getHeaderName());
                UsernamePasswordAuthenticationToken authentication = getAuthentication(token, appName, path);
                if (hasMultipleLoginFound) {
                    exceptionByFilterHandler.handleAccessDeniedException(res, liquibase.repackaged.org.apache.commons.lang3.StringUtils.EMPTY,
                            ErrorCodes.INVALID_LOGIN_DEVICE.getCode(), ErrorCodes.INVALID_LOGIN_DEVICE.getMessage());
                    return;
                }
                else if (null != authentication) {
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    log.atInfo().log("Token validation successful");
                } else {
                    log.atInfo().log("Token validation failed");
                }
            } else {
                log.atSevere().log("Token not present in the request");
            }
        }
        MDC.getMDCAdapter().put(ApiHeader.CLIENT_IP.name(), getClientIp(req));
        chain.doFilter(req, res);
        MDC.getMDCAdapter().clear();
    }

    private UsernamePasswordAuthenticationToken getAuthentication(String bearerToken, String appName, String clientRequestPath) {
        log.atInfo().log("Checking authorisation");
        String token = AuthUtil.retrieveJWTToken(bearerToken);
        try {
            User user = null;
            if (systemAuthenticationApiConfig.getSystemAuthApiPaths().stream()
                    .anyMatch(clientRequestPath::matches)) {
                user = jwtVerificationUtil.getUserBySystemAuthTokenType(token, "TRUE", appName);
            } else if (systemAuthenticationApiConfig.getDualAuthApiPaths().stream()
                    .anyMatch(clientRequestPath::matches)) {
                user = jwtVerificationUtil.verifyTokenForDualAuthPolicy(token, "TRUE", appName);
                hasMultipleLoginFound = false;
            } else {
                user = jwtVerificationUtil.getUserByAuthTokenType(token, "TRUE", appName);
                hasMultipleLoginFound = false;
            }

            if (null == user || !StringUtils.hasText(user.getMobileNo())) {
                throw new AccessDeniedException("Invalid Token - User or identifiers missing");
            }
            MDC.getMDCAdapter().put("USER_TYPE", user.getUserType().name());
            MDC.getMDCAdapter().put("USER_ID", user.getUserId());
            MDC.getMDCAdapter().put("MOBILE_NO", user.getMobileNo());
            return new UsernamePasswordAuthenticationToken(user, null, Collections.emptyList());
        }
        catch (ServiceException.MultipleLoginDeviceException ex){
            hasMultipleLoginFound = true;
        } catch (CertificateException | JsonProcessingException ex) {
            log.atSevere().log("The request is not authorized - %s", ex);
        }
        catch (Exception exception){
            log.atSevere().log("Something went wrong while processing auth token - %s", exception);
        }

        return null;
    }
    @Getter
    @AllArgsConstructor
    private enum ErrorCodes {

        INVALID_LOGIN_DEVICE("NPAY_IDAUTH_10124","Invalid login device - logout the user");

        private final String code;
        private final String message;
    }

}
