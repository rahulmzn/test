package com.neom.fss.neompay.crosscuttinglib.model.stepup;

import com.neom.fss.neompay.crosscuttinglib.constants.AuthorizationType;
import com.neom.fss.neompay.crosscuttinglib.constants.NeomChannelType;
import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.neom.fss.neompay.crosscuttinglib.model.stepup.constants.StepUpAuthorizationStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StepUpAuthTransaction {

    @NotBlank
    @NotNull
    private String transactionId;
    @NotNull
    private AuthorizationType authorizationType;
    @NotNull
    private StepUpAuthorizationStatus authorizationStatus;
    @NotNull
    private String serviceType;
    @NotNull
    private String serviceReference;
    @NotNull
    private NeomChannelType channel;
    @NotNull
    @NotBlank
    private String userId;
    @NotNull
    private UserType userType;

}
