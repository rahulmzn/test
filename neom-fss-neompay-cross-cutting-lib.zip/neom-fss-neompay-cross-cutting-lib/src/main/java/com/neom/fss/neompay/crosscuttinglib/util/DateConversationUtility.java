package com.neom.fss.neompay.crosscuttinglib.util;


import java.time.LocalDateTime;
import java.time.ZoneOffset;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;


@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DateConversationUtility {

    public static long localDateTimeToEpochMilliSeconds(LocalDateTime localDateTime) {
        return localDateTime.toEpochSecond(ZoneOffset.UTC);
    }

    public static LocalDateTime epochMilliSecondsToLocalDateTime(long epochMilliSeconds) {
        return LocalDateTime.ofEpochSecond(epochMilliSeconds, 0, ZoneOffset.UTC);
    }
}
