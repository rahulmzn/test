package com.neom.fss.neompay.crosscuttinglib.util;

import liquibase.repackaged.org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Component;

@Component
public class UniqueIdGenerator {

    public String getRandomAscii(int length) {
        return RandomStringUtils.randomAscii(length);
    }

    public String getRandomDigitsByLength(int length) {
        return RandomStringUtils.random(length, false, true);
    }

    public String getRandomDigitsAndLetterByLength(int length) {
        return RandomStringUtils.random(length, true, true);
    }

    public String getRandomAlphabetic(int length) {
        return RandomStringUtils.randomAlphabetic(length);
    }

    public String getRandomAlphabeticStartWithGivenAndHyphen(String startWith, int lengthOfRandomString) {
        return startWith + "-" + RandomStringUtils.randomAlphabetic(lengthOfRandomString);
    }
}