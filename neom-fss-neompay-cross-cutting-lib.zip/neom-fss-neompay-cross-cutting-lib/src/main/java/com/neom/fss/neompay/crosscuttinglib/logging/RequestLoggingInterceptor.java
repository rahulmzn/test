package com.neom.fss.neompay.crosscuttinglib.logging;

import com.neom.fss.neompay.crosscuttinglib.util.HeaderUtil;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * Log every request received and handle headers
 */
@Flogger
@Component
@RequiredArgsConstructor
public class RequestLoggingInterceptor implements HandlerInterceptor {

    private static final String LOG_HEADER_STR = "Header: %s: %s";
    private final RequestHeaderValidator requestHeaderValidator;
    private final LoggingConfig loggingConfig;

    @Value("${api.public-api-path}")
    private String apiPublicBaseUrl;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if (handler instanceof HandlerMethod) {
            log.atInfo().log(
                "Received Request: %s %s", request.getMethod(), request.getRequestURI());

            if (request.getRequestURI().matches(loggingConfig.getRequestsPattern())) {
                var headers = HeaderUtil.getRequestHeaders(request);
                requestHeaderValidator.validate(headers);
                headers.put(HeaderUtil.SERVICE_NAME, apiPublicBaseUrl);
                HeaderUtil.mdcRequestHeaders(headers);
            }
        }
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
        Exception ex) {
        if (handler instanceof HandlerMethod) {
            log.atInfo().log(
                "Returning Response: %s for Request: %s %s",
                response.getStatus(), request.getMethod(), request.getRequestURI());
        }
    }

}
