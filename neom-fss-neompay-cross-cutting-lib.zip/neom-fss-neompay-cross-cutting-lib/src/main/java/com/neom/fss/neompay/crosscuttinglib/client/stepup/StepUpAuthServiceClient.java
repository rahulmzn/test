package com.neom.fss.neompay.crosscuttinglib.client.stepup;

import com.neom.fss.neompay.crosscuttinglib.client.user.dto.WalletProviderTokenDto;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.NoData;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.ServerError;
import com.neom.fss.neompay.crosscuttinglib.model.stepup.StepUpAuthTransaction;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.crosscuttinglib.util.HeaderUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;

@Component
@RequiredArgsConstructor
public class StepUpAuthServiceClient {

    private static final String GET_TXN = "/step-up/transactions/{transactionId}";
    private static final String POST_TXN = "/step-up/transactions";
    private static final String PATCH_TXN = "/step-up/transactions/{transactionId}/{status}";

    private final WebRequestSender webRequestSender;
    private static final String MISSING_URL_ERROR = "ID Auth service address not configured";

    @Value("${services.id-auth.service-address:update-id-auth-url-in-application.yml}")
    private String idAuthServiceAddress;

    public void initiateTransaction(StepUpAuthTransaction stepUpAuthTransaction) {
        serviceAddressNotEmpty();
        ParameterizedTypeReference<String> parameterizedTypeReference = new ParameterizedTypeReference<>() {};
        var stepUpUri = UriComponentsBuilder.fromHttpUrl(idAuthServiceAddress + POST_TXN).build().toUri();
        webRequestSender.sendPostRequest(stepUpUri, stepUpAuthTransaction, HeaderUtil.getNeomHttpHeaders(), parameterizedTypeReference);
    }


    public StepUpAuthTransaction getTransactionById(String transactionId) {
        serviceAddressNotEmpty();
        ParameterizedTypeReference<StepUpAuthTransaction> parameterizedTypeReference = new ParameterizedTypeReference<>() {};
        var pathParams = new HashMap<String, String>();
        pathParams.put("transactionId", transactionId);

        var stepUpTransactionUri = UriComponentsBuilder.fromHttpUrl(idAuthServiceAddress + GET_TXN).buildAndExpand(pathParams).toUri();
        var httpHeaders = HeaderUtil.getNeomHttpHeaders();
        return webRequestSender.sendGetRequest(stepUpTransactionUri, httpHeaders, parameterizedTypeReference);
    }

    public void updateTransaction(String transactionId, String transactionStatus) {
        serviceAddressNotEmpty();
        ParameterizedTypeReference<StepUpAuthTransaction> parameterizedTypeReference = new ParameterizedTypeReference<>() {};
        var pathParams = new HashMap<String, String>();
        pathParams.put("transactionId", transactionId);
        pathParams.put("status", transactionStatus);

        var updateStepUpTransactionUri = UriComponentsBuilder.fromHttpUrl(idAuthServiceAddress + PATCH_TXN).buildAndExpand(pathParams).toUri();
        webRequestSender.sendPatchRequest(updateStepUpTransactionUri, new StepUpAuthTransaction(),HeaderUtil.getNeomHttpHeaders(), parameterizedTypeReference);
    }

    private void serviceAddressNotEmpty(){
        if (idAuthServiceAddress.isBlank()) {
            throw new ServerError(MISSING_URL_ERROR);
        }
    }
}
