package com.neom.fss.neompay.crosscuttinglib.util;

import com.neom.fss.neompay.crosscuttinglib.security.model.CachedUser;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.cache.RedisCacheManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MultipleLoginValidatorTest {

    @Mock
    RedisCacheManager cacheManager;

    @InjectMocks
    MultipleLoginValidator multipleLoginValidator;

    Map<String, List<CachedUser>> cacheMap;


    @Test
    void testMultipleDeviceLoginForFirstUser() {
        CachedUser cachedUser = new CachedUser();
        cachedUser.setUserId("US.123");
        cachedUser.setDeviceId("D1");
        cachedUser.setSessionId("S1");
        List<CachedUser> cachedUsers = new ArrayList<>();
        cacheMap = new HashMap<>();
        when(cacheManager.getCache(any())).thenReturn(new DummyCache(cacheMap));
        multipleLoginValidator.validateMultipleLogin(cachedUser);
        verify(cacheManager, times(1)).getCache(any());
    }

    @Test
    void testMultipleDeviceLoginForFirstUserWithDiffSessionId() {
        CachedUser cachedUser1 = new CachedUser();
        cachedUser1.setUserId("US.123");
        cachedUser1.setDeviceId("D1");
        cachedUser1.setSessionId("S1");
        cachedUser1.setStatus("ACTIVE");
        List<CachedUser> cachedUsers = List.of(cachedUser1);
        CachedUser cachedUser2 = new CachedUser();
        cachedUser2.setUserId("US.123");
        cachedUser2.setDeviceId("D1");
        cachedUser2.setSessionId("S2");
        // getCacheValues(userDetails);
        cacheMap = new HashMap<>();
        cacheMap.put(cachedUser2.getUserId(), cachedUsers);
        when(cacheManager.getCache(any())).thenReturn(new DummyCache(cacheMap));
        multipleLoginValidator.validateMultipleLogin(cachedUser2);
        verify(cacheManager, times(2)).getCache(any());
    }


    @Test
    void testMultipleDeviceLoginForFirstUserWithDiffDeviceSessionId() {
        CachedUser cachedUser1 = new CachedUser();
        cachedUser1.setUserId("US.123");
        cachedUser1.setDeviceId("D1");
        cachedUser1.setSessionId("S2");
        cachedUser1.setStatus("ACTIVE");

        List<CachedUser> cachedUsers = List.of(cachedUser1);
        CachedUser cachedUser2 = new CachedUser();
        cachedUser2.setUserId("US.123");
        cachedUser2.setDeviceId("D2");
        cachedUser2.setSessionId("S1");
        // getCacheValues(userDetails);
        cacheMap = new HashMap<>();
        cacheMap.put(cachedUser2.getUserId(), cachedUsers);
        when(cacheManager.getCache(any())).thenReturn(new DummyCache(cacheMap));
        multipleLoginValidator.validateMultipleLogin(cachedUser2);
        verify(cacheManager, times(2)).getCache(any());
    }

    @Test
    void testMultipleDeviceLoginForSameUserWithDiffDeviceId() {
        CachedUser cachedUser1 = new CachedUser();
        cachedUser1.setUserId("US.123");
        cachedUser1.setDeviceId("D2");
        cachedUser1.setSessionId("S1");
        cachedUser1.setStatus("ACTIVE");

        CachedUser cachedUser3 = new CachedUser();
        cachedUser3.setUserId("US.123");
        cachedUser3.setDeviceId("D1");
        cachedUser3.setSessionId("S2");
        cachedUser3.setStatus("INACTIVE");

        List<CachedUser> cachedUsers = new ArrayList<>();
        cachedUsers.add(cachedUser1);
        cachedUsers.add(cachedUser3);


        CachedUser cachedUser2 = new CachedUser();
        cachedUser2.setUserId("US.123");
        cachedUser2.setDeviceId("D1");
        cachedUser2.setSessionId("S2");
        // getCacheValues(userDetails);
        cacheMap = new HashMap<>();
        cacheMap.put(cachedUser2.getUserId(), cachedUsers);
        when(cacheManager.getCache(any())).thenReturn(new DummyCache(cacheMap));
        assertThrows(
                Exception.class,
                () -> multipleLoginValidator.validateMultipleLogin(cachedUser2));
    }

    @Test
    void testMultipleDeviceLoginRefreshToken() {
        CachedUser cachedUser1 = new CachedUser();
        cachedUser1.setUserId("US.123");
        cachedUser1.setDeviceId("D2");
        cachedUser1.setSessionId("S1");
        cachedUser1.setStatus("ACTIVE");

        List<CachedUser> cachedUsers = new ArrayList<>();
        cachedUsers.add(cachedUser1);

        CachedUser cachedUser2 = new CachedUser();
        cachedUser2.setUserId("US.123");
        cachedUser2.setDeviceId("D2");
        cachedUser2.setSessionId("S2");
        // getCacheValues(userDetails);
        cacheMap = new HashMap<>();
        cacheMap.put(cachedUser2.getUserId(), cachedUsers);
        when(cacheManager.getCache(any())).thenReturn(new DummyCache(cacheMap));
        multipleLoginValidator.validateMultipleLogin(cachedUser2);
        multipleLoginValidator.validateMultipleLogin(cachedUser2);
    }
}
