package com.neom.fss.neompay.crosscuttinglib.security;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.UnknownHostException;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.authentication.AuthenticationManager;

@ExtendWith(MockitoExtension.class)
class JwtAuthorizationFilterGetClientIpTest {

    @InjectMocks
    private JwtAuthorizationFilter instance;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private ServletContext servletContext;

    @Test
    @DisplayName("Should return X-Forwarded-For if has address")
    void getClientIpWithXForwardedForTest() throws UnknownHostException {
        HttpServletRequest request = mockRequestXForwardedFor();
        String result = instance.getClientIp(request);
        assertThat(result).isEqualTo("127.0.0.1");
    }

    @Test
    @DisplayName("Should return Proxy-Client-IP address if X-Forwarded-For is unknown")
    void getClientIpProxyClientIPTest() throws UnknownHostException {
        HttpServletRequest request = mockRequestProxyClientIP();
        String result = instance.getClientIp(request);
        assertThat(result).isEqualTo("127.0.0.2");
    }

    @Test
    @DisplayName("Should return WL-Proxy-Client-IP address if X-Forwarded-For is unknown")
    void getClientIpWLProxyClientIP() throws UnknownHostException {
        HttpServletRequest request = mockRequestWLProxyClientIP();
        String result = instance.getClientIp(request);
        assertThat(result).isEqualTo("127.0.0.3");
    }

    @Test
    @DisplayName("Should return remote address if all headers is unknown")
    void getClientIpWIfNoHeader() throws UnknownHostException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        String result = instance.getClientIp(request);
        assertThat(result).isNotNull();
    }

    @Test
    @DisplayName("Should return remote address in IPv6 if all headers is unknown")
    void getClientIpWIfNoHeaderAndIP6() throws UnknownHostException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRemoteAddr("0:0:0:0:0:0:0:1");
        String result = instance.getClientIp(request);
        assertThat(result).isNotNull();
    }

    private HttpServletRequest mockRequestXForwardedFor() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("X-Forwarded-For", "127.0.0.1,127.0.0.8,127.0.0.9");
        return request;
    }

    private HttpServletRequest mockRequestProxyClientIP() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("X-Forwarded-For", "unknown");
        request.addHeader("Proxy-Client-IP", "127.0.0.2");
        return request;
    }

    private HttpServletRequest mockRequestWLProxyClientIP() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("WL-Proxy-Client-IP", "127.0.0.3");
        return request;
    }
}
