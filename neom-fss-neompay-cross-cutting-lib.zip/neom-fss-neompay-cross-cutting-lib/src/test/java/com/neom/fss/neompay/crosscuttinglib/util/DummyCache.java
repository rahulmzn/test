package com.neom.fss.neompay.crosscuttinglib.util;

import com.neom.fss.neompay.crosscuttinglib.security.model.CachedUser;
import lombok.AllArgsConstructor;
import org.springframework.cache.Cache;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

@AllArgsConstructor
public class DummyCache implements  Cache{

    private  Map<String,List<CachedUser>> cacheMap;

    @Override
    public String getName() {
        return null;
    }

    @Override
    public Object getNativeCache() {
        return null;
    }

    @Override
    public Cache.ValueWrapper get(Object key) {
        return null;
    }

    @Override
    public <T> T get(Object key, Class<T> type) {
        cacheMap.get(key);
        return (T) cacheMap.get(key);
    }

    @Override
    public <T> T get(Object key, Callable<T> valueLoader) {
        return null;
    }

    @Override
    public void put(Object key, Object value) {
        cacheMap.put((String) key, (List<CachedUser>) value);
    }

    @Override
    public void evict(Object key) {

    }

    @Override
    public void clear() {

    }
}
