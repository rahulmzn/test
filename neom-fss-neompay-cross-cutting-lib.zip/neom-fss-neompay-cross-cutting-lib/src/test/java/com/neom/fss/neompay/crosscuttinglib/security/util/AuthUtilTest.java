package com.neom.fss.neompay.crosscuttinglib.security.util;

import static com.neom.fss.neompay.crosscuttinglib.security.util.AuthUtil.getCurrentDateTimeInUTC;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class AuthUtilTest {

    @Test
    void getCurrentDateTimeInUTCTest() {
        LocalDateTime now = LocalDateTime.now(ZoneOffset.UTC);
        LocalDateTime result = getCurrentDateTimeInUTC();
        assertTrue(now.isBefore(result) || now.isEqual(result));
    }

    @Test
    @DisplayName("Check if we will exclude bearer key word")
    void retrieveJWTTokenWithBearerTest() {
        String result = AuthUtil.retrieveJWTToken("barer token");
        assertThat(result).isEqualTo("token");
    }

    @Test
    @DisplayName("Check if it will return whole token if initially was without bearer keyword")
    void retrieveJWTTokenWithoutBearerTest() {
        String result = AuthUtil.retrieveJWTToken("token");
        assertThat(result).isEqualTo("token");
    }
}
