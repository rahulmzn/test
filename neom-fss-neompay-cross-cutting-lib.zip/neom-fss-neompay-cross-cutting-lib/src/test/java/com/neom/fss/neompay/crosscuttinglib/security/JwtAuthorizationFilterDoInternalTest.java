package com.neom.fss.neompay.crosscuttinglib.security;

import static org.assertj.core.api.Assertions.assertThat;

import com.neom.fss.neompay.crosscuttinglib.constants.ApiHeader;
import com.neom.fss.neompay.crosscuttinglib.security.util.JwtVerificationUtil;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockServletContext;
import org.springframework.security.authentication.AuthenticationManager;

@ExtendWith(MockitoExtension.class)
class JwtAuthorizationFilterDoInternalTest {

    @InjectMocks
    private JwtAuthorizationFilter instance;

    @Mock
    private JwtVerificationUtil jwtVerificationUtil;

    @Mock
    private AuthenticationManager authenticationManager;

    @Spy
    private MockServletContext servletContext = new MockServletContext();

    @ParameterizedTest
    @ValueSource(strings = {"Bearer token", "",
        "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJGb3JnZXJvY2siLCJpc3MiOiJuZW9tcGF5IiwiZXhwIjoxNjM5NDk2NzQ2LCJpYXQiOjE2Mzk0OTYxNDYsImp0aSI6ImFhMDNkZDZhLTEzYjYtNGRlOS1iYWE0LWI2ZmJkMzllYTU2ZCJ9.oInL847eqnwqbvb6oli3IsmW67EJZpa8NXuOigt1pS8"})
    void validationFailsWrongTokens(String arg) throws ServletException, IOException {
        MockHttpServletRequest requestMock = new MockHttpServletRequest();
        requestMock.addHeader("Authorization", arg);
        MockHttpServletResponse responseMock = new MockHttpServletResponse();
        FilterChain chainMock = new MockFilterChain();
        servletContext.setContextPath("context-path");
        instance.doFilterInternal(requestMock, responseMock, chainMock);
        String token = MDC.getMDCAdapter().get(ApiHeader.AUTHORIZATION.getHeaderName());
        assertThat(token).isNull();
    }
}
