package com.neom.fss.neompay.crosscuttinglib.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class UniqueIdGeneratorTest {

    @InjectMocks
    private UniqueIdGenerator uniqueIdGenerator;

    @Test
    void otpGenerator() {
        String actualResult = uniqueIdGenerator.getRandomDigitsByLength(6);
        assertEquals(6, actualResult.length());
    }

    @Test
    void getRandomAlphabetic() {
        String actualResult = uniqueIdGenerator.getRandomAlphabetic(6);
        assertEquals(6, actualResult.length());
    }

    @Test
    void getRandomDigitsAndLetterByLength() {
        String actualResult = uniqueIdGenerator.getRandomDigitsAndLetterByLength(6);
        assertEquals(6, actualResult.length());
    }

    @Test
    void getRandomAlphabeticStartWithGivenAndHyphen() {
        String actualResult = uniqueIdGenerator.getRandomAlphabeticStartWithGivenAndHyphen("otp", 6);
        assertTrue(actualResult.startsWith("otp"));
    }

    @Test
    void getRandomAscii() {
        String actualResult = uniqueIdGenerator.getRandomAscii(6);
        assertEquals(6, actualResult.length());
    }

    @Test
    void generateRandomOtp() {
        List<String> data = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            String actualResult = uniqueIdGenerator.getRandomDigitsByLength(6);
            assertFalse(data.contains(actualResult));
            assertEquals(6, actualResult.length());
            data.add(actualResult);

        }
    }

}