package com.neom.fss.neompay.crosscuttinglib.logging;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.neom.fss.neompay.crosscuttinglib.constants.ApiHeader;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import java.util.HashMap;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class RequestHeaderValidatorTest {

    private final RequestHeaderValidator requestHeaderValidator = new RequestHeaderValidator();

    @Test
    void failsWhenNoHeadersSent() {
        // when then
        assertThrows(ServiceException.InvalidHeaders.class, () -> requestHeaderValidator.validate(new HashMap<>()));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "invalid"})
    void failsWhenMandatoryHeaderInvalid(String channel) {
        // given
        var headers = getMandatoryHeaders();
        headers.put(ApiHeader.NEOM_CHANNEL.getHeaderName(), channel);

        // when then
        assertThrows(ServiceException.InvalidHeaders.class, () -> requestHeaderValidator.validate(headers));
    }

    @ParameterizedTest
    @ValueSource(strings = {"invalid"})
    void failsWhenOptionalHeaderInvalid(String platform) {
        // given
        var headers = getMandatoryHeaders();
        headers.put(ApiHeader.APP_PLATFORM.getHeaderName(), platform);

        // when then
        assertThrows(ServiceException.InvalidHeaders.class, () -> requestHeaderValidator.validate(headers));
    }

    @ParameterizedTest
    @ValueSource(strings = {"MOBILE", "Mobile", "mobile"})
    void succeedsWhenValidMandatoryHeader(String channel) {
        // given
        var headers = new HashMap<String, String>();
        headers.put(ApiHeader.NEOM_CHANNEL.getHeaderName().toLowerCase(), channel);
        headers.put(ApiHeader.APP_NAME.getHeaderName().toLowerCase(), "CUSTOMER");
        headers.put(ApiHeader.APP_PLATFORM.getHeaderName().toLowerCase(), "iOS");

        //when
        boolean result = requestHeaderValidator.validate(headers);

        // then
        assertTrue(result);
    }

    @Test
    void succeedsEvenWhenUnknownHeaderSent() {
        // given
        var headers = getMandatoryHeaders();
        headers.put("unknown", "unknown");
        headers.put(ApiHeader.NEOM_CHANNEL.getHeaderName().toLowerCase(), "MOBILE");
        headers.put(ApiHeader.APP_NAME.getHeaderName().toLowerCase(), "CUSTOMER");
        headers.put(ApiHeader.APP_PLATFORM.getHeaderName().toLowerCase(), "iOS");

        //when
        boolean result = requestHeaderValidator.validate(headers);

        // then
        assertTrue(result);
    }

    private HashMap<String, String> getMandatoryHeaders() {
        var headers = new HashMap<String, String>();
        headers.put(ApiHeader.NEOM_CHANNEL.getHeaderName().toLowerCase(), "MOBILE");
        headers.put(ApiHeader.APP_NAME.getHeaderName().toLowerCase(), "CUSTOMER");
        return headers;
    }
}
