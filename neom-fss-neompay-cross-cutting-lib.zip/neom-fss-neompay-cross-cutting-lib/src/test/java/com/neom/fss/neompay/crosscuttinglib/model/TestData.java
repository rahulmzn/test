
package com.neom.fss.neompay.crosscuttinglib.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestData {
    private String body;
    private Long id;
    private Long postId;

}
