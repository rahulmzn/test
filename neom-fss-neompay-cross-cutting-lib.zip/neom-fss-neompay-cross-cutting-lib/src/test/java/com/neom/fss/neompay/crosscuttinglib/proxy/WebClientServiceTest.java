package com.neom.fss.neompay.crosscuttinglib.proxy;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import com.neom.fss.neompay.crosscuttinglib.proxy.internal.InternalServiceClientErrorProcessor;
import com.neom.fss.neompay.crosscuttinglib.proxy.internal.InternalServiceResponseDeserializer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

class WebClientServiceTest {

    private static WebClientService webClientService;
    private static MockWebServer mockBackEnd;

    private final ObjectMapper objectMapper = new ObjectMapper();

    private final static InternalServiceResponseDeserializer internalServiceResponseDeserializer = new InternalServiceResponseDeserializer(new ObjectMapper());



    @BeforeAll
    static void setUp() throws IOException {
        mockBackEnd = new MockWebServer();
        mockBackEnd.start();
        webClientService = new WebClientService(WebClient.builder().build(),internalServiceResponseDeserializer, Collections.emptyList());

    }

    @AfterAll
    static void tearDown() throws IOException {
        mockBackEnd.shutdown();
    }

    @Test
    void sendGetRequest_expectedGetRequestSend() throws Exception {
        // given
        var visa = new CardDto("Visa", "0123123");
        var masterCard = new CardDto("Master card", "0231231");

        var availableCountryCodes = List.of(visa, masterCard);

        mockBackEnd.enqueue(new MockResponse()
            .setBody(objectMapper.writeValueAsString(availableCountryCodes))
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<List<CardDto>> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService.sendGetRequest(cardsURI, parameterizedTypeReference);

        // then
        assertEquals(availableCountryCodes, result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.GET.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
    }

    @Test
    void sendGetRequestWithHeaders_expectedGetRequestWithCustomHeaderSend() throws Exception {
        // given
        var visa = new CardDto("Visa", "0123123");
        var masterCard = new CardDto("Master card", "0231231");

        var availableCountryCodes = List.of(visa, masterCard);

        mockBackEnd.enqueue(new MockResponse()
            .setBody(objectMapper.writeValueAsString(availableCountryCodes))
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<List<CardDto>> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var headers = new HttpHeaders();
        headers.add("test", "test");

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService.sendGetRequest(cardsURI, headers, parameterizedTypeReference);

        // then
        assertEquals(availableCountryCodes, result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.GET.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
        assertNotNull(recordedRequest.getHeaders().get("test"));
    }

    @Test
    void sendDeleteRequest_expectedDeleteRequestSend() throws Exception {
        // given
        mockBackEnd.enqueue(new MockResponse()
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<Object> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService.sendDeleteRequest(cardsURI, parameterizedTypeReference);

        // then
        assertNotNull(result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.DELETE.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
    }

    @Test
    void sendDeleteRequestWithHeaders_expectedDeleteRequestWithCustomHeaderSend() throws Exception {
        // given
        mockBackEnd.enqueue(new MockResponse()
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<Object> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var headers = new HttpHeaders();
        headers.add("test", "test");

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService
            .sendDeleteRequest(cardsURI, headers, parameterizedTypeReference);

        // then
        assertNotNull(result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.DELETE.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
        assertNotNull(recordedRequest.getHeaders().get("test"));
    }

    @Test
    void sendPostRequest_expectedPostRequestSend() throws Exception {
        // given
        var visa = new CardDto("Visa", "0123123");
        var masterCard = new CardDto("Master card", "0231231");

        var availableCountryCodes = List.of(visa, masterCard);

        var availableCountryCodesJson = objectMapper.writeValueAsString(availableCountryCodes);
        mockBackEnd.enqueue(new MockResponse()
            .setBody(availableCountryCodesJson)
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<List<CardDto>> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService.sendPostRequest(cardsURI, availableCountryCodes,
            parameterizedTypeReference);

        // then
        assertEquals(availableCountryCodes, result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.POST.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
        assertEquals(availableCountryCodesJson, recordedRequest.getBody().readUtf8());
    }

    @Test
    void sendPostRequestWithHeaders_expectedPostRequestWithCustomHeaderSend() throws Exception {
        // given
        var visa = new CardDto("Visa", "0123123");
        var masterCard = new CardDto("Master card", "0231231");

        var availableCountryCodes = List.of(visa, masterCard);

        var availableCountryCodesJson = objectMapper.writeValueAsString(availableCountryCodes);
        mockBackEnd.enqueue(new MockResponse()
            .setBody(availableCountryCodesJson)
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<List<CardDto>> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var headers = new HttpHeaders();
        headers.add("test", "test");

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService.sendPostRequest(cardsURI, availableCountryCodes, headers,
            parameterizedTypeReference);

        // then
        assertEquals(availableCountryCodes, result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.POST.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
        assertEquals(availableCountryCodesJson, recordedRequest.getBody().readUtf8());
        assertNotNull(recordedRequest.getHeaders().get("test"));
    }

    @Test
    void sendPutRequest_expectedPutRequestSend() throws Exception {
        // given
        var visa = new CardDto("Visa", "0123123");
        var masterCard = new CardDto("Master card", "0231231");

        var availableCountryCodes = List.of(visa, masterCard);

        var availableCountryCodesJson = objectMapper.writeValueAsString(availableCountryCodes);
        mockBackEnd.enqueue(new MockResponse()
            .setBody(availableCountryCodesJson)
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<List<CardDto>> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService.sendPutRequest(cardsURI, availableCountryCodes,
            parameterizedTypeReference);

        // then
        assertEquals(availableCountryCodes, result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.PUT.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
        assertEquals(availableCountryCodesJson, recordedRequest.getBody().readUtf8());
    }

    @Test
    void sendPutRequestWithHeaders_expectedPutRequestWithCustomHeaderSend() throws Exception {
        // given
        var visa = new CardDto("Visa", "0123123");
        var masterCard = new CardDto("Master card", "0231231");

        var availableCountryCodes = List.of(visa, masterCard);

        var availableCountryCodesJson = objectMapper.writeValueAsString(availableCountryCodes);
        mockBackEnd.enqueue(new MockResponse()
            .setBody(availableCountryCodesJson)
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<List<CardDto>> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var headers = new HttpHeaders();
        headers.add("test", "test");

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService.sendPutRequest(cardsURI, availableCountryCodes, headers,
            parameterizedTypeReference);

        // then
        assertEquals(availableCountryCodes, result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.PUT.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
        assertEquals(availableCountryCodesJson, recordedRequest.getBody().readUtf8());
        assertNotNull(recordedRequest.getHeaders().get("test"));
    }

    @Test
    void patchRequestSentWithDefaultHeadersIfPatchRequestIsSent() throws Exception {
        // given
        var visa = new CardDto("Visa", "0123123");
        var masterCard = new CardDto("Master card", "0231231");

        var availableCountryCodes = List.of(visa, masterCard);

        var availableCountryCodesJson = objectMapper.writeValueAsString(availableCountryCodes);
        mockBackEnd.enqueue(new MockResponse()
            .setBody(availableCountryCodesJson)
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<List<CardDto>> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService.sendPatchRequest(cardsURI, availableCountryCodes,
            parameterizedTypeReference);

        // then
        assertEquals(availableCountryCodes, result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.PATCH.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
        assertEquals(availableCountryCodesJson, recordedRequest.getBody().readUtf8());
    }

    @Test
    void patchRequestIsSentWithHeadersIfPatchRequestIsSentWithHeaders() throws Exception {
        // given
        var visa = new CardDto("Visa", "0123123");
        var masterCard = new CardDto("Master card", "0231231");

        var availableCountryCodes = List.of(visa, masterCard);

        var availableCountryCodesJson = objectMapper.writeValueAsString(availableCountryCodes);
        mockBackEnd.enqueue(new MockResponse()
            .setBody(availableCountryCodesJson)
            .addHeader("Content-Type", "application/json"));

        ParameterizedTypeReference<List<CardDto>> parameterizedTypeReference =
            new ParameterizedTypeReference<>() {
            };

        var headers = new HttpHeaders();
        headers.add("test", "test");

        var baseUrl = String.format("http://localhost:%s", mockBackEnd.getPort());
        var cardsURI = UriComponentsBuilder.fromHttpUrl(baseUrl + "/cards").build().toUri();

        // when
        var result = webClientService.sendPatchRequest(cardsURI, availableCountryCodes, headers,
            parameterizedTypeReference);

        // then
        assertEquals(availableCountryCodes, result);

        var recordedRequest = mockBackEnd.takeRequest();
        assertEquals(HttpMethod.PATCH.name(), recordedRequest.getMethod());
        assertNotNull(recordedRequest.getRequestUrl());
        assertEquals("cards", recordedRequest.getRequestUrl().pathSegments().get(0));
        assertEquals(availableCountryCodesJson, recordedRequest.getBody().readUtf8());
        assertNotNull(recordedRequest.getHeaders().get("test"));
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CardDto {

        private String key;
        private String value;
    }
}
