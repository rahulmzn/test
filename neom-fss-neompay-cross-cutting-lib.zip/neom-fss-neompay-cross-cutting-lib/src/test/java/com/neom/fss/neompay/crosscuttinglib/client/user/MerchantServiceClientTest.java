package com.neom.fss.neompay.crosscuttinglib.client.user;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.neom.fss.neompay.crosscuttinglib.client.user.dto.WalletProviderTokenDto;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class MerchantServiceClientTest {

    @Mock
    WebRequestSender webRequestSender;

    @InjectMocks
    private MerchantServiceClient merchantServiceClient;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(merchantServiceClient, "merchantServiceAddress", "http://test");
    }

    @Test
    void getMerchantByNullMobileNumberFailsWithNoData() {
        //given
        when(webRequestSender.sendGetRequest(any(), any(), any()))
            .thenReturn(null);

        //when
        assertThrows(ServiceException.NoData.class, () ->
            merchantServiceClient.getWalletProviderToken(null));

        //then
        verify(webRequestSender).sendGetRequest(any(), any(), any());
    }

    @Test
    void getMerchantByValidMobileNumberIsSuccess() {
        //given
        var tokenMock = new WalletProviderTokenDto();
        tokenMock.setToken("TOKEN");

        when(webRequestSender.sendGetRequest(any(), any(), any()))
            .thenReturn(tokenMock);

        //when
        WalletProviderTokenDto tokenDto = merchantServiceClient.getWalletProviderToken("123456789");

        //then
        assertNotNull(tokenDto);
        verify(webRequestSender).sendGetRequest(any(), any(), any());
    }
}