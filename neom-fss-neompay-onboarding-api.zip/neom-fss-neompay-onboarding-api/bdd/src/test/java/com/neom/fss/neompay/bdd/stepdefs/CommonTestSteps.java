package com.neom.fss.neompay.bdd.stepdefs;

import com.microservice.test.accelerator.httpservicemanager.RestRequestManager;
import com.neom.fss.neompay.bdd.util.ApiUtilManager;
import com.neom.fss.neompay.bdd.util.SharedData;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import net.minidev.json.JSONObject;

public class CommonTestSteps {

  public RestRequestManager restRequestManager;
  TestManagerContext testManagerContext;
  CommonGivenTestSteps commonGivenTestSteps;
  CommonWhenTestSteps commonWhenTestSteps;
  CommonThenTestSteps commonThenTestSteps;

  public CommonTestSteps(TestManagerContext context) {
    testManagerContext = context;
    restRequestManager = testManagerContext.getRestRequest();
    commonGivenTestSteps = new CommonGivenTestSteps(context);
    commonWhenTestSteps = new CommonWhenTestSteps(context);
    commonThenTestSteps = new CommonThenTestSteps(context);
  }



  @Given("I authenticate {string} API with {string}")
  public void iAuthenticateAPIWith(String userType, String user) throws Exception {
    commonGivenTestSteps.iHaveAPI(userType);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(user);
    commonWhenTestSteps.iCallMethodPOST("POST");
    commonThenTestSteps.httpServiceAssertion.statusCodeIs(200);
  }

  @When("I verify the payment status of the 3dsecure transaction")
  public void iVerifyThePaymentStatusOfTheDsecureTransaction() throws Exception {
    commonGivenTestSteps.iHaveAPI("paymentstatus");
    commonGivenTestSteps.iSetRequestHeader();
    JSONObject jsonObj = new JSONObject();
    jsonObj.put("sessionId",SharedData.PaymentSessionId);
    restRequestManager.setRequestBody(jsonObj.toString());
    commonWhenTestSteps.iCallMethodPOST("POST");
  }

  @Given("I make a {string} request to {string} API with request body {string}")
  public void iMakeARequestToAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonGivenTestSteps.iProvideTheBodyWithAValueOf("cardId","Saved Card");
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request to delete all cards with request body {string}")
  public void iDeleteAllCards( String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonWhenTestSteps.iCallMethodPOST("GET");
    commonWhenTestSteps.iGetTheResponse();
    commonThenTestSteps.iVerifyReponseCodeIs(200);

    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonWhenTestSteps.iDeleteAllCards(requestBody);
    commonThenTestSteps.iVerifyReponseCodeIs(200);
  }

  @Given("I make a {string} request to onboard {string} API with request body {string}")
  public void iMakeARequestToOnboardAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonGivenTestSteps.iProvideTheBodyWithAValueOf("mobileNumber","Saved MobileNumber");
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request to duplicate onboard {string} API with request body {string}")
  public void iMakeRequestToOnboardAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request to {string} API")
  public void iMakeRequestToRegenerateOtpAPIWithRequestBody(String requestType, String api) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request to {string} API {int} times")
  public void iMakeRequestToRegenerateOtpAPIWithRequestBody(String requestType, String api, int number) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    for (int i=0;i<number;i++) {
      iSetPathParametersWithOtpRefId();
      commonWhenTestSteps.iCallMethodPOST(requestType);
      if(i<5) {
        commonWhenTestSteps.iSaveGenerateOtpResponseValue("otpRefId", "otpNumber");
      }
    }
  }

  @Given("I make a {string} request to rayah applicant verification {string} API with request body {string}")
  public void iMakeRequestToRayahAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request {int} times to onboard {string} API with request body {string}")
  public void iMakeRequestToOnboardAPIWithRequestBody(String requestType,int number, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonGivenTestSteps.iProvideTheBodyWithAValueOf("mobileNumber","Saved MobileNumber");
    for (int i=0;i<number;i++) {
      commonWhenTestSteps.iCallMethodPOST(requestType);
      if(i<5) {
        commonWhenTestSteps.iSaveOnboardingGenerateOtpResponseValue("otpRefId", "otpNumber");
      }
    }
  }

  @Given("I make a {string} request to onboard {string} API with previous otpNumberAndReferenceId request body {string}")
  public void iMakeRequestToOnboardAPIWithPreviousRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonGivenTestSteps.iProvideTheBodyWithAValueOf("mobileNumber","Previous");
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request {int} times to rayah generate otp {string} API with request body {string}")
  public void iMakeRequestToRayahOtpAPIWithRequestBody(String requestType, int number, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    //commonGivenTestSteps.iProvideTheBodyWithAValueOf("iqamaId","1");
    for (int i=0;i<number;i++) {
      commonWhenTestSteps.iCallMethodPOST(requestType);
      if (i < 5) {
        commonWhenTestSteps.iSaveOnboardingGenerateOtpResponseValue("otpRefId", "otpNumber");
      }
    }
  }

  @Given("I make a {string} request to rayah generate otp {string} API with request body {string}")
  public void iMakeRequestToRayahOtpAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request to verify rayahotp {string} API with request body {string}")
  public void iMakeRequestToVerifyRayahOtpAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request to signup {string} API with request body {string}")
  public void iMakeRequestToApiWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request to appregistration onboard {string} API with request body {string}")
  public void iMakeAApplicationGenerationRequestToOnboardAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonGivenTestSteps.iProvideTheBodyWithAValueOf("otpNumberAndReferenceId","Saved otpNumberAndReferenceId");
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request to otp verify {string} API with request body {string}")
  public void iMakeVerifyOTPAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonGivenTestSteps.iProvideTheBodyWithAValueOf("otpNumberAndReferenceId","Saved otpNumberAndReferenceId");
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }
  @Given("I make a {string} request to verify rayah otp {string} API with request body {string}")
  public void iMakeAVerifyRayahOtpAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonGivenTestSteps.iProvideTheBodyWithAValueOf("otpNumberAndReferenceId","Saved otpNumberAndReferenceId");
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I make a {string} request to verify email otp {string} API with request body {string}")
  public void iMakeAVerifyEmailOtpAPIWithRequestBody(String requestType, String api, String requestBody) throws Exception{
    commonGivenTestSteps.iHaveAPI(api);
    commonGivenTestSteps.iSetRequestHeader();
    commonGivenTestSteps.iSetRequestBodyAs(requestBody);
    commonGivenTestSteps.iProvideTheBodyWithAValueOf("otpNumberAndReferenceId","Saved otpNumberAndReferenceId");
    commonWhenTestSteps.iCallMethodPOST(requestType);
  }

  @Given("I set path parameter {string} with {string}")
  public void iSetPathParameterWith(String key, String value) {
    restRequestManager.setPathParam(key, value);
  }

  @Given("I set path parameters for API {string}")
  public void iSetPathParameters(String api) throws Exception {
    ApiUtilManager apiUtilManager = new ApiUtilManager();
    apiUtilManager.getParams(api).forEach((key, value) -> restRequestManager.setPathParam(key, value));
  }

  @Given("I set path parameters with applicationId")
  public void iSetPathParametersWithApplicationId() {
    ApiUtilManager apiUtilManager = new ApiUtilManager();
    restRequestManager.setPathParam("applicationId", SharedData.ApplicationId);
  }

  @Given("I set path parameters with otpRefId")
  public void iSetPathParametersWithOtpRefId() {
    ApiUtilManager apiUtilManager = new ApiUtilManager();
    restRequestManager.setPathParam("otpRefId", SharedData.OtpRefId);
  }

  @Given("I clear path parameters")
  public void iClearPathParametersWithOtpRefId() {
    ApiUtilManager apiUtilManager = new ApiUtilManager();
    restRequestManager.getPathParam().clear();
  }


}
