package com.neom.fss.neompay.bdd.util;

import com.microservice.test.accelerator.httpservicemanager.HttpResponseManager;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import java.util.*;

public class SharedData {

    public static String CardId;
    public static String WalletId;
    public static Response GetResponse;
    public static String Payment3dSecureUrl;
    public static String SessionID;
    public static String Balance;
    public static String BalanceAfterAddFund;
    public static String UserId;
    public static String MobileNumber;
    public static String PaymentSessionId;
    public static String OtpNumber;
    public static String OtpRefId;
    public static String ResendCounter;
    public static String PreviousOtpRefId;
    public static String PreviousOtpNumber;
    public static String ResendCounterLatest;
    public static String ApplicationId;
    public static String Email;
    public static String IqamaId;

    public static String X_fapi_interaction_id;


}
