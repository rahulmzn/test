package com.neom.fss.neompay.bdd.stepdefs;

import com.google.common.collect.ImmutableMap;
import com.microservice.test.accelerator.httpservicemanager.ConfigManager;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import static com.github.automatedowl.tools.AllureEnvironmentWriter.allureEnvironmentWriter;

public class Hooks {
    private static final Logger CURL_LOG = LoggerFactory.getLogger("curl");
    private TestManagerContext testManagerContext;

    String logFolder = "apilogs";

    public Hooks(TestManagerContext context) {
        this.testManagerContext = context;
    }


    @Before()
    public void beforeScenario(Scenario scenario) throws Exception {

        if (System.getProperty("AllureEnv") == null) {
            allureEnvironmentWriter(
                    ImmutableMap.<String, String>builder()
                            .put("Environment", ConfigManager.getSystemPropertyOrSetDefault("env.type", "qaenv"))
                            .put("User", ConfigManager.getSystemPropertyOrSetDefault("user.name", "Automation"))
                            .put("project", String.valueOf(Paths.get("").toAbsolutePath().getParent()))
                            .build());
            System.setProperty("AllureEnv", "TRUE");
        }
        CURL_LOG.info("## SCENARIO: {}", scenario.getName());
        PrintStream printStream = null;
        File fileWriter;
        String scenarioID = scenario.getId();
        String[] fileName = scenarioID.split("[.;:/]");
        String dir = logFolder + "/" + fileName[4] + "/" + fileName[5];
        File featureDirectory = new File(dir);
        if (!featureDirectory.exists()) featureDirectory.mkdirs();
        fileWriter = new File(dir + "/" + fileName[5] + fileName[7] + ".log");
        if (!fileWriter.exists()) {
            try {
                fileWriter.createNewFile();
            } catch (IOException e) {
                System.out.println("file not created:" + fileWriter.getPath());
            }
        }
        try {
            printStream = new PrintStream(new FileOutputStream(fileWriter), true);
            printStream.append("Scenario Name: " + scenario.getName() + System.lineSeparator());
            testManagerContext.getHttpRequest().restConfig.setDefaultStream(printStream);
            testManagerContext.getHttpRequest().initNewSpecification();
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException("file not found");
        }
    }

    @After()
    public void afterScenario(Scenario scenario) throws Exception {
        if (scenario.isFailed()) {
            String scenarioID = scenario.getId();
            String[] fileName = scenarioID.split("[.;:/]");
            File log =
                    new File(
                            logFolder
                                    + "/"
                                    + fileName[4]
                                    + "/"
                                    + fileName[5]
                                    + "/"
                                    + fileName[5]
                                    + fileName[7]
                                    + ".log");
            byte[] byteData = new byte[0];
            try {
                byteData = Files.readAllBytes(log.toPath());
            } catch (IOException e) {
                e.printStackTrace();
            }
            scenario.embed(byteData, "text/plain");
        }
        testManagerContext.getSoftAssertions().assertAll();
    }
}
