package com.neom.fss.neompay.bdd.stepdefs;

import com.google.common.base.Strings;
import com.microservice.test.accelerator.httpservicemanager.HttpResponseManager;
import com.neom.fss.neompay.bdd.enums.ApiContext;
import com.microservice.test.accelerator.httpservicemanager.HttpRequestManager;
import com.microservice.test.accelerator.httpservicemanager.HttpServiceAssertion;
import com.microservice.test.accelerator.httpservicemanager.RestRequestManager;
import com.neom.fss.neompay.bdd.util.ApiUtilManager;
import com.microservice.test.accelerator.utils.JsonUtil;
import com.neom.fss.neompay.bdd.util.SharedData;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.restassured.path.json.JsonPath;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class CommonThenTestSteps {

  HttpServiceAssertion httpServiceAssertion;
  TestManagerContext testManagerContext;
  RestRequestManager restRequestManager;
  HttpRequestManager httpRequestManager;
  ApiUtilManager apiUtilManager;
  HttpResponseManager httpResponseManager;

  public CommonThenTestSteps(TestManagerContext context) {
    testManagerContext = context;
    this.httpServiceAssertion = new HttpServiceAssertion(testManagerContext.getHttpResponse());
    restRequestManager = testManagerContext.getRestRequest();
    httpRequestManager = testManagerContext.getHttpRequest();
    apiUtilManager = new ApiUtilManager();
    httpResponseManager= testManagerContext.getHttpResponse();
  }

  @Then("I verify response code is {int}")
  public void iVerifyReponseCodeIs(int statusCode) {
    httpServiceAssertion.statusCodeIs(statusCode);
  }

  @And("I verify fields in response")
  public void iVerifyFieldsInResponse(DataTable table) {
    table
        .asMap(String.class, String.class)
        .entrySet()
        .stream()
        .skip(1)
        .forEach(
            (entry) -> {
              httpServiceAssertion.bodyContainsPropertyWithValue(
                  (String) entry.getKey(),
                  JsonUtil.getNodeValue(
                      testManagerContext.getScenarioContext().getContext(ApiContext.REQUEST_BODY).toString(),
                      (String) entry.getValue()));
            });
  }

  @And("I verify {string} in Response")
  public void iVerifyResponse(String customer) {
    String request = (String) testManagerContext.getScenarioContext().getContext(ApiContext.RESPONSE_BODY);
    Map<String, Object> map = apiUtilManager.getSchema(customer, (String) testManagerContext.getScenarioContext().getContext(ApiContext.API_NAME));
    map.forEach((key, value) -> {
        httpServiceAssertion.bodyContainsPropertyWithValue(key,
                JsonUtil.getNodeValue(request, (String) value));
    });
  }

  @And("I verify empty Response")
  public void iVerifyEmptyResponse() {
    String response = (String) testManagerContext.getScenarioContext().getContext(ApiContext.RESPONSE_BODY);
    MatcherAssert.assertThat("Response is not Empty. Response :"+response,response.equals("{}"));
  }


  @And("I clear the request body")
  public void iClearTheRequestBody() {
    restRequestManager.clearRequestBody();
    httpRequestManager.body("");
  }

  @And("I clear the request headers")
  public void iClearTheRequestHeaders() throws IOException {
    restRequestManager.clearRequestHeader();
  }

  @And("I clear the query parameters")
  public void iClearTheQueryParameters() {
    restRequestManager.clearRequestParam();
  }

  @And("I validate response against the {string}")
  public void iValidateReponseAgainstTheSchema(String schema) {
    httpServiceAssertion.validateTheJsonResponseSchema("schemas/"+schema);
  }

  @And("I verify the {string} is set to {string}")
  public void iVerifyTheIsSetTo(String arg0, String arg1) {
    httpServiceAssertion.bodyContainsPropertyWithValue(arg0, arg1);
  }

  @And("I verify {string} key in Response")
  public void iVerifyKeyInResponse(String arg0) throws InterruptedException {
    httpServiceAssertion.bodyContainskey(arg0);
  }

  @And("I verify that {string} fund added to {string}")
  public void iVerifyTheBalanceAfterAddFund(String arg0, String arg1) {
    double finalBalance= Double.parseDouble(arg0)+Double.parseDouble(SharedData.Balance);
    DecimalFormat format = new DecimalFormat("0.##");
    String balance= format.format(finalBalance);

    JsonPath actualResponse = this.httpResponseManager.getResponse().jsonPath();
    String propertyValueFromResponse = null;
    if (!Strings.isNullOrEmpty(actualResponse.getString(arg1))) {
      propertyValueFromResponse = actualResponse.getString(arg1).replaceAll("\\[", "").replaceAll("\\]", "");
    }

     propertyValueFromResponse= format.format(finalBalance);

    String assertionReason = String.format("Response field '%s' value is not equal to '%s' value.", balance, propertyValueFromResponse);

    MatcherAssert.assertThat(assertionReason,balance.equals(propertyValueFromResponse));

   // httpServiceAssertion.bodyContainsPropertyWithValue(arg1, balance);
  }

  @And("I wait for {int} seconds")
  public void iWaitForSeconds(int timeinSeconds) throws InterruptedException {
    TimeUnit.MINUTES.sleep(timeinSeconds);
  }

    @And("I save the response header parameter {string}")
    public void iSaveTheResponseHeaderParameter(String X_fapi_interaction_id) {
      SharedData.X_fapi_interaction_id = this.httpResponseManager.getResponse().getHeader(X_fapi_interaction_id);
    }
}
