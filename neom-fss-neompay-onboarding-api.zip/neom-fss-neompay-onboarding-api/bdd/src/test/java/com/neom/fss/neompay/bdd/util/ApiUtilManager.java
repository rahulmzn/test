package com.neom.fss.neompay.bdd.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Strings;
import com.google.gson.JsonObject;
import com.microservice.test.accelerator.constants.ConfigConstants;
import com.neom.fss.neompay.bdd.constants.Entity;
import com.neom.fss.neompay.bdd.constants.FilePaths;
import com.neom.fss.neompay.bdd.enums.ApiContext;
import com.neom.fss.neompay.bdd.stepdefs.TestManagerContext;
import com.microservice.test.accelerator.utils.DateUtils;
import com.microservice.test.accelerator.utils.YamlReaderUtils;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class ApiUtilManager {

    private static final Logger logger = LoggerFactory.getLogger(ApiUtilManager.class);
    public String request;

    public String env = System.getProperty(ConfigConstants.ENV_TYPE).split("_")[0];

    public String getRequestBody(TestManagerContext testManagerContext, String customer)
            throws IOException, URISyntaxException, ParseException {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        ObjectMapper mapper = new ObjectMapper();
        String api = (String) testManagerContext.getScenarioContext().getContext(ApiContext.API_NAME);
        ObjectNode defaults =
                mapper.readValue(
                        new File(
                                getClass()
                                        .getResource(
                                                FilePaths.API_PATH_REQUEST_JSON
                                                        .replaceAll(Entity.API_PATH, api.toLowerCase())
                                                        .replaceAll(Entity.ENV_TYPE, env))
                                        .toURI()),
                        ObjectNode.class);
        if (!Strings.isNullOrEmpty(customer)) {
            ObjectReader updater = mapper.readerForUpdating(defaults.get(Entity.REQUEST));
            ObjectMapper jsonWriter = new ObjectMapper();
            request = updater.readTree(jsonWriter.writeValueAsString(getData(customer, api))).toString();
        } else {
            request = mapper.readTree(mapper.writeValueAsString(defaults.get(Entity.REQUEST))).toString();
        }
        return request
                .replaceAll("\\{RandomString}", getRandomAlphaString())
                .replaceAll(
                        "\\{ID}",
                        (String) testManagerContext.getScenarioContext().getContext(ApiContext.ID))
                .replaceAll("\\{RandomUUID}", getUniqueCorrelationid())
                .replaceAll("\\{currentdate}", DateUtils.getTodayDateInString());
    }

    public Map<String, String> getHeader(String api, String userId)
            throws IOException, URISyntaxException {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode defaults =
                mapper.readValue(
                        new File(
                                getClass()
                                        .getResource(
                                                FilePaths.API_PATH_REQUEST_JSON
                                                        .replaceAll(Entity.API_PATH, api.toLowerCase())
                                                        .replaceAll(Entity.ENV_TYPE, env))
                                        .toURI()),
                        ObjectNode.class);
        return mapper.convertValue(
                defaults.get(Entity.HEADER), new TypeReference<Map<String, String>>() {
                });
    }

    public String getBasePath(String api) throws IOException, URISyntaxException {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode defaults =
                mapper.readValue(
                        new File(
                                getClass()
                                        .getResource(
                                                FilePaths.API_PATH_REQUEST_JSON
                                                        .replaceAll(Entity.API_PATH, api.toLowerCase())
                                                        .replaceAll(Entity.ENV_TYPE, env))
                                        .toURI()),
                        ObjectNode.class);
        return getJsonNodeValue(defaults, Entity.BASE_PATH);
    }

    public void setEntityHostURI(String api, TestManagerContext testManagerContext)
            throws IOException, URISyntaxException {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode defaults =
                mapper.readValue(
                        new File(
                                getClass()
                                        .getResource(
                                                FilePaths.API_PATH_REQUEST_JSON
                                                        .replaceAll(Entity.API_PATH, api.toLowerCase())
                                                        .replaceAll(Entity.ENV_TYPE, env))
                                        .toURI()),
                        ObjectNode.class);
        String entity_host_uri = testManagerContext.configManager.getEnvProperty(ConfigConstants.ENTITY_HOST_URI);
        if (!Strings.isNullOrEmpty(entity_host_uri)) {
            testManagerContext.configManager.put(ConfigConstants.ENTITY_HOST_URI, "");
        }

        entity_host_uri = getJsonNodeValue(defaults, Entity.HOST_URI);

        if (!Strings.isNullOrEmpty(entity_host_uri)) {
            testManagerContext.configManager.put(ConfigConstants.ENTITY_HOST_URI, entity_host_uri);
        }
    }

    public Object getData(String customer, String api) {
        String filePath =
                FilePaths.TEST_DATA_FILE_PATH
                        .replaceAll(Entity.API_PATH, api.toLowerCase())
                        .replaceAll(Entity.ENV_TYPE, env);
        YamlReaderUtils yamlReaderUtils = new YamlReaderUtils(ClassLoader.getSystemResourceAsStream(filePath));
        return yamlReaderUtils.getValue(customer);
    }

    public Map<String, String> getParams(String api) throws IOException, URISyntaxException {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode defaults =
                mapper.readValue(
                        new File(
                                getClass()
                                        .getResource(
                                                FilePaths.API_PATH_REQUEST_JSON
                                                        .replaceAll(Entity.API_PATH, api.toLowerCase())
                                                        .replaceAll(Entity.ENV_TYPE, env))
                                        .toURI()),
                        ObjectNode.class);

        return mapper.convertValue(
                defaults.get(Entity.PARAMS), new TypeReference<Map<String, String>>() {
                });
    }

    public Map<String, Object> getSchema(String schemaKey, String api) {
        String filePath =
                FilePaths.SCHEMA_MAPPING
                        .replaceAll(Entity.API_PATH, api.toLowerCase())
                        .replaceAll(Entity.ENV_TYPE, env);
        YamlReaderUtils yamlReaderUtils = new YamlReaderUtils(ClassLoader.getSystemResourceAsStream(filePath));
        return yamlReaderUtils.getYamlObj(schemaKey);
    }

    public String getValue(String schemaKey, String api) {
        String filePath = FilePaths.SCHEMA_MAPPING.replaceAll(Entity.API_PATH, api.toLowerCase()).replaceAll(Entity.ENV_TYPE, env);
        YamlReaderUtils yamlReaderUtils = new YamlReaderUtils(ClassLoader.getSystemResourceAsStream(filePath));
        return (String) yamlReaderUtils.getValue(schemaKey);
    }

    public List<String> getListValue(String schemaKey, String api) {
        String filePath = FilePaths.SCHEMA_MAPPING.replaceAll(Entity.API_PATH, api.toLowerCase()).replaceAll(Entity.ENV_TYPE, env);
        YamlReaderUtils yamlReaderUtils = new YamlReaderUtils(ClassLoader.getSystemResourceAsStream(filePath));
        return (List<String>) yamlReaderUtils.getList(schemaKey);
    }

    public static String getJsonNodeValue(String jsonString, String nodeKey) throws IOException {
        String value = null;
        ObjectMapper mapper = new ObjectMapper();
        JsonNode data = mapper.readTree(jsonString);
        JsonNode node = data;
        if (data.isArray()) {
            if (data.size() == 0) {
                return null;
            } else if (data.size() == 1) {
                node = data.get(0);
            } else {
                //                logger.atWarning().log(
                //                        "Node array is %s and has more than one elements. Returning first
                // element.", data.asText());
                node = data.get(0);
            }
        }
        if (nodeKey.contains("/")) {
            value = node.at(nodeKey) == null ? null : node.at(nodeKey).asText();
        } else {
            value = node.get(nodeKey) == null ? null : node.get(nodeKey).asText();
        }
        return value;
    }

    public String getJsonNodeValue(JsonNode data, String nodeKey) {
        String value = null;
        JsonNode node = data;
        if (data.isArray()) {
            if (data.size() == 0) {
                return null;
            } else if (data.size() == 1) {
                node = data.get(0);
            } else {
                //                logger.atWarning().log(
                //                        "Node array is %s and has more than one elements. Returning first
                // element.", data.asText());
                node = data.get(0);
            }
        }

        if (nodeKey.contains("/")) {
            value = node.at(nodeKey) == null ? null : node.at(nodeKey).asText();
        } else {
            value = node.get(nodeKey) == null ? null : node.get(nodeKey).asText();
        }
        return value;
    }

    public String getUniqueCorrelationid() {
        return UUID.randomUUID().toString();
    }

    public String getRandomAlphaString() {
        int length = 10;
        String candidateChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvxyz";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(candidateChars.charAt(random.nextInt(candidateChars.length())));
        }
        return sb.toString();
    }

    public int getRandomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }

    public String getRandomNumbers() {
        var getNumber = (int) Math.floor(1000000 + Math.random() * 9000);
        return String.valueOf(getNumber);
    }

    public WebDriver getDriver() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");
        options.addArguments("--disable-gpu", "--window-size=1920,1200", "--ignore-certificate-errors", "--disable-extensions", "--no-sandbox", "--disable-dev-shm-usage");
        WebDriver driver = new ChromeDriver(options);
        return driver;
    }

    public String getSessionID() {
        WebDriver driver = null;
        String sessionID = "";
        try {
            By password = By.id("password");
            By submit = By.id("txtButton");
            driver = getDriver();
            driver.get(SharedData.Payment3dSecureUrl);
            if (isPasswordScreenDisplayed(driver)) {
                driver.switchTo().frame("cko-3ds2-iframe");
                enterText(driver, password, "Checkout1!");
                click(driver, submit);
                driver.switchTo().defaultContent();
            }
            String getUrl = getSessionIdFromUrl(driver);
            sessionID = getUrl.substring(getUrl.lastIndexOf("=") + 1).trim();
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            if (driver != null)
                driver.close();
            driver.quit();
        }
        System.out.println("Browser SessionID : " + sessionID);
        return sessionID;
    }

    public String getSessionIdForfrictionlessFlow() {
        WebDriver driver = null;
        String sessionID = "";
        try {
            driver = getDriver();
            driver.get(SharedData.Payment3dSecureUrl);
            String getUrl = getSessionIdFromUrl(driver);
            sessionID = getUrl.substring(getUrl.lastIndexOf("=") + 1);
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            if (driver != null)
                driver.close();
            driver.quit();
        }
        return sessionID;
    }

    public void waitElementToBeClickable(WebDriver driver, By locator) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public String getSessionIdFromUrl(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.urlContains("sid_"));
        return driver.getCurrentUrl();
    }

    public void click(WebDriver driver, By locator) {
        getElement(driver, locator).click();
    }

    public WebElement getElement(WebDriver driver, By locator) {
        waitElementToBeClickable(driver, locator);
        return driver.findElement(locator);
    }

    public void enterText(WebDriver driver, By locator, String value) {
        getElement(driver, locator).click();
        getElement(driver, locator).sendKeys(value);
    }

    public boolean isPasswordScreenDisplayed(WebDriver driver) {
        By locator = By.name("cko-3ds2-iframe");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        int size = driver.findElements(locator).size();
        if (size > 0) {
            return true;
        }
        return false;
    }

    public String getRequest(String request, String nickName) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("cardId", json.get("cardId"), SharedData.CardId);
        json.replace("walletId", json.get("walletId"), SharedData.WalletId);
        json.replace("nickName", json.get("nickName"), nickName);
        return json.toString();
    }

    public String getCardAndWallet(String request) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("cardId", json.get("cardId"), SharedData.CardId);
        json.replace("walletId", json.get("walletId"), SharedData.WalletId);
        return json.toString();
    }

    public String getCardID(String request) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("cardId", json.get("cardId"), SharedData.CardId);
        return json.toString();
    }

    public String getWalletID(String request) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("walletId", json.get("walletId"), SharedData.WalletId);
        return json.toString();
    }

    public String getUpdatedSessionID(String request) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("sessionId", json.get("sessionId"), SharedData.SessionID);
        return json.toString();
    }

    public String getBalanceRequest(String request, String balance) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        String transaction = json.get("transactionAmount").toString();
        JSONObject json1 = (JSONObject) parser.parse(transaction);
        json1.replace("amount", json1.get("amount"), balance);
        json.put("transactionAmount", json1);
        return json.toString();
    }

    public String getMobileNumber(String request) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        return json.get("mobileNo").toString();
    }

    public String updateMobileNumber(String request, String mobileNumber) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("mobileNumber", json.get("mobileNumber"), mobileNumber);
        return json.toString();
    }

    public String updateUserName(String request, String mobileNumber) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("username", json.get("username"), mobileNumber);
        return json.toString();
    }
    public String updateIqamaId(String request, String mobileNumber) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("iqamaId", json.get("iqamaId"), mobileNumber);
        return json.toString();
    }

    public String updateLogId(String request, String mobileNumber) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("logId", json.get("logId"), mobileNumber);
        return json.toString();
    }

    public String updateOtpNumber_RefId(String request, String otpNumber, String otpRefId) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("otpRefId", json.get("otpRefId"), otpRefId);
        json.replace("otpNumber", json.get("otpNumber"), otpNumber);
        return json.toString();
    }

    public String updateOtpRefId(String request, String otpRefId) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        json.replace("otpRefId", json.get("otpRefId"), otpRefId);
        return json.toString();
    }

    public String updateRandomEmailID(String request, String email) throws org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();
        JSONObject json = (JSONObject) parser.parse(request);
        if (email.equalsIgnoreCase("RANDOMEMAIL")) {
            json.replace("email", json.get("email"), new ApiUtilManager().getRandomAlphaString() + "@mail.com");
        } else {
            json.replace("email", json.get("email"), email);
        }
        SharedData.Email = json.get("email").toString();
        return json.toString();
    }


}
