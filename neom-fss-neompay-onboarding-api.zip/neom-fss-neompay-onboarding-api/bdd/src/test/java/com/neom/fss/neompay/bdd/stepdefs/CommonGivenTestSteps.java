package com.neom.fss.neompay.bdd.stepdefs;

import com.google.common.base.Strings;
import com.neom.fss.neompay.bdd.constants.Entity;
import com.neom.fss.neompay.bdd.constants.Headers;
import com.neom.fss.neompay.bdd.enums.ApiContext;
import com.microservice.test.accelerator.httpservicemanager.RestRequestManager;
import com.neom.fss.neompay.bdd.util.ApiUtilManager;
import com.neom.fss.neompay.bdd.util.SharedData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;

public class CommonGivenTestSteps {

    public RestRequestManager restRequestManager;
    TestManagerContext testManagerContext;

    public CommonGivenTestSteps(TestManagerContext context) {
        testManagerContext = context;
        restRequestManager = testManagerContext.getRestRequest();
    }

    @Given("I have API {string}")
    public void iHaveAPI(String apiName) throws IOException, URISyntaxException {
        testManagerContext.getScenarioContext().setContext(ApiContext.API_NAME, apiName);
        ApiUtilManager apiUtilManager = new ApiUtilManager();
        String basePath = apiUtilManager.getBasePath((String) testManagerContext.getScenarioContext().getContext(ApiContext.API_NAME));
        testManagerContext.getScenarioContext().setContext(ApiContext.BASE_PATH, basePath);
        apiUtilManager.setEntityHostURI(apiName, testManagerContext);
        restRequestManager.clearRequestBody();
        restRequestManager.clearRequestHeader();
    }


    @And("^I set content-type as (.+)$")
    public void content_Type(String contentType) {
        restRequestManager.contentType(ContentType.valueOf(contentType).withCharset("utf-8"));
    }

    @And("I set request body for {string}")
    public void iSetRequestBodyAs(String customer) throws IOException, URISyntaxException, ParseException {
        ApiUtilManager apiUtilManager = new ApiUtilManager();
        restRequestManager.setRequestBody(apiUtilManager.getRequestBody(testManagerContext, customer));
        testManagerContext.getScenarioContext().setContext(ApiContext.REQUEST_BODY, restRequestManager.getRequestBody());
    }


    @Given("I set header {string} with a value of {string}")
    public void iProvideTheHeaderWithAValueOf(String name, String value) {
        if(value.equalsIgnoreCase("X-fapi-interaction-id"))
        {
            value = SharedData.X_fapi_interaction_id;
        }
        restRequestManager.setRequestHeader(name, value);
        testManagerContext.getScenarioContext().setContext(ApiContext.BRAND_HEADER, restRequestManager.getHeader().get(Headers.COMMON_HEADERS));
        String access_token = (String) testManagerContext.getScenarioContext().getContext(ApiContext.ACCESS_TOKEN);
        String apiName = (String) (testManagerContext.getScenarioContext().getContext(ApiContext.API_NAME));
        Boolean isAuthAPI = apiName.contains(Entity.AUTH_API);


        if (!Strings.isNullOrEmpty(access_token)) {
            restRequestManager.setRequestHeader("Authorization", "Bearer " + access_token);
        }
    }

    @Given("I set body {string} with a value of {string}")
    public void iProvideTheBodyWithAValueOf(String name, String value) throws IOException, URISyntaxException, ParseException, org.json.simple.parser.ParseException {

        String requestBody = testManagerContext.getScenarioContext().getContext(ApiContext.REQUEST_BODY).toString();
        System.out.println(requestBody);
        if (name.equalsIgnoreCase("cardId")) {

            requestBody = new ApiUtilManager().getCardID(requestBody);
            requestBody = requestBody.replaceAll("\\\\", "");
            System.out.println(requestBody);
        } else if (name.equalsIgnoreCase("walletID")) {

            requestBody = new ApiUtilManager().getWalletID(requestBody);
        } else if (name.equalsIgnoreCase("sessionID")) {
            requestBody = new ApiUtilManager().getUpdatedSessionID(requestBody);
        } else if (name.equalsIgnoreCase("NickName")) {
            String getupdatedRequestBody = new ApiUtilManager().getRequest(requestBody, value);
            requestBody = getupdatedRequestBody;
        } else if (name.equalsIgnoreCase("Balance")) {
            String getupdatedRequestBody = new ApiUtilManager().getBalanceRequest(requestBody, value);
            requestBody = getupdatedRequestBody;
        } else if (name.equalsIgnoreCase("mobileNumber")) {
            String mobileNumber = "96655" + new ApiUtilManager().getRandomNumbers();
            SharedData.MobileNumber = mobileNumber;
            String getupdatedRequestBody = new ApiUtilManager().updateMobileNumber(requestBody, mobileNumber);
            requestBody = getupdatedRequestBody;
        } else if (name.equalsIgnoreCase("iqamaId")) {
            if (value.equals("1")) {
                String mobileNumber = "100" + new ApiUtilManager().getRandomNumbers();
                String getupdatedRequestBody = new ApiUtilManager().updateIqamaId(requestBody, mobileNumber);
                requestBody = getupdatedRequestBody;
            } else {
                String mobileNumber = "200" + new ApiUtilManager().getRandomNumbers();
                String getupdatedRequestBody = new ApiUtilManager().updateIqamaId(requestBody, mobileNumber);
                requestBody = getupdatedRequestBody;
            }
        } else if (name.equalsIgnoreCase("logId")) {
            if (value.equals("UNIQUE_EXPAT")) {
                String mobileNumber = "200" + new ApiUtilManager().getRandomNumbers();
                String getupdatedRequestBody = new ApiUtilManager().updateLogId(requestBody, mobileNumber);
                SharedData.IqamaId = mobileNumber;
                requestBody = getupdatedRequestBody;
            } else if (value.equals("UNIQUE_KSA")) {
                String mobileNumber = "100" + new ApiUtilManager().getRandomNumbers();
                String getupdatedRequestBody = new ApiUtilManager().updateLogId(requestBody, mobileNumber);
                SharedData.IqamaId = mobileNumber;
                requestBody = getupdatedRequestBody;
            } else {
                SharedData.IqamaId = value;
                requestBody = requestBody.replaceAll(name, value);
            }
        } else if (name.equalsIgnoreCase("otpNumberAndReferenceId") && value.contains("Previous")) {
            String otpNumberAndReferenceId = new ApiUtilManager().updateOtpNumber_RefId(requestBody, SharedData.PreviousOtpNumber, SharedData.PreviousOtpRefId);
            requestBody = otpNumberAndReferenceId;
        } else if (name.equalsIgnoreCase("otpNumberAndReferenceId") && !(value.contains("Previous"))) {
            String otpNumberAndReferenceId = new ApiUtilManager().updateOtpNumber_RefId(requestBody, SharedData.OtpNumber, SharedData.OtpRefId);
            requestBody = otpNumberAndReferenceId;
        } else if (name.equalsIgnoreCase("email")) {
            String getupdatedRequestBody = new ApiUtilManager().updateRandomEmailID(requestBody, value);
            requestBody = getupdatedRequestBody;
            System.out.println(requestBody);
        } else {
            requestBody = requestBody.replaceAll(name, value);
        }

        restRequestManager.setRequestBody(requestBody);
        testManagerContext.getScenarioContext().setContext(ApiContext.REQUEST_BODY, requestBody);

    }

    @And("I set request header")
    public void iSetRequestHeader() throws IOException, URISyntaxException {
        ApiUtilManager apiUtilManager = new ApiUtilManager();

        restRequestManager.setRequestHeader(apiUtilManager.getHeader((String) testManagerContext.getScenarioContext().getContext(ApiContext.API_NAME),
                (String) testManagerContext.getScenarioContext().getContext(ApiContext.ID)));
        String access_token = (String) testManagerContext.getScenarioContext().getContext(ApiContext.ACCESS_TOKEN);
        String apiName = (String) (testManagerContext.getScenarioContext().getContext(ApiContext.API_NAME));
        Boolean isAuthAPI = apiName.contains(Entity.AUTH_API);

        if (!Strings.isNullOrEmpty(access_token)) {
            restRequestManager.setRequestHeader("Authorization", "Bearer " + access_token);
        }
    }

    @And("I set parameter {string} with a value of {string}")
    public void iSetParameterWithAValueOf(String name, String value) {
        restRequestManager.setRequestParam(name, value);
    }

    @And("I set form parameter {string} with a value of {string}")
    public void iSetFormParameterWithAValueOf(String name, String value) {
        if (name.equalsIgnoreCase("username") && value.toLowerCase().contains("save")) {
            restRequestManager.formParam(name, SharedData.MobileNumber);
        } else if (name.equalsIgnoreCase("mobileNo")) {
            restRequestManager.formParam("mobileNo", SharedData.MobileNumber);
        } else if (name.equalsIgnoreCase("idValue")) {
            restRequestManager.formParam("idValue", SharedData.ApplicationId);
        } else {
            restRequestManager.formParam(name, value);
        }
        System.out.println(restRequestManager.getFormParam());
    }

    @And("I set form with file upload {string}")
    public void iSetFormParameterWithfileupload(String value) throws IOException {
        FileInputStream input = new FileInputStream(new File("src/test/resources/testPDF.pdf").getAbsolutePath());
//        File file = new File("./bdd/src/test/resources/testPDF.pdf");
        restRequestManager.multiPart(input.readAllBytes(), "testPDF.pdf", "application/pdf");
        System.out.println(restRequestManager.getFormParam());

    }

    @And("I update {string} with saved data {string}")
    public void iUpdateParameterWithAValueOf(String name, String value) throws org.json.simple.parser.ParseException {

        String requestBody = testManagerContext.getScenarioContext().getContext(ApiContext.REQUEST_BODY).toString();
        System.out.println(requestBody);
        if (name.equalsIgnoreCase("logId")) {
            requestBody = new ApiUtilManager().updateIqamaId(requestBody, SharedData.IqamaId);
            System.out.println(requestBody);
        } else if (name.equalsIgnoreCase("username")) {
            String getupdatedRequestBody = new ApiUtilManager().updateUserName(requestBody, SharedData.MobileNumber);
            requestBody = getupdatedRequestBody;
        } else if (name.equalsIgnoreCase("OtpRefId")) {
            String getupdatedRequestBody = new ApiUtilManager().updateOtpRefId(requestBody, SharedData.OtpRefId);
            requestBody = getupdatedRequestBody;
        } else {
            requestBody = requestBody.replaceAll(name, value);
        }
        System.out.println(requestBody);
        restRequestManager.setRequestBody(requestBody);
        testManagerContext.getScenarioContext().setContext(ApiContext.REQUEST_BODY, requestBody);

    }

    @And("I set the new correlationId in header")
    public void iSetTheNewCorrelationIdInHeader() {
        ApiUtilManager apiUtilManager = new ApiUtilManager();
        restRequestManager.setRequestHeader("x-txn-correlation-id", apiUtilManager.getUniqueCorrelationid());
    }
/*
  @Given("I authenticate {string} API with {string}")
  public void iAuthenticateAPIWith(String userType, String user) throws IOException, URISyntaxException, ParseException{
    iHaveAPI(userType);
    iSetRequestHeader();
    iSetRequestBodyAs(user);
  }

 */
}
