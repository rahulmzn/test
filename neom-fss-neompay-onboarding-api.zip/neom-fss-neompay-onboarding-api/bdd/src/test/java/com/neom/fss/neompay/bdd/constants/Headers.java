package com.neom.fss.neompay.bdd.constants;

public class Headers {

  public static final String COMMON_HEADERS = "headers";
}
