package com.neom.fss.neompay.bdd.stepdefs;

import com.microservice.test.accelerator.httpservicemanager.HttpServiceAssertion;
import com.neom.fss.neompay.bdd.enums.ApiContext;
import com.microservice.test.accelerator.httpservicemanager.HttpResponseManager;
import com.microservice.test.accelerator.httpservicemanager.RestRequestManager;
import com.neom.fss.neompay.bdd.util.ApiUtilManager;
import com.neom.fss.neompay.bdd.util.SharedData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import org.hamcrest.MatcherAssert;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

public class CommonWhenTestSteps {

  HttpResponseManager httpResponseManager;
  TestManagerContext testManagerContext;
  RestRequestManager restRequestManager;
  HttpServiceAssertion httpServiceAssertion;


  public CommonWhenTestSteps(TestManagerContext context) {
    testManagerContext = context;
    httpResponseManager = testManagerContext.getHttpResponse();
    restRequestManager = testManagerContext.getRestRequest();
  }

  @When("^the client performs (.+) request on API \"(.+)\"$")
  public void perform_Http_Request(String httpMethod, String url) throws Throwable {
    httpResponseManager.setResponsePrefix("");
    ApiUtilManager apiUtilManager = new ApiUtilManager();
    httpResponseManager.setReponse(httpResponseManager.doRequest(httpMethod, apiUtilManager.getBasePath(url)));
  }

  @When("I call method (.+)")
  public void iCallMethodPOST(String httpMethod) throws Exception {
    httpResponseManager.setResponsePrefix("");
    String basePath = (String) testManagerContext.getScenarioContext().getContext(ApiContext.BASE_PATH);
    basePath= basePath.replaceAll("walletID",SharedData.WalletId).replaceAll("cardID",SharedData.CardId).replaceAll("MobileNumber",SharedData.MobileNumber);
    httpResponseManager.setReponse(httpResponseManager.doRequest(httpMethod, basePath));
   }

  @And("I call GET method with {string} Mobile Number")
  public void iCallGETMethodUsingMobileNumber(String number) throws Exception {
    httpResponseManager.setResponsePrefix("");
    String mobileNumber;
    if(number.equalsIgnoreCase("Valid")) {
      String getRequestBody = testManagerContext.getScenarioContext().getContext(ApiContext.REQUEST_BODY).toString();
      mobileNumber = new ApiUtilManager().getMobileNumber(getRequestBody);
    }
    else
    {
      mobileNumber= number;
    }
    String basePath = (String) testManagerContext.getScenarioContext().getContext(ApiContext.BASE_PATH);
    basePath= basePath.replaceAll("MobileNumber",mobileNumber);
    httpResponseManager.setReponse(httpResponseManager.doRequest("GET", basePath));
  }

  @And("I get the response")
  public void iGetTheResponse() {
    testManagerContext
        .getScenarioContext()
        .setContext(ApiContext.RESPONSE_BODY, httpResponseManager.getResponse().asString());
    System.out.println(httpResponseManager.getResponse().asString());
    SharedData.GetResponse = httpResponseManager.getResponse();

  }


    @And("I save the initial response")
    public void iSaveTheInitialResponse() {
      testManagerContext
              .getScenarioContext()
              .setContext(ApiContext.INITIAL_RESPONSE_BODY, httpResponseManager.getResponse().asString());
    }

  @And("I save the auth response {string}")
  public void iSetAuthTheResponse(String authKey) {
    String authToken= httpResponseManager.getJsonPathValue(authKey);
    testManagerContext.getScenarioContext().setContext(ApiContext.ACCESS_TOKEN, authToken);
  }

  @And("I save the balance from response {string}")
  public void iSaveBalanceFromTheResponse(String key) {
    String balance= httpResponseManager.getJsonPathValue(key);
    SharedData.Balance = balance.replaceAll("\\[", "").replaceAll("\\]","");
  }

  @And("I save the balance after add fund from response {string}")
  public void iSaveBalanceAfterAddFundFromTheResponse(String authKey) {
    String balance= httpResponseManager.getJsonPathValue(authKey);
    SharedData.BalanceAfterAddFund = balance;
  }


  @And("I save the {string} and {string} from the response")
  public void iSaveResponseValue(String key1, String key2) {
        SharedData.CardId = httpResponseManager.getJsonPathValue(key1);
        SharedData.WalletId = httpResponseManager.getJsonPathValue(key2);
    }

  @And("I save the {string} and {string} from the generateotp response")
  public void iSaveGenerateOtpResponseValue(String key1, String key2) {
    SharedData.OtpRefId = httpResponseManager.getJsonPathValue(key1);
    SharedData.OtpNumber = httpResponseManager.getJsonPathValue(key2);
  }

  @And("I save the {string} and {string} from the verify otp response")
  public void iSaveVerifyOtpResponseValue(String key1, String key2) {
    SharedData.OtpRefId = httpResponseManager.getJsonPathValue(key1);
    SharedData.OtpNumber = httpResponseManager.getJsonPathValue(key2);
  }

  @And("I save the {string} and {string} from the onboarding generateotp response")
  public void iSaveOnboardingGenerateOtpResponseValue(String key1, String key2) {
    SharedData.PreviousOtpRefId = httpResponseManager.getJsonPathValue(key1);
    SharedData.PreviousOtpNumber = httpResponseManager.getJsonPathValue(key2);
  }

  @And("I save the {string} from the generateotp response")
  public void iSaveResendCounterResponseValue(String key1) {
    SharedData.ResendCounter = httpResponseManager.getJsonPathValue(key1);
  }

  @And("I save the {string} from the AppRegistration response")
  public void iSaveAppRegistrationResponseValue(String key1) {
    SharedData.ApplicationId = httpResponseManager.getJsonPathValue(key1);
  }

  @And("I save the {string} from the verify rayah otp response")
  public void iSaveVerifyRayahOtpResponseValue(String key1) {
    SharedData.ApplicationId = httpResponseManager.getJsonPathValue(key1);
  }

  @And("I save the {string}  again from the generate response")
  public void iSaveGenerateOtpResponseValue(String key1) {
    SharedData.ResendCounterLatest = httpResponseManager.getJsonPathValue(key1);
    }


  @And("I save the {string} from the response")
  public void iSaveResponseValue(String key1) {
    SharedData.UserId = httpResponseManager.getJsonPathValue(key1);
  }

  @And("I save the {string} and {string} value from the response")
  public void iSaveResponseValueFromArray(String key1, String key2) {
    JsonPath response = httpResponseManager.getResponse().jsonPath();
    List<Map<String, Object>> list = response.get();
    SharedData.CardId = list.get(0).get(key1).toString();
    SharedData.WalletId = list.get(0).get(key2).toString();
  }


  @And("I verify valid {string} in Response")
  public void iVerifyResponseForSearchedUser(String customer) {
    JsonPath response = httpResponseManager.getResponse().jsonPath();
    String getUserId= response.getString(customer);
    MatcherAssert.assertThat("Search returned incorrect user details",getUserId.equals(SharedData.UserId));
  }


  @And("I verify {string} and {string} value in Response")
  public void iVerifyValueInResponse(String key1, String key2) {

    JsonPath response = httpResponseManager.getResponse().jsonPath();
    List<Map<String, Object>> list = response.get();
   for(Map<String, Object> map:list) {
      String getCardId = map.get(key1).toString();
      String getWalletId= map.get(key2).toString();
      if(getCardId.equals(SharedData.CardId) && getWalletId.equals(SharedData.WalletId))
      {
        MatcherAssert.assertThat(key1 +" and "+ key2+" are not present in the response",getCardId.equals(SharedData.CardId) && getWalletId.equals(SharedData.WalletId));
      }
    }
  }

  @And("I set request body for delete all active cards {string}")
  public void iDeleteAllCards(String customer) throws Exception {
    JsonPath response = SharedData.GetResponse.jsonPath();
    List<Map<String, Object>> list = response.get();;
    for(Map<String, Object> map:list) {
      String getCardId = map.get("cardId").toString();
      String getWalletId= map.get("walletId").toString();

      iSetRequestBodyAs(customer);

      String requestBody = testManagerContext.getScenarioContext().getContext(ApiContext.REQUEST_BODY).toString();
      requestBody = requestBody.replaceAll ("src_.*,", getCardId+"\",");
      requestBody = requestBody.replaceAll("\"walletId\":.[0-9]*", "\"walletId\" :" +getWalletId);
      restRequestManager.setRequestBody(requestBody);
      testManagerContext.getScenarioContext().setContext(ApiContext.REQUEST_BODY, requestBody);
      iCallMethodPOST("DELETE");
    }
  }



  public void iSetRequestBodyAs(String customer) throws IOException, URISyntaxException, ParseException {
    ApiUtilManager apiUtilManager = new ApiUtilManager();
    restRequestManager.setRequestBody(apiUtilManager.getRequestBody(testManagerContext, customer));
    testManagerContext.getScenarioContext().setContext(ApiContext.REQUEST_BODY, restRequestManager.getRequestBody());
  }

  @And("I verify {string} value in Response")
  public void iVerifyValueInResponse(String key1) {

    JsonPath response = httpResponseManager.getResponse().jsonPath();
    List<Map<String, Object>> list = response.get();
    String getCardId = list.get(0).get(key1).toString();
      if(getCardId.equals(SharedData.CardId))
      {
        MatcherAssert.assertThat(key1  +" :"+SharedData.CardId +" don't appear at top in the response",true);
      }
      else {
        MatcherAssert.assertThat(key1  +" :"+getCardId +" appear at top in the response instead of "+SharedData.CardId,false);
      }
  }

  @And("I verify {string} and {string} value not in Response")
  public void iVerifyValueNotInResponse(String key1, String key2) {

    JsonPath response = httpResponseManager.getResponse().jsonPath();
    List<Map<String, Object>> list = response.get();
    for(Map<String, Object> map:list) {
      String getCardId = map.get(key1).toString();
      String getWalletId= map.get(key2).toString();
      if(getCardId.equals(SharedData.CardId) && getWalletId.equals(SharedData.WalletId))
      {
        MatcherAssert.assertThat(key1 +" and "+ key2+" are present in the response",false);
      }
      else {
        MatcherAssert.assertThat(key1 +" and "+ key2+" are not present in the response",true);

      }
    }
  }

  @And("I verify {string} status {string} in Response for {string}")
  public void iVerifyDefaultCardValueInResponse(String key1, String key3,String key2) {

    JsonPath response = httpResponseManager.getResponse().jsonPath();
    List<Map<String, Object>> list = response.get();
    for(Map<String, Object> map:list) {
      String getCardId = map.get(key1).toString();
      String getFavouriteStatus= map.get(key2).toString();
      if(key3.equalsIgnoreCase("True")) {
        if (getCardId.equals(SharedData.CardId)) {
          MatcherAssert.assertThat(key1+" status is not " + key2+ " for "+SharedData.CardId, Boolean.parseBoolean(getFavouriteStatus));
        } else {
          MatcherAssert.assertThat(key1+" status is " + key2+ " for "+getCardId+" instead of "+SharedData.CardId, !Boolean.parseBoolean(getFavouriteStatus));
        }
      }
      else if(key3.equalsIgnoreCase("False")) {
        if (getCardId.equals(SharedData.CardId)) {
          MatcherAssert.assertThat(key1 + "status is not " + key2, !Boolean.parseBoolean(getFavouriteStatus));
        }
      }
    }
  }

  @And("I save the {string} , {string} and {string} from the response")
  public void iSaveTheAndAndFromTheResponse(String key1, String key2, String key3) {
    SharedData.CardId = httpResponseManager.getJsonPathValue(key1);
    SharedData.WalletId = httpResponseManager.getJsonPathValue(key2);
    SharedData.Payment3dSecureUrl = httpResponseManager.getJsonPathValue(key3);
  }

  @And("I get sessionID from the browser")
  public void iGetSessionID() {
    ApiUtilManager apiUtilManager = new ApiUtilManager();
    SharedData.SessionID= apiUtilManager.getSessionID();
  }

  @And("I get sessionID from the browser for frictionlessFlow")
  public void iGetSessionIdForfrictionlessFlow() {
    ApiUtilManager apiUtilManager = new ApiUtilManager();
    SharedData.SessionID= apiUtilManager.getSessionIdForfrictionlessFlow();
  }

}
