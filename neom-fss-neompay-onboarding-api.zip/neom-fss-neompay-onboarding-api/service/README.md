# Service Module

<!-- OnBoarding API -->

## About The Service Module

OnBoarding API 

## Test
Run test with jacoco
./gradlew clean test jacocoTestReport

## Build
./gradlew build

## Run 
In folder /service/build/libs
java -jar service-0.0.1-SNAPSHOT.jar

Check on
http://localhost:9081/actuator/info