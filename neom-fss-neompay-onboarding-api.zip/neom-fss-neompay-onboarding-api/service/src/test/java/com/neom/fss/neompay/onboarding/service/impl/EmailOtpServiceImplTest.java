package com.neom.fss.neompay.onboarding.service.impl;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.onboarding.client.idauth.IdAuthClient;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationResponseDto;
import com.neom.fss.neompay.onboarding.constants.OtpServiceType;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationResponse;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
 class EmailOtpServiceImplTest {


    @Mock
    private IdAuthClient idAuthClient;

    @Mock
    private ApplicationService applicationService;

    @InjectMocks
    private EmailOtpServiceImpl emailOtpService;


    @ParameterizedTest
    @CsvSource({"true,SUCCESS", "false,FAILED"})
    void shouldVerifyOtpWhenRecordIsInDatabase(boolean status, String expected) {
        OtpVerificationResponseDto responseDto = new OtpVerificationResponseDto("1234567890", status, "1234", "IQ1234", null,
                OtpServiceType.SMS, null, null, UserType.CUSTOMER,"abc@gmail.com");

        when(idAuthClient.verifyOtp(any()))
                .thenReturn(responseDto);

        Application application = new Application();
        application.setApplicationId("1");
        when(applicationService.getApplicationById(any())).thenReturn(application);

        EmailOtpVerificationRequest request = new EmailOtpVerificationRequest("12345", "123456");
        EmailOtpVerificationResponse response = emailOtpService.verifyEmail("1234567890", request);

        assertNotNull(response);

    }

    @Test
    void shouldThrowExceptionForVerifyOtpWhenNoRecordIsInDatabase() {

        when(applicationService.getApplicationById(any())).thenThrow(ServiceException.NoData.class);

        EmailOtpVerificationRequest request = new EmailOtpVerificationRequest("12345", "123456");

        Assertions.assertThrows(ServiceException.NoData.class, () -> {
            emailOtpService.verifyEmail("1234567890", request);
        });

    }

}
