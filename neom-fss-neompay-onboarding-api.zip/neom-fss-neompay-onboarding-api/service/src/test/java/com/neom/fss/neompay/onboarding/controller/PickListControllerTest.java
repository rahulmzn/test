package com.neom.fss.neompay.onboarding.controller;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.onboarding.model.Value;
import com.neom.fss.neompay.onboarding.service.PickListService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.context.MessageSource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
class PickListControllerTest {

    public static final String URL_CUSTOMER_VALUES = "/picklists/v1.0/customers";

    private MockMvc mockMvc;

    @Mock
    private PickListService pickListService;

    @InjectMocks
    private PickListController controller;

    @BeforeEach
    void setUp() {
        // MockMvc standalone approach
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
            .build();
    }

    @Test
    void shouldFetchCustomerValuesWhenValidData() throws Exception {
        Map<String, List<Value>> response  = new HashMap<>();
        Value value = new Value();
        value.setDisplayName("display_name");
        value.setId("display_id");
        response.put("dummy_key", List.of(value));

        // given
        UUID uuid = UUID.randomUUID();
        when(pickListService.picklistData()).thenReturn(response);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_CUSTOMER_VALUES)
            .header("correlationID", uuid))
            .andExpect(status().isOk());
    }
}
