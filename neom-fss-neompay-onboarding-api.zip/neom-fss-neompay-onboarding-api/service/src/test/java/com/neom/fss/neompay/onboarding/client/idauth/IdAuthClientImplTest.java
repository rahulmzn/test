package com.neom.fss.neompay.onboarding.client.idauth;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.crosscuttinglib.util.JsonHelper;
import com.neom.fss.neompay.onboarding.client.idauth.dto.GenerateOtpRequestDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpTemplateType;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationRequestDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.UserProfileRequestDto;
import com.neom.fss.neompay.onboarding.client.idauth.impl.IdAuthClientImpl;
import com.neom.fss.neompay.onboarding.constants.OtpServiceType;
import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class IdAuthClientImplTest {

    @Mock
    private WebRequestSender webRequestSender;

    @InjectMocks
    private IdAuthClientImpl idAuthClient;

    private final JsonHelper jsonHelper = new JsonHelper(new ObjectMapper());

    @Test
    void verifyOtp() {
        idAuthClient.setIdauthServiceAddress("http://service.com");
        OtpVerificationRequestDto request = new OtpVerificationRequestDto("123456", "123456");
        idAuthClient.verifyOtp(request);
        verify(webRequestSender, Mockito.atLeastOnce()).sendPostRequest(any(), any(), any(), any());
    }

    @Test
    void generateAndSendOtp() {
        idAuthClient.setIdauthServiceAddress("http://service.com");
        var request = new GenerateOtpRequestDto(
            "1234567890", OtpServiceType.RAYAH, OtpTemplateType.ONBOARD, UserType.CUSTOMER);

        idAuthClient.generateAndSendOtp(request);
        verify(webRequestSender, Mockito.atLeastOnce()).sendPostRequest(any(), any(), any(), any());
    }

    @Test
    void userProfileWithPinShouldGiveCreatedStatusOnValidRequest() throws IOException {
        idAuthClient.setIdAuthUserProfileServiceAddress("http://service.com");

        var userProfileRequest = jsonHelper
            .objectFromJsonFile("user_profile_with_pin_valid_request.json", UserProfileRequestDto.class);

        idAuthClient.createUserProfileWithPin(userProfileRequest);
        verify(webRequestSender, Mockito.atLeastOnce()).sendPostRequest(any(), any(), any(), any());
    }
}