package com.neom.fss.neompay.onboarding.service.impl;

import com.neom.fss.neompay.onboarding.model.ApplicantVerificationRequest;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationResponse;
import com.neom.fss.neompay.onboarding.repository.ApplicantRepository;
import com.neom.fss.neompay.onboarding.repository.entity.Applicant;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import com.neom.fss.neompay.onboarding.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ApplicantVerificationServiceImplTest {

    @InjectMocks
    ApplicantVerificationServiceImpl applicantVerificationService;

    @Mock
    private ApplicantRepository applicantRepository;

    @Mock
    private ApplicationService applicationService;

    @Mock
    private UserService userService;


    @Test
    void verifyApplicant() {
        ApplicantVerificationRequest request = new ApplicantVerificationRequest();
        String applicationId = "app-123";
        String iqmaId = "1234567891";
        String birthDate = "12-01-2001";

        request.setBirthDate(birthDate);
        request.setIqamaId(iqmaId);
        Application application = new Application();
        application.setApplicationId("1");

        when(applicationService.getApplicationById(any())).thenReturn(application);

        Optional<Applicant> optionalApplicant = Optional.of(new Applicant());
        Applicant dummyApplicant = new Applicant();
        dummyApplicant.setApplicationId("app-345");

        when(applicantRepository.findByApplicationId(any())).thenReturn(optionalApplicant);
        when(userService.getApplicantDummy(iqmaId, birthDate)).thenReturn(dummyApplicant);
        ApplicantVerificationResponse response = applicantVerificationService.verifyApplicant(applicationId, request);
        assertNotNull(response);
        assertEquals("1", response.getApplicationId());
    }
}
