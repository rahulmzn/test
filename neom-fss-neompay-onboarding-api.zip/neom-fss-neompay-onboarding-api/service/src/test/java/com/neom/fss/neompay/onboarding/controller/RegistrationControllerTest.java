package com.neom.fss.neompay.onboarding.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.crosscuttinglib.util.JsonHelper;
import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import com.neom.fss.neompay.onboarding.constants.OtpStatus;
import com.neom.fss.neompay.onboarding.model.RegistrationRequest;
import com.neom.fss.neompay.onboarding.model.RegistrationResponse;
import com.neom.fss.neompay.onboarding.model.SearchResponse;
import com.neom.fss.neompay.onboarding.model.SubmissionRequest;
import com.neom.fss.neompay.onboarding.model.SubmissionResponse;
import com.neom.fss.neompay.onboarding.service.RegistrationService;
import com.neom.fss.neompay.onboarding.service.UserService;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
public class RegistrationControllerTest {

    public static final String URL_APPLICATION_SUBMIT = "/registration/v1.0/applications/1122/submissions";
    public static final String URL_APPLICATION_BUSINESS_SUBMIT = "/registration/v1.0/applications/1122/business/submissions";
    public static final String URL_APPLICATION_REGISTER = "/registration/v1.0/applications";
    private final JsonHelper jsonHelper = new JsonHelper(new ObjectMapper());
    @Mock
    private RegistrationService registrationService;
    @InjectMocks
    private RegistrationController controller;
    private MockMvc mockMvc;
    private MessageSource messageSource;

    @Mock
    private UserService userService;

    public static final String URL_CONTACT_SEARCH = "/registration/v1.0/contact/search";


    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @BeforeEach
    void setUp() {
        JacksonTester.initFields(this, new ObjectMapper());
        messageSource = mock(MessageSource.class);

        // MockMvc standalone approach
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
            .build();
    }

    @Test
    void shouldOnboardApplicantWhenValidRequestSent_submission() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        SubmissionResponse response = new SubmissionResponse("1122",
            ApplicationStage.ONBOARDING_COMPLETED);

        when(registrationService.submitApplication(anyString(), any(SubmissionRequest.class)))
            .thenReturn(response);

        var createOnboardRequest = jsonHelper
            .objectFromJsonFile("applicant_submission_valid_request.json", SubmissionRequest.class);

        this.mockMvc.perform(MockMvcRequestBuilders.patch(URL_APPLICATION_SUBMIT)
            .accept(MediaType.APPLICATION_JSON)
            .content(jsonHelper.objectAsJsonData(createOnboardRequest))
            .contentType(MediaType.APPLICATION_JSON)
            .header("correlationID", uuid)
            .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isOk())
            .andDo(print())
            .andExpect(jsonPath("$.applicationId").exists())
            .andExpect(jsonPath("$.applicationId").value("1122"));
    }

    @Test
    void shouldThrowBadRequestForOnboardWhenInvalidRequestSent_registerApplicant()
        throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        var createOnboardRequest = new SubmissionRequest();
        createOnboardRequest.setEmail("johndoe@gmail.com");
        createOnboardRequest.setEmploymentStatus("Public");
        createOnboardRequest.setUserPin("123456");
        createOnboardRequest.setConfirmUserPin("123456");
        createOnboardRequest.setIncomeRange("1");
        createOnboardRequest.setPrimarySourceOfIncome("I");

        this.mockMvc.perform(MockMvcRequestBuilders.patch(URL_APPLICATION_SUBMIT)
            .accept(MediaType.APPLICATION_JSON)
            .content(jsonHelper.objectAsJsonData(createOnboardRequest))
            .contentType(MediaType.APPLICATION_JSON)
            .header("correlationID", uuid)
            .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isBadRequest());
    }

    @Test
    void shouldSearchContactWhenValidData_searchContact() throws Exception {
        SearchResponse searchResponse  = new SearchResponse();
        searchResponse.setMobile("989898987");
        // given
        UUID uuid = UUID.randomUUID();
        when(userService.contactSearch(anyString(), any(UserType.class))).thenReturn(searchResponse);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_CONTACT_SEARCH)
            .header("correlationID", uuid)
            .param("searchParam", "966534354534")
            .param("userType", UserType.CUSTOMER.name()))
            .andExpect(status().isOk());
    }

    @Test
    void shouldRegisterApplicantWhenValidRequestSent_register() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();
        RegistrationRequest request = new RegistrationRequest("otp_ref_id", "112333");
        RegistrationResponse response = new RegistrationResponse("app_id","otp_ref_id", OtpStatus.SUCCESS, 0);

        when(registrationService.registerUser(any(RegistrationRequest.class)))
            .thenReturn(response);

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_APPLICATION_REGISTER)
            .accept(MediaType.APPLICATION_JSON)
            .content(jsonHelper.objectAsJsonData(request))
            .contentType(MediaType.APPLICATION_JSON)
            .header("correlationID", uuid)
            .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isCreated())
            .andDo(print())
            .andExpect(jsonPath("$.applicationId").exists())
            .andExpect(jsonPath("$.applicationId").value("app_id"));
    }



    /*@Test
    void shouldFetchCustomerValuesWhenValidData() throws Exception {
        CustomerValuesResponse response  = new CustomerValuesResponse();
        Value value = new Value();
        value.setDisplayName("display_name");
        value.setId("display_id");
        response.setEmploymentStatusList(List.of(value));

        // given
        UUID uuid = UUID.randomUUID();
        when(registrationService.fetchCustomerValues()).thenReturn(response);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_CUSTOMER_VALUES)
            .header("correlationID", uuid))
            .andExpect(status().isOk());
    }*/
}
