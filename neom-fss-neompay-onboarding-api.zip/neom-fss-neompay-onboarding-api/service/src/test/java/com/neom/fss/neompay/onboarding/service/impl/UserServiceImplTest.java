package com.neom.fss.neompay.onboarding.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.client.user.CustomerServiceClient;
import com.neom.fss.neompay.crosscuttinglib.client.user.MerchantServiceClient;
import com.neom.fss.neompay.crosscuttinglib.client.user.dto.CustomerDto;
import com.neom.fss.neompay.crosscuttinglib.client.user.dto.ExpatCitizenDto;
import com.neom.fss.neompay.crosscuttinglib.client.user.dto.KsaCitizenDto;
import com.neom.fss.neompay.crosscuttinglib.client.user.dto.MerchantDto;
import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.crosscuttinglib.util.JsonHelper;
import com.neom.fss.neompay.onboarding.client.comviva.ComvivaClient;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ContactSearchResponseDto;
import com.neom.fss.neompay.onboarding.mapper.ApplicantMapper;
import com.neom.fss.neompay.onboarding.mapper.ComvivaMapper;
import com.neom.fss.neompay.onboarding.model.SearchResponse;
import com.neom.fss.neompay.onboarding.repository.entity.Applicant;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {
    @Mock
    private ComvivaClient comvivaClient;

    @InjectMocks
    private UserServiceImpl userService;

    @Mock
    private CustomerServiceClient customerServiceClient;

    @Mock
    private MerchantServiceClient merchantServiceClient;

    @Mock
    private ApplicantMapper applicantMapper;

    @Mock
    private ComvivaMapper comvivaMapper;

    @Test
    void shouldSearchContactForCustomerWithValidRequest() throws IOException {
        var jsonHelper = new JsonHelper(new ObjectMapper());
        var response = jsonHelper.objectFromJsonFile("comviva_search_contact_customer_valid_response.json",
                ContactSearchResponseDto.class);
        SearchResponse searchResponse = new SearchResponse();
        searchResponse.setEmailId("anb@neom.com");
        when( comvivaMapper.mapResponseDtoToSearchResponse(any())).thenReturn(searchResponse);
        when(comvivaClient.contactSearch(anyString())).thenReturn(response);

        userService.contactSearch("96655246802", UserType.CUSTOMER);
        verify(comvivaClient).contactSearch(anyString());
    }

    @Test
    void shouldSearchContactForMerchantWithValidRequest() throws IOException {
        var jsonHelper = new JsonHelper(new ObjectMapper());
        var response = jsonHelper.objectFromJsonFile("comviva_search_contact_merchant_valid_response.json",
                ContactSearchResponseDto.class);
        SearchResponse searchResponse = new SearchResponse();
        searchResponse.setEmailId("anb@neom.com");
        when(comvivaClient.contactSearch(anyString())).thenReturn(response);
        when( comvivaMapper.mapResponseDtoToSearchResponse(any())).thenReturn(searchResponse);
        userService.contactSearch("96655246800", UserType.MERCHANT);
        verify(comvivaClient).contactSearch(anyString());
    }

    @Test
    void shouldSearchContactNotAvailableWithValidRequest() throws IOException {
        var jsonHelper = new JsonHelper(new ObjectMapper());
        var response = jsonHelper.objectFromJsonFile("comviva_search_contact_merchant_valid_response.json",
                ContactSearchResponseDto.class);
        SearchResponse searchResponse = new SearchResponse();
        searchResponse.setEmailId("anb@neom.com");

        when(comvivaClient.contactSearch(anyString())).thenReturn(response);
        when( comvivaMapper.mapResponseDtoToSearchResponse(any())).thenReturn(searchResponse);

        Assertions.assertThrows(BadInput.class,
                () -> userService.contactSearch("96655246802", UserType.CUSTOMER));

    }

    @Test
    void shouldSearchContactNotMatchingWithUserTypeRequest() {
        var response = new ContactSearchResponseDto();
        response.setStatus("FAILED");

        when(comvivaClient.contactSearch(anyString())).thenReturn(response);

        Assertions.assertThrows(BadInput.class,
                () -> userService.contactSearch("96655246802", UserType.CUSTOMER));

    }

    @Test
    void customerUserTypeExistTest() {
        UserType userType = UserType.CUSTOMER;
        String mobile = "9898989876";
        CustomerDto customerDto = new CustomerDto();
        customerDto.setCustomerId("123");
        when(customerServiceClient.getCustomerByMobileNumber(mobile)).thenReturn(customerDto);
        assertTrue(userService.userExists(userType, mobile));
    }

    @Test
    void merchantUserTypeExistTest() {
        UserType userType = UserType.MERCHANT;
        String mobile = "9898989876";
        MerchantDto merchantDto = new MerchantDto();
        merchantDto.setMerchantId("123");
        when(merchantServiceClient.getMerchantByMobileNumber(mobile)).thenReturn(merchantDto);
        assertTrue(userService.userExists(userType, mobile));
    }

    @Test
    void shouldThrowExceptionWithInvalidUserTypeTest() {
        String mobile = "9898989876";
        MerchantDto merchantDto = new MerchantDto();
        merchantDto.setMerchantId("123");
        var response = assertThrows(ServiceException.BadInput.class,
                () -> userService.userExists(UserType.TOURIST, mobile));
        assertNotNull(response);
    }

    @Test
    void getDummyApplicantIfIqmaStartWith1Test() {
        String iqmaId = "2234567891";
        String birthDate = "12-01-2001";
        MerchantDto merchantDto = new MerchantDto();
        merchantDto.setMerchantId("123");
        ExpatCitizenDto expatCitizenDto = new ExpatCitizenDto();
        Applicant applicant = new Applicant();
        applicant.setApplicationId("123");
        when(applicantMapper.toEntity(expatCitizenDto)).thenReturn(applicant);
        when(customerServiceClient.getExpatCitizen(iqmaId, birthDate)).thenReturn(expatCitizenDto);
        Applicant response = userService.getApplicantDummy(iqmaId, birthDate);
        assertNotNull(response);
    }

    @Test
    void getDummyApplicantIfIqmaStartWith2Test() {
        String iqmaId = "1234567891";
        String birthDate = "12-01-2001";
        MerchantDto merchantDto = new MerchantDto();
        merchantDto.setMerchantId("123");
        KsaCitizenDto ksaCitizen = new KsaCitizenDto();
        Applicant applicant = new Applicant();
        applicant.setApplicationId("123");
        when(applicantMapper.toEntity(ksaCitizen)).thenReturn(applicant);
        when(customerServiceClient.getKsaCitizen(iqmaId, birthDate)).thenReturn(ksaCitizen);
        Applicant response = userService.getApplicantDummy(iqmaId, birthDate);
        assertNotNull(response);
    }
    @Test
    void shouldThrowExceptionWIthInvalidIqmaId() {
        String iqmaId = "3228348747";
        String birthDate = "12-01-2001";
        var response = assertThrows(ServiceException.BadInput.class,
                () -> userService.getApplicantDummy(iqmaId, birthDate));
        assertNotNull(response);
    }
}
