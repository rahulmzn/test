package com.neom.fss.neompay.onboarding.service.impl;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.onboarding.repository.ApplicationRepository;
import com.neom.fss.neompay.onboarding.repository.ApplicationStageHistoryRepository;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class ApplicationServiceImplTest {

    @Mock
    private ApplicationRepository applicationRepository;

    @Mock
    private ApplicationStageHistoryRepository applicationStageHistoryRepository;

    @InjectMocks
    ApplicationServiceImpl applicationService;

    @Test
    void getApplicationByIdTest() {

        Application application = new Application();
        application.setApplicationId("123");
        Optional<Application> optionalApplication = Optional.of(application);

        when(applicationRepository.findByApplicationId(any())).thenReturn(optionalApplication);
        Application applicationResponse = applicationService.getApplicationById("123");

        assertNotNull(applicationResponse);
        assertEquals("123", applicationResponse.getApplicationId());

    }

    @Test
    void shouldThrowExceptionIfApplicationIdIsInvalidTest() {

        Application application = new Application();
        application.setApplicationId("123");
        Optional<Application> optionalApplication = Optional.empty();

        when(applicationRepository.findByApplicationId(any())).thenReturn(optionalApplication);
        var response = assertThrows(ServiceException.NoData.class,
                () -> applicationService.getApplicationById("123"));
        //then
        assertNotNull(response);
        assertEquals("NPAY_ONBRD_10111", response.getMessage());

    }
}
