package com.neom.fss.neompay.onboarding.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.onboarding.client.comviva.dto.DocumentPayloadDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.DocumentUploadResponseDto;
import com.neom.fss.neompay.onboarding.constants.ApplicationIdType;
import com.neom.fss.neompay.onboarding.constants.DocumentType;
import com.neom.fss.neompay.onboarding.model.DocumentUploadRequest;
import com.neom.fss.neompay.onboarding.repository.MerchantDocumentRepository;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class MerchantRegistrationServiceImplTest {

    @Mock
    private WebRequestSender webRequestSender;

    @Mock
    private MerchantDocumentRepository merchantDocumentRepository;

    @Mock
    private ApplicationService applicationService;

    @InjectMocks
    private MerchantRegistrationServiceImpl merchantRegistrationService;

    @Test
    void uploadDocumentFaileForInvalidFileType() {

        //given
        var applicationId = "app123";
        var docDetails = new DocumentUploadRequest();
        docDetails.setDocType(DocumentType.COMPANY_REG_CERT);
        docDetails.setMobileNo("2321213131");
        docDetails.setFile(new MockMultipartFile("file", "test".getBytes()));

        //when
        var response = assertThrows(BadInput.class,
            () -> merchantRegistrationService.uploadDocument(docDetails, applicationId));

        //then
        assertNotNull(response);
        assertNotNull("NPAY_ONBRD_10117", response.getMessage());
        verify(merchantDocumentRepository, never()).save(any());
        verify(applicationService, never()).save(any());

    }

    @Test
    void uploadDocumentFilaedForInvalidUploadFileExtension() {

        //given
        var applicationId = "app123";
        var docDetails = new DocumentUploadRequest();
        docDetails.setDocType(DocumentType.COMPANY_REG_CERT);
        docDetails.setMobileNo("2321213131");
        docDetails.setFile(
            new MockMultipartFile("file", "test.pdf", MediaType.MULTIPART_FORM_DATA_VALUE, "test".getBytes()));
        docDetails.setFileName("test.gif");

        //when
        var response = assertThrows(BadInput.class,
            () -> merchantRegistrationService.uploadDocument(docDetails, applicationId));

        //then
        assertNotNull(response);
        assertNotNull("NPAY_ONBRD_10117", response.getMessage());
        verify(merchantDocumentRepository, never()).save(any());
        verify(applicationService, never()).save(any());
    }

    @Test
    void uploadDocumentForValidUploadDetailSuccess() throws IOException {

        //given
        var applicationId = "app123";
        var docDetails = new DocumentUploadRequest();
        docDetails.setDocType(DocumentType.COMPANY_REG_CERT);
        docDetails.setMobileNo("2321213131");
        docDetails.setFile(
            new MockMultipartFile("file", "test.pdf", MediaType.MULTIPART_FORM_DATA_VALUE, "test".getBytes()));
        docDetails.setFileName("test.pdf");
        docDetails.setIdType(ApplicationIdType.MERCHNAT_SIGNUP_APPID);

        var responseDto = new DocumentUploadResponseDto();
        var extDocId = "2131231232132";
        responseDto.setPayload(new DocumentPayloadDto("test.pdf", extDocId, "Doc uploaded successfully", null));
        responseDto.setStatus(200);

        Application application = new Application();
        application.setApplicationId(applicationId);

        ReflectionTestUtils.setField(merchantRegistrationService, "docUploadUrl", "http://localhost:9071");
        when(applicationService.getApplicationById(applicationId)).thenReturn(application);
        when(webRequestSender.sendPostRequest(any(), any(), any(), any(ParameterizedTypeReference.class))).thenReturn(
            responseDto);

        //when
        var response = merchantRegistrationService.uploadDocument(docDetails, applicationId);

        //then
        assertNotNull(response);
        assertEquals(extDocId, response.getDocumentId());
        assertEquals("SUCCESS", response.getStatus());
        verify(merchantDocumentRepository, times(1)).save(any());
        verify(applicationService, times(1)).save(any());
    }

    @Test
    void uploadDocumentFailedForValidUploadDetail() throws IOException {

        //given
        var applicationId = "app123";
        var docDetails = new DocumentUploadRequest();
        docDetails.setDocType(DocumentType.COMPANY_REG_CERT);
        docDetails.setMobileNo("2321213131");
        docDetails.setFile(
            new MockMultipartFile("file", "test.pdf", MediaType.MULTIPART_FORM_DATA_VALUE, "test".getBytes()));
        docDetails.setFileName("test.pdf");
        docDetails.setIdType(ApplicationIdType.MERCHNAT_SIGNUP_APPID);

        var extDocId = "2131231232132";

        Application application = new Application();
        application.setApplicationId(applicationId);

        ReflectionTestUtils.setField(merchantRegistrationService, "docUploadUrl", "http://localhost:9071");
        when(applicationService.getApplicationById(applicationId)).thenReturn(application);
        when(webRequestSender.sendPostRequest(any(), any(), any(), any(ParameterizedTypeReference.class))).thenReturn(
            null);

        //when
        var response = merchantRegistrationService.uploadDocument(docDetails, applicationId);

        //then
        assertNotNull(response);
        assertNull(response.getDocumentId());
        assertEquals("FAILED", response.getStatus());
    }

    @Test
    void uploadDocumentSuccessForValidUploadDetail() throws IOException {

        //given
        var applicationId = "app123";
        var docDetails = new DocumentUploadRequest();
        docDetails.setDocType(DocumentType.BENEFECIAL_OWNER);
        docDetails.setMobileNo("2321213131");
        docDetails.setFile(
            new MockMultipartFile("file", "test.pdf", MediaType.MULTIPART_FORM_DATA_VALUE, "test".getBytes()));
        docDetails.setFileName("test.pdf");
        docDetails.setIdType(ApplicationIdType.MERCHNAT_SIGNUP_APPID);

        Application application = new Application();
        application.setApplicationId(applicationId);

        var responseDto = new DocumentUploadResponseDto();
        var extDocId = "2131231232132";
        responseDto.setPayload(new DocumentPayloadDto("test.pdf", extDocId, "Doc uploaded successfully", null));
        responseDto.setStatus(200);

        ReflectionTestUtils.setField(merchantRegistrationService, "docUploadUrl", "http://localhost:9071");
        when(applicationService.getApplicationById(applicationId)).thenReturn(application);
        when(webRequestSender.sendPostRequest(any(), any(), any(), any(ParameterizedTypeReference.class))).thenReturn(
            responseDto);

        //when
        var response = merchantRegistrationService.uploadDocument(docDetails, applicationId);

        //then
        assertNotNull(response);
        assertEquals(extDocId, response.getDocumentId());
        assertEquals("SUCCESS", response.getStatus());
        verify(merchantDocumentRepository, times(1)).save(any());
        verify(applicationService, never()).save(any());
    }
}
