package com.neom.fss.neompay.onboarding.controller;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponseBuilder;
import com.neom.fss.neompay.crosscuttinglib.exception.ExceptionControllerAdvice;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.NoData;
import com.neom.fss.neompay.onboarding.constants.OtpStatus;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationResponse;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationResponse;
import com.neom.fss.neompay.onboarding.service.EmailOtpService;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
public class EmailOtpControllerTest {

    public static final String VERIFY_EMAIL_OTP_URL = "/registration/v1.0/applications/APP123/email-verifications";

    @InjectMocks
    private EmailOtpController controller;

    @Mock
    private EmailOtpService emailOtpService;

    private MockMvc mockMvc;

    private MessageSource messageSource;

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @BeforeEach
    void setUp() {
        JacksonTester.initFields(this, new ObjectMapper());
        messageSource = mock(MessageSource.class);

        // MockMvc standalone approach
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
            .setControllerAdvice(new ExceptionControllerAdvice(new ErrorResponseBuilder()))
            .build();
    }

    @Test
    void shouldVerifyOtpWhenValidRequestSent_verifyOtp() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        EmailOtpVerificationResponse emailOtpVerificationResponse = new EmailOtpVerificationResponse("123456",
            OtpStatus.SUCCESS);

        when(emailOtpService.verifyEmail(anyString(), any(EmailOtpVerificationRequest.class))).thenReturn(
            emailOtpVerificationResponse);

        String request = asJsonString(createRequest("123456", "123456"));

        this.mockMvc.perform(MockMvcRequestBuilders.patch(VERIFY_EMAIL_OTP_URL)
                .accept(MediaType.APPLICATION_JSON)
                .content(request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("correlationID", uuid)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isOk())
            .andDo(print())
            .andExpect(jsonPath("$.*", hasSize(2)))
            .andExpect(jsonPath("$.applicationId").exists());
    }

    @Test
    void validationFailsWhenInvalidRequestSent_verifyOtp() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();
        String request = asJsonString(createRequest("123456", "INVALID123456"));

        this.mockMvc.perform(MockMvcRequestBuilders.patch(VERIFY_EMAIL_OTP_URL)
                .accept(MediaType.APPLICATION_JSON)
                .content(request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("correlationID", uuid)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isBadRequest());
    }

    @Test
    void shouldThrowNotFoundExceptionWhenWrongAppIdSend_verifyOtp() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        RayahOtpVerificationResponse rayahOtpVerificationResponse = new RayahOtpVerificationResponse("123456",
            OtpStatus.FAILED);

        when(emailOtpService.verifyEmail(anyString(), any(EmailOtpVerificationRequest.class))).thenThrow(
            new ServiceException.NoData("dummy"));

        String request = asJsonString(createRequest("123456", "864201"));

        assertThatThrownBy(() -> this.mockMvc.perform(MockMvcRequestBuilders.patch(VERIFY_EMAIL_OTP_URL)
                .accept(MediaType.APPLICATION_JSON)
                .content(request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("correlationID", uuid)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isNotFound()))
            .hasCause(new NoData("dummy"));

    }

    private RayahOtpVerificationRequest createRequest(String otpRefId, String otpNumber) {
        return new RayahOtpVerificationRequest(otpRefId, otpNumber);
    }
}
