package com.neom.fss.neompay.onboarding.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.neom.fss.neompay.onboarding.model.DocumentUploadRequest;
import java.io.InputStream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class MultipartInputStreamFileResourceTest {

    @Mock
    InputStream inputStream;

    @InjectMocks
    MultipartInputStreamFileResource multipartInputStreamFileResource;

    @Test
    void getFileNameShouldReturnFileName() {
        String fileName = "test.pdf";
        var multipartinput = new MultipartInputStreamFileResource(inputStream, fileName);
        var filename = multipartinput.getFilename();
        assertEquals(fileName, filename);
    }

    @Test
    void getContentLengthReturnSuccess() {
        String fileName = "test.pdf";
        var multipartinput = new MultipartInputStreamFileResource(inputStream, fileName);
        var contentLength = multipartinput.contentLength();
        assertEquals(-1, contentLength);
    }

    @Test
    void testEquals_Symmetric() {
        String fileName = "test.pdf";
        var multipartinputX = new MultipartInputStreamFileResource(inputStream, fileName);
        var multipartinputY = new MultipartInputStreamFileResource(inputStream, fileName);
        assertTrue(multipartinputX.equals(multipartinputY) && multipartinputY.equals(multipartinputX));
        assertEquals(multipartinputX.hashCode(), multipartinputY.hashCode());

    }

    @Test
    void testSameObject() {
        String fileName = "test.pdf";
        var multipartinputX = new MultipartInputStreamFileResource(inputStream, fileName);

        assertTrue(multipartinputX.equals(multipartinputX) && multipartinputX.equals(multipartinputX));
        assertEquals(multipartinputX.hashCode(), multipartinputX.hashCode());

    }

    @Test
    void testWithNullObject() {
        String fileName = "test.pdf";
        var multipartInputX = new MultipartInputStreamFileResource(inputStream, fileName);
        assertNotEquals(null,multipartInputX);

    }

    @Test
    void testEquals_Asymmetric() {

        var multipartinputX = new MultipartInputStreamFileResource(inputStream, "fileNamex.pdf");
        var anotherObject = new DocumentUploadRequest();
        assertFalse(multipartinputX.equals(anotherObject) && anotherObject.equals(multipartinputX));
    }

}
