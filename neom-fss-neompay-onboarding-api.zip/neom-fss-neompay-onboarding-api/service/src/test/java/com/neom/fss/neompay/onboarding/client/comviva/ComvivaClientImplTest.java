package com.neom.fss.neompay.onboarding.client.comviva;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.crosscuttinglib.util.JsonHelper;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaBusinessOnboardRequestDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaOnboardRequestDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaOnboardResponseDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ContactSearchResponseDto;
import com.neom.fss.neompay.onboarding.client.comviva.impl.ComvivaClientImpl;
import com.neom.fss.neompay.onboarding.config.BackendApiPathsConfig;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.URI;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ComvivaClientImplTest {
    @Mock
    private WebRequestSender webRequestSender;

    @Mock
    private BackendApiPathsConfig backendApiPathsConfig;

    @InjectMocks
    private ComvivaClientImpl comvivaClient;

    private final JsonHelper jsonHelper = new JsonHelper(new ObjectMapper());


    @Test
    void shouldCreateUserInComvivaWithValidRequest() throws IOException {
        var request = jsonHelper
                .objectFromJsonFile("create_comviva_user.json", ComvivaOnboardRequestDto.class);
        Assertions.assertNotNull(request);
    }

    @Test
    void comvivaSelfRegistrationTest() throws IOException {
        var expectedResponse = jsonHelper
                .objectFromJsonFile("comviva_self_registration_response_dto.json", ComvivaOnboardResponseDto.class);

        when(backendApiPathsConfig.getSelfSignUpApi()).thenReturn("/v1/ums/user/self");
        when(webRequestSender.sendPostRequest(any(URI.class), any(), any()))
                .thenReturn(expectedResponse);
        ReflectionTestUtils.setField(comvivaClient, "comvivaServiceAddress",
                "http://localhost:90901");

        var responseDto = comvivaClient.comvivaSelfRegistration(new ComvivaOnboardRequestDto());
        assertEquals(expectedResponse.getStatus(), responseDto.getStatus());

    }

    @Test
    void shouldThrowErrorForInvalidComvivaSelfRegistrationTest() {
        when(webRequestSender.sendPostRequest(any(URI.class), any(), any()))
                .thenThrow(new ServiceException.ClientError("Comviva call has failed with error:"));
        when(backendApiPathsConfig.getSelfSignUpApi()).thenReturn("/v1/ums/user/self");
        ReflectionTestUtils.setField(comvivaClient, "comvivaServiceAddress",
                "http://localhost:90901");
        assertThrows(
                ServiceException.ClientError.class,
                () -> comvivaClient.comvivaSelfRegistration(new ComvivaOnboardRequestDto()));
    }

    @Test
    void merchantSelfRegistrationTest() throws IOException {

        var expectedResponse = jsonHelper
                .objectFromJsonFile("comviva_self_registration_response_dto.json", ComvivaOnboardResponseDto.class);

        when(backendApiPathsConfig.getMerchantSelfSignUpApi()).thenReturn("/v1/ums/user/business/self");
        when(webRequestSender.sendPostRequest(any(URI.class), any(), any()))
                .thenReturn(expectedResponse);
        ReflectionTestUtils.setField(comvivaClient, "comvivaServiceAddress",
                "http://localhost:90901");

        var responseDto = comvivaClient.merchantSelfRegistration(new ComvivaBusinessOnboardRequestDto());
        assertEquals(expectedResponse.getStatus(), responseDto.getStatus());

    }
    @Test
    void shouldThrowErrorForInvalidComvivaMerchantRegistrationTest() {
        when(webRequestSender.sendPostRequest(any(URI.class), any(), any()))
                .thenThrow(new ServiceException.ClientError("Comviva call has failed with error:"));
        when(backendApiPathsConfig.getMerchantSelfSignUpApi()).thenReturn("/v1/ums/user/business/self");
        ReflectionTestUtils.setField(comvivaClient, "comvivaServiceAddress",
                "http://localhost:90901");
        assertThrows(
                ServiceException.ClientError.class,
                () -> comvivaClient.merchantSelfRegistration(new ComvivaBusinessOnboardRequestDto()));
    }

    @Test
    void contactSearchTest() throws IOException {
        String searchParameter = "neom";

        var expectedResponse = jsonHelper
                .objectFromJsonFile("comviva_contact_search_response_dto.json", ContactSearchResponseDto.class);

        when(backendApiPathsConfig.getContactSearchUrl()).thenReturn("/v2/ums/user/search");
        when(webRequestSender.sendGetRequest(any(URI.class), any()))
                .thenReturn(expectedResponse);
        ReflectionTestUtils.setField(comvivaClient, "comvivaServiceAddress",
                "http://localhost:90901");

        var responseDto = comvivaClient.contactSearch(searchParameter);
        assertEquals(expectedResponse.getStatus(), responseDto.getStatus());
        assertEquals("1985-12-12",responseDto.getUsers().get(0).getDateOfBirth());
    }

    @Test
    void contactSearchIfResponseIsEmptyTest() {
        String searchParameter = "neom";
        ContactSearchResponseDto contactSearchResponseDto = new ContactSearchResponseDto();
        when(backendApiPathsConfig.getContactSearchUrl()).thenReturn("/v2/ums/user/search");
        when(webRequestSender.sendGetRequest(any(URI.class), any()))
                .thenReturn(contactSearchResponseDto);
        ReflectionTestUtils.setField(comvivaClient, "comvivaServiceAddress",
                "http://localhost:90901");
        var responseDto = comvivaClient.contactSearch(searchParameter);
        assertNull(responseDto.getUsers());
    }

}
