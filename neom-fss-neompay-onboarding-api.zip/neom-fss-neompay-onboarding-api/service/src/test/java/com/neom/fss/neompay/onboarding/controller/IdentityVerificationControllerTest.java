package com.neom.fss.neompay.onboarding.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponseBuilder;
import com.neom.fss.neompay.crosscuttinglib.exception.ExceptionControllerAdvice;
import com.neom.fss.neompay.onboarding.constants.OtpStatus;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationRequest;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationResponse;
import com.neom.fss.neompay.onboarding.service.ApplicantVerificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class IdentityVerificationControllerTest {

    @InjectMocks
    private IdentityVerificationController identityVerificationController;

    @Mock
    private ApplicantVerificationService applicantVerificationService;

    private MockMvc mockMvc;

    public static final String VERIFY_APPLICANT_URL = "/registration/v1.0/applications/1234/applicant-verifications";

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @BeforeEach
    void setUp() {
        JacksonTester.initFields(this, new ObjectMapper());

        // MockMvc standalone approach
        mockMvc = MockMvcBuilders.standaloneSetup(identityVerificationController)
                .setControllerAdvice(new ExceptionControllerAdvice(new ErrorResponseBuilder()))
                .build();
    }

    @Test
    void shouldVerifyApplicant() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        ApplicantVerificationResponse applicantVerificationResponse = new ApplicantVerificationResponse("123456",
                OtpStatus.SUCCESS);

        when(applicantVerificationService.verifyApplicant(anyString(), any(ApplicantVerificationRequest.class))).thenReturn(
                applicantVerificationResponse);

        ApplicantVerificationRequest applicantVerificationRequest = new ApplicantVerificationRequest("1234567891", "12-03-2021");
        String request = asJsonString(applicantVerificationRequest);

        this.mockMvc.perform(MockMvcRequestBuilders.patch(VERIFY_APPLICANT_URL)
                        .accept(MediaType.APPLICATION_JSON)
                        .content(request)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("correlationID", uuid)
                        .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
                .andExpect(status().isOk());
    }
    
}
