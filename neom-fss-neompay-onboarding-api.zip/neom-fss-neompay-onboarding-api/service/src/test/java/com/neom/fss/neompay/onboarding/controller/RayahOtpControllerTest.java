package com.neom.fss.neompay.onboarding.controller;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponseBuilder;
import com.neom.fss.neompay.crosscuttinglib.exception.ExceptionControllerAdvice;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.NoData;
import com.neom.fss.neompay.onboarding.constants.OtpStatus;
import com.neom.fss.neompay.onboarding.model.RayahOtpRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpResponse;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationResponse;
import com.neom.fss.neompay.onboarding.service.RayahOtpService;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
class RayahOtpControllerTest {

    public static final String VERIFY_RAYAH_OTP_URL = "/registration/v1.0/applications/APP123/rayah-otp-verifications";
    public static final String GENERATE_RAYAH_OTP_URL = "/registration/v1.0/applications/APP123/rayah-one-time-pins";

    @Mock
    private RayahOtpService rayahOtpService;

    @InjectMocks
    private RayahOtpController controller;

    private MockMvc mockMvc;

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @BeforeEach
    void setUp() {
        JacksonTester.initFields(this, new ObjectMapper());

        // MockMvc standalone approach
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
            .setControllerAdvice(new ExceptionControllerAdvice(new ErrorResponseBuilder()))
            .build();
    }

    @Test
    void shouldVerifyOtpWhenValidRequestSent_verifyOtp() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        RayahOtpVerificationResponse rayahOtpVerificationResponse = new RayahOtpVerificationResponse("123456",
            OtpStatus.SUCCESS);

        when(rayahOtpService.verifyOtp(anyString(), any(RayahOtpVerificationRequest.class))).thenReturn(
            rayahOtpVerificationResponse);

        String request = asJsonString(createRequest("123456", "123456"));

        this.mockMvc.perform(MockMvcRequestBuilders.patch(VERIFY_RAYAH_OTP_URL)
                .accept(MediaType.APPLICATION_JSON)
                .content(request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("correlationID", uuid)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isOk())
            .andDo(print())
            .andExpect(jsonPath("$.*", hasSize(2)))
            .andExpect(jsonPath("$.applicationId").exists());
    }

    @Test
    void validationFailsWhenInvalidRequestSent_verifyOtp() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();
        String request = asJsonString(createRequest("123456", "INVALID123456"));

        this.mockMvc.perform(MockMvcRequestBuilders.patch(VERIFY_RAYAH_OTP_URL)
                .accept(MediaType.APPLICATION_JSON)
                .content(request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("correlationID", uuid)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isBadRequest());
    }

    @Test
    void shouldThrowNotFoundExceptionWhenWrongAppIdSend_verifyOtp() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        RayahOtpVerificationResponse rayahOtpVerificationResponse = new RayahOtpVerificationResponse("123456",
            OtpStatus.FAILED);

        when(rayahOtpService.verifyOtp(anyString(), any(RayahOtpVerificationRequest.class))).thenThrow(
            new ServiceException.NoData("dummy"));

        String request = asJsonString(createRequest("123456", "123456"));

        assertThatThrownBy(() -> this.mockMvc.perform(MockMvcRequestBuilders.patch(VERIFY_RAYAH_OTP_URL)
                .accept(MediaType.APPLICATION_JSON)
                .content(request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("correlationID", uuid)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isNotFound()))
            .hasCause(new NoData("dummy"));
    }

    private RayahOtpVerificationRequest createRequest(String otpRefId, String otpNumber) {
        return new RayahOtpVerificationRequest(otpRefId, otpNumber);
    }

    @Test
    void shouldGenerateOtpWhenValidRequestSent_generateOtp() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        RayahOtpResponse rayahOtpResponse = new RayahOtpResponse("123-abc", "1234", "123456", 2, 100L);

        when(rayahOtpService.generateAndSendOtp(anyString(), any(RayahOtpRequest.class))).thenReturn(rayahOtpResponse);

        String request = asJsonString(new RayahOtpRequest("1234567890"));

        this.mockMvc.perform(MockMvcRequestBuilders.patch(GENERATE_RAYAH_OTP_URL)
                .accept(MediaType.APPLICATION_JSON)
                .content(request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("correlationID", uuid)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isOk())
            .andDo(print())
            .andExpect(jsonPath("$.*", hasSize(5)))
            .andExpect(jsonPath("$.applicationId").exists())
            .andExpect(jsonPath("$.otpRefId").exists())
            .andExpect(jsonPath("$.otpNumber").exists());
    }

    @Test
    void validationFailsWhenInvalidRequestSent_generateOtp() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        RayahOtpResponse rayahOtpResponse = new RayahOtpResponse("123-abc", "1234", "123456", 2, 100L);

        String request = asJsonString(new RayahOtpRequest("1234567"));

        this.mockMvc.perform(MockMvcRequestBuilders.patch(GENERATE_RAYAH_OTP_URL)
                .accept(MediaType.APPLICATION_JSON)
                .content(request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("correlationID", uuid)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isBadRequest());
    }

    @Test
    void shouldThrowNotFoundExceptionWhenWrongAppIdSent_generateOtp() throws Exception {
        // given
        UUID uuid = UUID.randomUUID();

        RayahOtpResponse rayahOtpResponse = new RayahOtpResponse("123-abc", "1234", "123456", 2, 100L);

        when(rayahOtpService.generateAndSendOtp(anyString(), any(RayahOtpRequest.class))).thenThrow(
            new ServiceException.NoData("dummy"));

        String request = asJsonString(new RayahOtpRequest("1234567890"));

        assertThatThrownBy(() -> this.mockMvc.perform(MockMvcRequestBuilders.patch(GENERATE_RAYAH_OTP_URL)
                .accept(MediaType.APPLICATION_JSON)
                .content(request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("correlationID", uuid)
                .header(HttpHeaders.AUTHORIZATION, "Bearer token").secure(false))
            .andExpect(status().isNotFound()))
            .hasCause(new NoData("dummy"));
    }
}