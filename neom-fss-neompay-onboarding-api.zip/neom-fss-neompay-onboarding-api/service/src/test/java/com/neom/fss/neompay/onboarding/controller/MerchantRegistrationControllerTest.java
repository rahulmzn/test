package com.neom.fss.neompay.onboarding.controller;

import com.neom.fss.neompay.onboarding.constants.ApplicationIdType;
import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import com.neom.fss.neompay.onboarding.constants.DocumentType;
import com.neom.fss.neompay.onboarding.model.DocumentUploadRequest;
import com.neom.fss.neompay.onboarding.model.DocumentUploadResponse;
import com.neom.fss.neompay.onboarding.model.MerchantSubmissionRequest;
import com.neom.fss.neompay.onboarding.model.SubmissionResponse;
import com.neom.fss.neompay.onboarding.service.impl.MerchantRegistrationServiceImpl;
import com.neom.fss.neompay.onboarding.service.impl.RegistrationServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MerchantRegistrationControllerTest {

    @Mock
    private RegistrationServiceImpl registrationService;

    @InjectMocks
    private MerchantRegistrationController controller;


    @Mock
    private MerchantRegistrationServiceImpl merchantRegistrationService;



    @Test
    void shouldUploadDocWhenValidDocumentDetails() throws Exception {
        //given

        var applicationId = "app123";
        var docDetails = new DocumentUploadRequest();
        docDetails.setDocType(DocumentType.COMPANY_REG_CERT);
        docDetails.setMobileNo("2321213131");
        docDetails.setFile(
            new MockMultipartFile("file", "test.pdf", MediaType.MULTIPART_FORM_DATA_VALUE, "test".getBytes()));
        docDetails.setFileName("test.pdf");
        docDetails.setIdType(ApplicationIdType.MERCHNAT_SIGNUP_APPID);
        docDetails.setDocType(DocumentType.COMPANY_REG_CERT);

        var documentUploadResponse = new DocumentUploadResponse("TEST_DOC_ID", "SUCCESS");

        when(merchantRegistrationService.uploadDocument(docDetails, applicationId)).thenReturn(documentUploadResponse);

        //when
        var response = controller.uploadDocument(applicationId, docDetails);

        //then
        assertNotNull(response);
        assertNotNull("TEST_DOC_ID", response.getBody().getDocumentId());
        assertNotNull("SUCCESS", response.getBody().getStatus());

    }

    @Test
    void shouldSubmitMerchantApplicationTest() {
        //given

        var applicationId = "app123";
        var request = new MerchantSubmissionRequest();
        request.setPreferredLanguage("en");
        var response = new SubmissionResponse("app-12", ApplicationStage.APPLICATION_SUBMITTED);
        when(registrationService.submitMerchantApplication(applicationId,request)).thenReturn(response);
        //when
        var submissionResponse = controller.submitMerchantApplication(applicationId , request);
        //then
        assertNotNull(submissionResponse);
        assertNotNull(applicationId, Objects.requireNonNull(submissionResponse.getBody()).getApplicationId());

    }
}
