package com.neom.fss.neompay.onboarding.service.impl;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.util.UniqueIdGenerator;
import com.neom.fss.neompay.onboarding.client.comviva.ComvivaClient;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaBusinessOnboardRequestDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaOnboardRequestDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaOnboardResponseDto;
import com.neom.fss.neompay.onboarding.client.idauth.IdAuthClient;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationResponseDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.RequestedByKey;
import com.neom.fss.neompay.onboarding.client.idauth.dto.UserProfileRequestDto;
import com.neom.fss.neompay.onboarding.client.mobiquity.MobiquityClient;
import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import com.neom.fss.neompay.onboarding.domain.ApplicationStageValidator;
import com.neom.fss.neompay.onboarding.mapper.ApplicantMapper;
import com.neom.fss.neompay.onboarding.mapper.ComvivaMapper;
import com.neom.fss.neompay.onboarding.mapper.IdAuthMapper;
import com.neom.fss.neompay.onboarding.model.*;
import com.neom.fss.neompay.onboarding.repository.entity.Applicant;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.repository.entity.ApplicationStageHistory;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import com.neom.fss.neompay.onboarding.service.UserService;
import com.neom.fss.neompay.onboarding.utils.PropertiesConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RegistrationServiceImplTest {

    @Mock
    private IdAuthClient idAuthClient;

    @Mock
    private ComvivaClient comvivaClient;

    @Mock
    private ApplicantVerificationServiceImpl applicantVerificationService;

    @Mock
    private ApplicationService applicationService;

    @Mock
    private ComvivaMapper comvivaMapper;

    @Mock
    private IdAuthMapper idAuthMapper;

    @Mock
    private ApplicationStageValidator applicationStageValidator;

    @Mock
    private ApplicantMapper applicantMapper;

    @InjectMocks
    private RegistrationServiceImpl registrationService;

    @Mock
    private  UserService userService;

    @Mock
    private UniqueIdGenerator uniqueIdGenerator;

    @Mock
    private MobiquityClient mobiquityClient;

    @Test
    void shouldDoUserOnboardCompleteWithValidRequest() {
        var submissionRequest = this.createSubmissionRequest();

        when(applicantMapper.toModel(any())).thenReturn(this.createDummyApplicantDetails());
        when(applicationService.getApplicationById(any())).thenReturn(createDummyApplicantEntity());
        when(applicationService.save(any())).thenReturn(createDummyApplication());
        when(applicantVerificationService.getApplicantInformation(anyString())).thenReturn(createDummyApplicant());
        when(applicationStageValidator.hasPassedAllStages(any())).thenReturn(true);
        when(comvivaClient.comvivaSelfRegistration(any())).thenReturn(this.createComvivaOnboardResponse());
        when(comvivaMapper.mapModelToRequestDto(any(), any())).thenReturn(new ComvivaOnboardRequestDto());
        when(comvivaMapper.mapDtoToResponseModel(any())).thenReturn(this.createComvivaResgistrationResponse());
        when(idAuthMapper.mapModelToRequestDto(any())).thenReturn(new UserProfileRequestDto());
        doNothing().when(idAuthClient).createUserProfileWithPin(any());

        SubmissionResponse response = registrationService.submitApplication("1122", submissionRequest);

        assertNotNull(response);
        assertEquals(ApplicationStage.ONBOARDING_COMPLETED, response.getStage());

    }


    @Test
    void shouldDoUserOnboardFailedWithComvivaRequestFail() {
        var submissionRequest = this.createSubmissionRequest();
        var application = new Application();
        application.setStageName(ApplicationStage.ONBOARDING_FAILED);

        var comvivaOnboardResponse = this.createComvivaResgistrationResponse();
        comvivaOnboardResponse.setUserId(null);

        when(applicationService.getApplicationById(any())).thenReturn(createDummyApplicantEntity());
        when(applicantMapper.toModel(any())).thenReturn(this.createDummyApplicantDetails());
        when(applicationService.save(any())).thenReturn(application);
        when(applicantVerificationService.getApplicantInformation(anyString())).thenReturn(
            createDummyApplicant());
        when(comvivaClient.comvivaSelfRegistration(any())).thenReturn(this.createComvivaOnboardResponse());
        when(comvivaMapper.mapModelToRequestDto(any(), any())).thenReturn(new ComvivaOnboardRequestDto());
        when(comvivaMapper.mapDtoToResponseModel(any())).thenReturn(comvivaOnboardResponse);

        ServiceException.ClientError thrown = assertThrows(ServiceException.ClientError.class,
            () -> registrationService.submitApplication("1122", submissionRequest));
        assertEquals("NPAY_ONBRD_10119", thrown.getMessage());
    }

    private ComvivaRegistrationResponse createComvivaResgistrationResponse() {
        return new ComvivaRegistrationResponse("e63a3411-85a1-4b11-877e-6d497a1d2dd1",
            "User Registration has been completed successfully with the mobileNumber 7700000011",
            "USER_SELF_REG", "SUCCEEDED", "US.27391640691196247");
    }

    private ComvivaOnboardResponseDto createComvivaOnboardResponse() {
        return new ComvivaOnboardResponseDto("e63a3411-85a1-4b11-877e-6d497a1d2dd1",
            "User Registration has been completed successfully with the mobileNumber 7700000011",
            "USER_SELF_REG", "SUCCEEDED", "US.27391640691196247");

    }

    private SubmissionRequest createSubmissionRequest() {
        SubmissionRequest createOnboardRequest = new SubmissionRequest();
        createOnboardRequest.setEmail("johndoe@gmail.com");
        createOnboardRequest.setEmploymentStatus("Public");
        createOnboardRequest.setUserPin("135790");
        createOnboardRequest.setConfirmUserPin("135790");
        createOnboardRequest.setIncomeRange("1");
        createOnboardRequest.setPrimarySourceOfIncome("I");
        createOnboardRequest.setPreferredLanguage("en");
        return createOnboardRequest;
    }

    private Application createDummyApplicantEntity() {
        Application application = new Application();
        application.setApplicationId("1122");
        application.setUserId("");
        application.setUserType(UserType.CUSTOMER);
        application.setTokenJti("");
        application.setCreatedTs(LocalDateTime.now());
        application.setRiskRating("2");
        application.setMobileNo("919876543210");
        application.setUpdatedTs(LocalDateTime.now());
        application.setId(1L);
        application.setStageName(ApplicationStage.YAKEEN_RECEIVED);

        List<String> successStages = Arrays.asList("OTP_INITIATED",
            "OTP_VERIFIED", "YAKEEN_RECEIVED",
            "LOCAL_SANCTION_PASS", "INT_SANCTION_PASS", "RAYAH_OTP_INIT", "RAYAH_OTP_VERIFIED");

        Set<ApplicationStageHistory> historySet = new HashSet<>();
        for (String stage : successStages) {
            historySet.add(createDummyAppStageHistory(stage, application));
        }
        application.setApplicationStageHistories(historySet);
        return application;
    }


    private ApplicationStageHistory createDummyAppStageHistory(String stage, Application application) {
        return new ApplicationStageHistory(application, ApplicationStage.valueOf(stage));

    }

    private ApplicantDetail createDummyApplicantDetails() {
        ApplicantDetail applicantDetail = new ApplicantDetail();
        applicantDetail.setMobileNo("9876543210");
        applicantDetail.setApplicationId("1122");
        applicantDetail.setEnglishBirthDate(LocalDate.now());
        applicantDetail.setEnglishFirstName("John");
        applicantDetail.setEnglishSecondName("Sam");
        applicantDetail.setEnglishThirdName("");
        applicantDetail.setEnglishLastName("Doe");
        applicantDetail.setFamilyName("Doe");
        applicantDetail.setFatherName("Mr. X");
        applicantDetail.setGender('M');
        applicantDetail.setHijriBirthDate("2093-12-20");
        applicantDetail.setIqamaId("1111122222");
        applicantDetail.setNationality("SA");
        applicantDetail.setIdExpiryDate(LocalDate.now());
        return applicantDetail;
    }

    private Applicant createDummyApplicant() {
        Applicant applicant = new Applicant();

        applicant.setId(1L);
        applicant.setApplicationId("1122");
        applicant.setEnglishBirthDate(LocalDate.now());
        applicant.setEnglishFirstName("John");
        applicant.setEnglishSecondName("Sam");
        applicant.setEnglishThirdName("");
        applicant.setEnglishLastName("Doe");
        applicant.setFamilyName("Doe");
        applicant.setFatherName("Mr. X");
        applicant.setGender('M');
        applicant.setHijriBirthDate("2093-12-20");
        applicant.setIqamaId("1111122222");
        applicant.setNationality("SA");
        applicant.setIdExpiryDate(LocalDate.now());

        return applicant;
    }

    private Application createDummyApplication() {
        Application application = new Application();
        application.setApplicationId("1122");
        application.setUserType(UserType.CUSTOMER);
        application.setStageName(ApplicationStage.ONBOARDING_COMPLETED);
        return application;
    }

    @Test
    void userOnboardFailsIfLastStageWasCompleted() {
        var submissionRequest = this.createSubmissionRequest();
        var application = new Application();
        application.setStageName(ApplicationStage.ONBOARDING_COMPLETED);
        var comvivaOnboardResponse = this.createComvivaResgistrationResponse();
        comvivaOnboardResponse.setUserId(null);
        when(applicationService.getApplicationById(any())).thenReturn(createDummyApplication());
        when(applicantVerificationService.getApplicantInformation(anyString())).thenReturn(
                createDummyApplicant());

        ServiceException.ClientError thrown = assertThrows(ServiceException.ClientError.class,
                () -> registrationService.submitApplication("1122", submissionRequest));
        assertEquals("NPAY_ONBRD_10108", thrown.getMessage());
    }

    @Test
    void registerUserTest() {
        RegistrationRequest registrationRequest = new RegistrationRequest();
        registrationRequest.setOtpNumber("123456");
        registrationRequest.setOtpRefId("123458989");
        OtpVerificationResponseDto responseDto = new OtpVerificationResponseDto();
        responseDto.setVerified(true);
        responseDto.setSentTo("abc@neom.com");
        responseDto.setRequestedByKey(RequestedByKey.CUSTOMER_ID);
        responseDto.setRequestedByValue("customer");
        when(userService.userExists(any(), any())).thenReturn(false);
        when(idAuthClient.verifyOtp(any())).thenReturn(responseDto);
        when(uniqueIdGenerator.getRandomAlphabeticStartWithGivenAndHyphen(PropertiesConfig.APP_REF_ID_PREFIX, PropertiesConfig.APP_REF_ID_LENGTH)).thenReturn("123");
        RegistrationResponse registrationResponse = registrationService.registerUser(registrationRequest);
        assertEquals("123", registrationResponse.getApplicationId());
        assertEquals("123458989", registrationResponse.getOtpRefId());
    }
    @Test
    void shouldThrowExceptionIfUserExistsTest() {
        RegistrationRequest registrationRequest = new RegistrationRequest();
        registrationRequest.setOtpNumber("123456");
        registrationRequest.setOtpRefId("123458989");
        OtpVerificationResponseDto responseDto = new OtpVerificationResponseDto();
        responseDto.setVerified(true);
        responseDto.setSentTo("abc@neom.com");
        responseDto.setRequestedByKey(RequestedByKey.CUSTOMER_ID);
        responseDto.setRequestedByValue("customer");
        when(userService.userExists(any(), any())).thenReturn(true);
        when(idAuthClient.verifyOtp(any())).thenReturn(responseDto);
        var response = assertThrows(ServiceException.BadInput.class,
                () ->registrationService.registerUser(registrationRequest));
        assertNotNull(response);
    }
    @Test
    void shouldThrowExceptionIfOtpIsNotVerifiedTest() {
        RegistrationRequest registrationRequest = new RegistrationRequest();
        registrationRequest.setOtpNumber("123456");
        registrationRequest.setOtpRefId("123458989");
        OtpVerificationResponseDto responseDto = new OtpVerificationResponseDto();
        responseDto.setVerified(false);
        responseDto.setSentTo("abc@neom.com");
        responseDto.setRequestedByKey(RequestedByKey.CUSTOMER_ID);
        responseDto.setRequestedByValue("customer");
        when(idAuthClient.verifyOtp(any())).thenReturn(responseDto);
        var response = assertThrows(ServiceException.BadInput.class,
                () ->registrationService.registerUser(registrationRequest));
        assertNotNull(response);
    }

    @Test
    void submitMerchantApplicationTest() throws IOException {
        MerchantSubmissionRequest request = new MerchantSubmissionRequest();
        CompanyDetail companyDetail = new CompanyDetail();
        RegistrationDetail registrationDetail = new RegistrationDetail();
        BusinessDetail businessDetail = new BusinessDetail();
        registrationDetail.setCompanyName("ABC");
        registrationDetail.setCompanyType("A");
        registrationDetail.setCompanyType("Type C");
        registrationDetail.setRegistrationDocUrl("abc.jpeg");
        businessDetail.setTransactionValue("100");
        companyDetail.setRegistrationInfo(registrationDetail);
        companyDetail.setBusinessInfo(businessDetail);
        ManagementDetail managementDetail = new ManagementDetail();
        Management management = new Management();
        managementDetail.setSeniorManagements(Arrays.asList(management));
        companyDetail.setManagementDetails(managementDetail);
        request.setCompanyDetails(companyDetail);
        var comvivaOnboardResponse = this.createComvivaResgistrationResponse();
        comvivaOnboardResponse.setUserId(null);

        Application application = new Application();
        application.setApplicationId("123");
        application.setUserType(UserType.CUSTOMER);
        application.setStageName(ApplicationStage.APPLICATION_SUBMITTED);
        when(applicationService.getApplicationById(any())).thenReturn(createDummyApplicantEntity());
        when(applicationService.save(any())).thenReturn(createDummyApplication());
        when(comvivaMapper.mapBusinessModelToRequestDto(any(),any())).thenReturn(new ComvivaBusinessOnboardRequestDto());
        when(comvivaClient.merchantSelfRegistration(any())).thenReturn(new ComvivaOnboardResponseDto());
        when(comvivaMapper.mapDtoToResponseModel(any())).thenReturn(comvivaOnboardResponse);
        when(mobiquityClient.mobiquityPickListMerchantData()).thenReturn("{\"businessCategoryList\":[{\"displayName\":\"Grocery\",\"id\":\"MER_CAT_1\"},{\"displayName\":\"Hotel\",\"id\":\"MER_CAT_2\"},{\"displayName\":\"Automobiles and vehicles\",\"id\":\"MER_CAT_3\"},{\"displayName\":\"Dining\",\"id\":\"MER_CAT_4\"},{\"displayName\":\"Education\",\"id\":\"MER_CAT_5\"},{\"displayName\":\"Entertainment\",\"id\":\"MER_CAT_6\"},{\"displayName\":\"Gas/Fuel\",\"id\":\"MER_CAT_7\"},{\"displayName\":\"Hospitals\",\"id\":\"MER_CAT_8\"},{\"displayName\":\"Medical services\",\"id\":\"MER_CAT_9\"},{\"displayName\":\"Personal and professional services\",\"id\":\"MER_CAT_10\"},{\"displayName\":\"Electronics\",\"id\":\"MER_CAT_11\"},{\"displayName\":\"Fashion\",\"id\":\"MER_CAT_12\"},{\"displayName\":\"Furniture\",\"id\":\"MER_CAT_13\"},{\"displayName\":\"General merchandise\",\"id\":\"MER_CAT_14\"},{\"displayName\":\"Airlines\",\"id\":\"MER_CAT_15\"},{\"displayName\":\"Rental agency\",\"id\":\"MER_CAT_16\"},{\"displayName\":\"Transportation\",\"id\":\"MER_CAT_17\"},{\"displayName\":\"Telecom\",\"id\":\"MER_CAT_18\"},{\"displayName\":\"Utility bills\",\"id\":\"MER_CAT_19\"},{\"displayName\":\"Others\",\"id\":\"MER_CAT_20\"}],\"companyTypeList\":[{\"displayName\":\"Public\",\"id\":\"MERCH_CLASS_1\"},{\"displayName\":\"Private\",\"id\":\"MERCH_CLASS_2\"},{\"displayName\":\"Government\",\"id\":\"MERCH_CLASS_3\"},{\"displayName\":\"Charity\",\"id\":\"MERCH_CLASS_4\"}],\"monthlyValueofTransactionsList\":[{\"displayName\":\"SAR 0 - SAR 5,000\",\"id\":\"MONTH_VAL_1\"},{\"displayName\":\"SAR 5,001 - SAR 10,000\",\"id\":\"MONTH_VAL_2\"},{\"displayName\":\"SAR 10,001 - SAR 20,000\",\"id\":\"MONTH_VAL_3\"},{\"displayName\":\"SAR 20,001 - SAR 50,000\",\"id\":\"MONTH_VAL_4\"},{\"displayName\":\"SAR 50,001 - SAR 100,000\",\"id\":\"MONTH_VAL_5\"},{\"displayName\":\"\\u003e SAR 100,000\",\"id\":\"MONTH_VAL_6\"}],\"monthlyVolumeofTransactionsList\":[{\"displayName\":\"0 - 1000\",\"id\":\"MONTH_VOL_1\"},{\"displayName\":\"1001 - 5000\",\"id\":\"MONTH_VOL_2\"},{\"displayName\":\"5001 - 10000\",\"id\":\"MONTH_VOL_3\"},{\"displayName\":\"\\u003e10000\",\"id\":\"MONTH_VOL_4\"}]}");
        when(applicationService.save(any())).thenReturn(application);
        // when(applicationService.saveToHistory(any())).thenReturn();
       var response = registrationService.submitMerchantApplication("123",request);
       assertNotNull(response);
       assertEquals("123", response.getApplicationId());

}
    @Test

    void submitMerchantApplicationExceptionTest(){

        MerchantSubmissionRequest request = new MerchantSubmissionRequest();
        CompanyDetail companyDetail = new CompanyDetail();
        RegistrationDetail registrationDetail = new RegistrationDetail();
        BusinessDetail businessDetail = new BusinessDetail();
        registrationDetail.setCompanyName("ABC");
        registrationDetail.setCompanyType("A");
        registrationDetail.setCompanyType("Type C");
        registrationDetail.setRegistrationDocUrl("abc.jpeg");
        businessDetail.setTransactionValue("100");
        companyDetail.setRegistrationInfo(registrationDetail);
        companyDetail.setBusinessInfo(businessDetail);
        ManagementDetail managementDetail = new ManagementDetail();
        Management management = new Management();
        managementDetail.setSeniorManagements(Arrays.asList(management));
        companyDetail.setManagementDetails(managementDetail);
        request.setCompanyDetails(companyDetail);
        var comvivaOnboardResponse = this.createComvivaResgistrationResponse();
        comvivaOnboardResponse.setUserId(null);
        when(applicationService.getApplicationById(any())).thenReturn(createDummyApplicantEntity());
        when(applicationService.save(any())).thenReturn(createDummyApplication());
        when(comvivaClient.merchantSelfRegistration(any())).thenReturn(new ComvivaOnboardResponseDto());
        when(comvivaMapper.mapDtoToResponseModel(any())).thenReturn(comvivaOnboardResponse);
        when(mobiquityClient.mobiquityPickListMerchantData()).thenReturn("{\"businessCategoryList\":[{\"displayName\":\"Grocery\",\"id\":\"MER_CAT_1\"},{\"displayName\":\"Hotel\",\"id\":\"MER_CAT_2\"},{\"displayName\":\"Automobiles and vehicles\",\"id\":\"MER_CAT_3\"},{\"displayName\":\"Dining\",\"id\":\"MER_CAT_4\"},{\"displayName\":\"Education\",\"id\":\"MER_CAT_5\"},{\"displayName\":\"Entertainment\",\"id\":\"MER_CAT_6\"},{\"displayName\":\"Gas/Fuel\",\"id\":\"MER_CAT_7\"},{\"displayName\":\"Hospitals\",\"id\":\"MER_CAT_8\"},{\"displayName\":\"Medical services\",\"id\":\"MER_CAT_9\"},{\"displayName\":\"Personal and professional services\",\"id\":\"MER_CAT_10\"},{\"displayName\":\"Electronics\",\"id\":\"MER_CAT_11\"},{\"displayName\":\"Fashion\",\"id\":\"MER_CAT_12\"},{\"displayName\":\"Furniture\",\"id\":\"MER_CAT_13\"},{\"displayName\":\"General merchandise\",\"id\":\"MER_CAT_14\"},{\"displayName\":\"Airlines\",\"id\":\"MER_CAT_15\"},{\"displayName\":\"Rental agency\",\"id\":\"MER_CAT_16\"},{\"displayName\":\"Transportation\",\"id\":\"MER_CAT_17\"},{\"displayName\":\"Telecom\",\"id\":\"MER_CAT_18\"},{\"displayName\":\"Utility bills\",\"id\":\"MER_CAT_19\"},{\"displayName\":\"Others\",\"id\":\"MER_CAT_20\"}],\"companyTypeList\":[{\"displayName\":\"Public\",\"id\":\"MERCH_CLASS_1\"},{\"displayName\":\"Private\",\"id\":\"MERCH_CLASS_2\"},{\"displayName\":\"Government\",\"id\":\"MERCH_CLASS_3\"},{\"displayName\":\"Charity\",\"id\":\"MERCH_CLASS_4\"}],\"monthlyValueofTransactionsList\":[{\"displayName\":\"SAR 0 - SAR 5,000\",\"id\":\"MONTH_VAL_1\"},{\"displayName\":\"SAR 5,001 - SAR 10,000\",\"id\":\"MONTH_VAL_2\"},{\"displayName\":\"SAR 10,001 - SAR 20,000\",\"id\":\"MONTH_VAL_3\"},{\"displayName\":\"SAR 20,001 - SAR 50,000\",\"id\":\"MONTH_VAL_4\"},{\"displayName\":\"SAR 50,001 - SAR 100,000\",\"id\":\"MONTH_VAL_5\"},{\"displayName\":\"\\u003e SAR 100,000\",\"id\":\"MONTH_VAL_6\"}],\"monthlyVolumeofTransactionsList\":[{\"displayName\":\"0 - 1000\",\"id\":\"MONTH_VOL_1\"},{\"displayName\":\"1001 - 5000\",\"id\":\"MONTH_VOL_2\"},{\"displayName\":\"5001 - 10000\",\"id\":\"MONTH_VOL_3\"},{\"displayName\":\"\\u003e10000\",\"id\":\"MONTH_VOL_4\"}]}");
        when(applicationService.save(any())).thenReturn(createDummyApplication());
        ServiceException.ClientError thrown = assertThrows(ServiceException.ClientError.class,
                () -> registrationService.submitMerchantApplication("123",request));
        assertEquals("NPAY_ONBRD_10106", thrown.getMessage());
    }
}
