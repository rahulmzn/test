package com.neom.fss.neompay.onboarding.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.onboarding.client.mobiquity.MobiquityClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PickListServiceImplTest {
    @Mock
    private MobiquityClient mobiquityClient;

    @InjectMocks
    private PickListServiceImpl pickListService;

    @Test
    void shouldFetchCustomerValuesWithValidRequest(){
        String data = "{\"employementStatusList\":[{\"displayName\":\"Public\",\"id\":\"EMP_STATUS_1\"},{\"displayName\":\"Private\",\"id\":\"EMP_STATUS_2\"},{\"displayName\":\"Self-employed\",\"id\":\"EMP_STATUS_3\"},{\"displayName\":\"Unemployed\",\"id\":\"EMP_STATUS_4\"}]}";
        when(mobiquityClient.mobiquityPickListCustomerData()).thenReturn(data);

        var response = pickListService.picklistData();
        assertNotNull(response);
    }

    @Test
    void shouldThrowErrorWhenResponseIsEmpty(){
        String data = "";
        when(mobiquityClient.mobiquityPickListCustomerData()).thenReturn(data);

        assertThrows(ServiceException.NoData.class,
            () -> pickListService.picklistData());

    }

    @Test
    void shouldThrowsErrorWhenJsonProcessingFails(){
        String data = "{\"employementStatusList\":\":\"Public\",\"id\":\"EMP_STATUS_1\"},{\"displayName\":\"Private\",\"id\":\"EMP_STATUS_2\"},{\"displayName\":\"Self-employed\",\"id\":\"EMP_STATUS_3\"},{\"displayName\":\"Unemployed\",\"id\":\"EMP_STATUS_4\"}]}";
        when(mobiquityClient.mobiquityPickListCustomerData()).thenReturn(data);

        assertThrows(ServiceException.BadInput.class,
            () -> pickListService.picklistData());
    }
}
