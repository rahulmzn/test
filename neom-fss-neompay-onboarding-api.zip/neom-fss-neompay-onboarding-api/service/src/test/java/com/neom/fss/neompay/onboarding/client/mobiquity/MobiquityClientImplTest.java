package com.neom.fss.neompay.onboarding.client.mobiquity;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.WebClientError;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.onboarding.client.mobiquity.impl.MobiquityClientImpl;
import com.neom.fss.neompay.onboarding.config.BackendApiPathsConfig;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

@ExtendWith(MockitoExtension.class)
class MobiquityClientImplTest {
    @Mock
    private WebRequestSender webRequestSender;

    @Mock
    private BackendApiPathsConfig backendApiPathsConfig;

    @InjectMocks
    private MobiquityClientImpl mobiquityClient;

    @Test
    void shouldFetchCustomerValuesWithValidRequest()  {
        mobiquityClient.setMobiquityServiceAddress("http://service.com");
        mobiquityClient.mobiquityPickListCustomerData();
        verify(webRequestSender, Mockito.atLeastOnce()).sendGetRequest(any(), any());
    }

    @Test
    void shouldFetchNoValueWhenSomeErrorWithRequest()  {
        mobiquityClient.setMobiquityServiceAddress("http://service.com");
        Mockito.when(webRequestSender.sendGetRequest(any(),any())).thenThrow(
            new WebClientError("err", HttpStatus.BAD_REQUEST));
        var response = mobiquityClient.mobiquityPickListCustomerData();
        Assertions.assertNotNull(response);
        Assertions.assertEquals("", response);
    }
    @Test
    void shouldFetchMerchantValuesWithValidRequest()  {
        mobiquityClient.setMobiquityServiceAddress("http://service.com");
        mobiquityClient.mobiquityPickListMerchantData();
        verify(webRequestSender, Mockito.atLeastOnce()).sendGetRequest(any(), any());
    }

    @Test
    void shouldFetchNoValueWhenSomeErrorWithRequestForMerchant()  {
        mobiquityClient.setMobiquityServiceAddress("http://service.com");
        Mockito.when(webRequestSender.sendGetRequest(any(),any())).thenThrow(
                new WebClientError("err", HttpStatus.BAD_REQUEST));
        var response = mobiquityClient.mobiquityPickListMerchantData();
        Assertions.assertNotNull(response);
        Assertions.assertEquals("", response);
    }

}
