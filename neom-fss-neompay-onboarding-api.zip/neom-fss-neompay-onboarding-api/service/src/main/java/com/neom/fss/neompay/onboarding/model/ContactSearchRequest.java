package com.neom.fss.neompay.onboarding.model;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ApiModel(description = "User Contact Search Payload")
@ToString
public class ContactSearchRequest {
    @ApiModelProperty(example = "966556625635", value = "MSISDN or Email to be searched")
    @NotBlank
    private String searchParameter;

    @ApiModelProperty(example = "CUSTOMER", value = "User Type")
    @NotNull
    private UserType userType;
}
