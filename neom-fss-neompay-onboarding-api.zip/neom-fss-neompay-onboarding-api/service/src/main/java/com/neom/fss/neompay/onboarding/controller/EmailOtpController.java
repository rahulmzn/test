package com.neom.fss.neompay.onboarding.controller;

import com.neom.fss.neompay.onboarding.controller.definition.EmailOtpApi;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationResponse;
import com.neom.fss.neompay.onboarding.service.EmailOtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@RequiredArgsConstructor
public class EmailOtpController implements EmailOtpApi {

    private final EmailOtpService emailOtpService;

    @Override
    public ResponseEntity<EmailOtpVerificationResponse> verifyEmail(String applicationId,
                                                                    EmailOtpVerificationRequest request) {
        EmailOtpVerificationResponse verifyOtpResponse = emailOtpService
            .verifyEmail(applicationId, request);
        return new ResponseEntity<>(verifyOtpResponse, HttpStatus.OK);
    }
}
