package com.neom.fss.neompay.onboarding.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ComvivaRegistrationResponse {

    private String serviceRequestId;
    private String message;
    private String serviceFlow;
    private String status;
    private String userId;
}
