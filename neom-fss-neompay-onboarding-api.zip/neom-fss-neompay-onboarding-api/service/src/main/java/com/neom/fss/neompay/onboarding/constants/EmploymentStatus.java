package com.neom.fss.neompay.onboarding.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum EmploymentStatus {
    PERMANENT("Permanent"),
    UNKNOWN("Unknown");

    private String value;
}
