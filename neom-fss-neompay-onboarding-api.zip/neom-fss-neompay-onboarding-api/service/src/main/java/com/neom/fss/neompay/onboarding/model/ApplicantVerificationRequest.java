package com.neom.fss.neompay.onboarding.model;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = "birthDate")
public class ApplicantVerificationRequest {

    @ApiModelProperty(value = "Ten Digit Iqama ID", required = true, example = "1234567890")
    @NotBlank
    @Size(min = 10, max = 10)
    @Pattern(regexp = "[0-9]+")
    private String iqamaId;

    @ApiModelProperty(value = "Date of Birth (dd-MM-yyyy)", required = true, example = "31-12-1999")
    @Pattern(regexp = "^([0-2][0-9]|(3)[0-1])(\\-)(((0)[0-9])|((1)[0-2]))(\\-)\\d{4}$")
    private String birthDate;
}
