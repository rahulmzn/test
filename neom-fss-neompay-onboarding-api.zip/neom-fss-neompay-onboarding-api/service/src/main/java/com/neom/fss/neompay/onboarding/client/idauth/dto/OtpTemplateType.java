package com.neom.fss.neompay.onboarding.client.idauth.dto;

import lombok.Getter;

@Getter
public enum OtpTemplateType {
    PAYMENT,
    ONBOARD,
    UNKNOWN
}
