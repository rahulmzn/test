package com.neom.fss.neompay.onboarding.service;

import com.neom.fss.neompay.onboarding.model.RayahOtpRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpResponse;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationResponse;

public interface RayahOtpService {

    RayahOtpResponse generateAndSendOtp(String applicationId, RayahOtpRequest rayahOtpRequest);

    RayahOtpVerificationResponse verifyOtp(String applicationId,
        RayahOtpVerificationRequest request);
}
