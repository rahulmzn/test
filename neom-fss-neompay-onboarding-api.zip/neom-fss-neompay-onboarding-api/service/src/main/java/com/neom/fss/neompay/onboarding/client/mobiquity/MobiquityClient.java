package com.neom.fss.neompay.onboarding.client.mobiquity;


public interface MobiquityClient {
    String mobiquityPickListCustomerData();

    String mobiquityPickListMerchantData();

}
