package com.neom.fss.neompay.onboarding.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DocumentUploadResponse {

    @ApiModelProperty(value = "Comviva uploaded document Id", required = true, example = "626baff4185f32d704bf87b5")
    private String documentId;

    @ApiModelProperty(value = "Document upload status", required = true, example = "SUCCESS")
    private String status;
}
