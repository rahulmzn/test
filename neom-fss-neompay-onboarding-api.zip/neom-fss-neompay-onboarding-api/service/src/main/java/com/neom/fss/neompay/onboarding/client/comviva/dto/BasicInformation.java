package com.neom.fss.neompay.onboarding.client.comviva.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BasicInformation {

    private String address1;
    private String address2;
    private Integer annexId;
    private String attr1;
    private String attr10;
    private String attr2;
    private String attr3;
    private String attr4;
    private String attr5;
    private String attr6;
    private String attr7;
    private String attr8;
    private String attr9;
    private String authenticationIdType;
    private Integer authenticationValue;
    private String city;
    private Long contactNumber;
    private String contactPerson;
    private String country;
    private String dateOfBirth;
    private String district;
    private String emailId;
    private String fatherName;
    private String firstName;
    private String formNo;
    private String gender;
    private String lastName;
    private String loginId;
    private String maritalStatus;
    private String middleName;
    private String spouseFirstName;
    private Long mobileNumber;
    private String nationality;
    private Integer postalCode;
    private String preferredLanguage;
    private String referenceId;
    private String referralCode;
    private String remarks;
    private String residenceCountry;
    private String state;
    private String title;
}
