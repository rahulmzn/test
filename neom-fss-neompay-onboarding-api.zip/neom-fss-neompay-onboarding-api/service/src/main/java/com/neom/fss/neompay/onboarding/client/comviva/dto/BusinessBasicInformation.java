package com.neom.fss.neompay.onboarding.client.comviva.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BusinessBasicInformation extends BasicInformation {

    private String allowedDays;
    private String cif;
    private String isTransferReversalRequired;
    private Double latitude;
    private Double longitude;
    private String merchantCode;
    private String merchantCodeRequired;
    private String merchantType;
    private String businessCategory;
    private String merchantClassificationCode;
}
