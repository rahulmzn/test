package com.neom.fss.neompay.onboarding.client.comviva.impl;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.WebClientError;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.onboarding.client.comviva.ComvivaClient;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaBusinessOnboardRequestDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaOnboardRequestDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaOnboardResponseDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ContactSearchResponseDto;
import com.neom.fss.neompay.onboarding.config.BackendApiPathsConfig;
import liquibase.repackaged.org.apache.commons.lang3.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Objects;

@Component
@Setter
@Flogger
@RequiredArgsConstructor
public class ComvivaClientImpl implements ComvivaClient {

    @Qualifier("comvivaWebRequestSender")
    private final WebRequestSender webRequestSender;

    private final BackendApiPathsConfig backendApiPathsConfig;

    @Value("#{ '${services.comviva.useComviva}' ? '${services.comviva.service-address}' : '${services.mock.service-address}' }")
    private String comvivaServiceAddress;

    @Override
    public ComvivaOnboardResponseDto comvivaSelfRegistration(
        ComvivaOnboardRequestDto comvivaOnboardRequestDto) {
        ParameterizedTypeReference<ComvivaOnboardResponseDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        var customerSignUpURI = UriComponentsBuilder
            .fromHttpUrl(comvivaServiceAddress + backendApiPathsConfig.getSelfSignUpApi()).build()
            .toUri();
        try {
            return webRequestSender.sendPostRequest(customerSignUpURI, comvivaOnboardRequestDto,
                parameterizedTypeReference);
        } catch (WebClientError exception) {
            log.atSevere().log("Comviva call has failed with error: %s", exception.getMessage());
        }
        return null;
    }

    @Override
    public ComvivaOnboardResponseDto merchantSelfRegistration(
        ComvivaBusinessOnboardRequestDto comvivaBusinessOnboardRequestDto) {
        ParameterizedTypeReference<ComvivaOnboardResponseDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        var merchantSignUpURI = UriComponentsBuilder
            .fromHttpUrl(comvivaServiceAddress + backendApiPathsConfig.getMerchantSelfSignUpApi())
            .build().toUri();
        try {
            return webRequestSender.sendPostRequest(merchantSignUpURI, comvivaBusinessOnboardRequestDto,
                parameterizedTypeReference);
        } catch (WebClientError exception) {
            log.atSevere().log("Comviva call has failed with error: %s", exception.getMessage());
        }
        return null;
    }

    @Override
    public ContactSearchResponseDto contactSearch(String searchParameter) {
        var contactSearchURI = UriComponentsBuilder
                .fromHttpUrl(comvivaServiceAddress + backendApiPathsConfig.getContactSearchUrl())
                .queryParam("searchValue", searchParameter)
                .build().toUri();

        ContactSearchResponseDto searchContact = webRequestSender.sendGetRequest(contactSearchURI,
                new ParameterizedTypeReference<>() {
                });
        if (Objects.nonNull(searchContact) && !CollectionUtils.isEmpty(searchContact.getUsers()) &&
                StringUtils.isNotEmpty(searchContact.getUsers().get(0).getDateOfBirth()) &&
                searchContact.getUsers().get(0).getDateOfBirth().length() >= 10) {
            String dateOfBirth = searchContact.getUsers().get(0).getDateOfBirth().substring(0, 10);
            searchContact.getUsers().get(0).setDateOfBirth(dateOfBirth);
        }
        return searchContact;
    }
}
