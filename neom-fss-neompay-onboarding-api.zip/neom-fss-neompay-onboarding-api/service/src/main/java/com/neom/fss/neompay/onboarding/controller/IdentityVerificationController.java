package com.neom.fss.neompay.onboarding.controller;

import com.neom.fss.neompay.onboarding.controller.definition.IdentityVerificationApi;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationRequest;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationResponse;
import com.neom.fss.neompay.onboarding.service.ApplicantVerificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@RequiredArgsConstructor
public class IdentityVerificationController implements IdentityVerificationApi {

    private final ApplicantVerificationService applicantVerificationService;

    @Override
    public ResponseEntity<ApplicantVerificationResponse> verifyApplicant(String applicationId,
        ApplicantVerificationRequest request) {
        ApplicantVerificationResponse applicantVerificationResponse = applicantVerificationService
            .verifyApplicant(applicationId, request);
        return new ResponseEntity<>(applicantVerificationResponse, HttpStatus.OK);
    }
}
