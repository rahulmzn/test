package com.neom.fss.neompay.onboarding.repository.entity;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Generated
@Table(name = "stage_user_type_lkp")
public class StageUserTypeLookup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "stage_name", nullable = false)
    private String stageName;

    @Column(name = "user_type", nullable = false)
    @Enumerated(EnumType.STRING)
    private UserType userType;

    @CreatedDate
    private LocalDateTime createdTs;

    @UpdateTimestamp
    private LocalDateTime updatedTs;

    public StageUserTypeLookup(String stageName,
        UserType userType, LocalDateTime createdAt, LocalDateTime updatedTs) {
        this.stageName = stageName;
        this.userType = userType;
        this.createdTs = createdAt;
        this.updatedTs = updatedTs;
    }
}
