package com.neom.fss.neompay.onboarding.repository;

import com.neom.fss.neompay.onboarding.repository.entity.MerchantDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MerchantDocumentRepository extends JpaRepository<MerchantDocument, Long> {

}
