package com.neom.fss.neompay.onboarding.config;


import com.neom.fss.neompay.crosscuttinglib.util.YmlPropertySourceFactory;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.validation.annotation.Validated;

@Configuration
@PropertySource(value = "classpath:service-config.yml", factory = YmlPropertySourceFactory.class)
@Validated
@Getter
public class BackendApiPathsConfig {

    @Value("${backend-api-path.comvia.customer-self-sign-up:}")
    private String selfSignUpApi;

    @Value("${backend-api-path.id-auth.on-time-pins:}")
    private String idAuthOneTimePins;

    @Value("${backend-api-path.id-auth.verify-otp:}")
    private String idAuthVerifyOtp;

    @Value("${backend-api-path.id-auth.users:}")
    private String idAuthUsers;

    @Value("${backend-api-path.comvia.merchant-self-sign-up:}")
    private String merchantSelfSignUpApi;

    @Value("${backend-api-path.comvia.contact-search}")
    private String contactSearchUrl;

    @Value("${backend-api-path.mobiquity.customer-picklist:}")
    private String customerPicklistApi;

    @Value("${backend-api-path.mobiquity.merchant-picklist:}")
    private String merchantPicklistApi;
}
