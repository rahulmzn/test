package com.neom.fss.neompay.onboarding.model;

import static com.neom.fss.neompay.onboarding.constants.DocumentType.COMPANY_REG_CERT;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.onboarding.constants.ApplicationIdType;
import com.neom.fss.neompay.onboarding.constants.DocumentType;
import com.neom.fss.neompay.onboarding.constants.ErrorCodes;
import com.neom.fss.neompay.onboarding.constants.FileType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Objects;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.io.FilenameUtils;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@ApiModel
public class DocumentUploadRequest {

    @ApiModelProperty(value = "Document Type", example = "COMPANY_REG_CERT")
    @NotNull
    private DocumentType docType;

    @ApiModelProperty(value = "Merchant Mobile No", example = "7689879876")
    @NotBlank
    private String mobileNo;

    @ApiModelProperty(value = "ISd Code of uploader", example = "61")
    private String isdCode;

    @ApiModelProperty(value = "Application ID Type", dataType = "ApplicationIdType.class", example = "MERCHNAT_SIGNUP_APPID")
    @NotNull
    private ApplicationIdType idType;

    @ApiModelProperty(value = "Application ID value", example = "2131221")
    @NotBlank
    private String idValue;

    @ApiModelProperty(value = "Document Name", example = "NEOM_COMPANY_REG_CERT.pdf")
    @NotBlank
    private String fileName;

    @ApiModelProperty(value = "Document to be uploaded", example = "file.jpeg")
    @NotNull
    private MultipartFile file;

    public void validateFileType() {
        // validate file type & size: https://neom.atlassian.net/browse/NFS-1959

        var fileExtension = FilenameUtils.getExtension(file.getOriginalFilename());
        if (COMPANY_REG_CERT.equals(docType)) {
            var response = COMPANY_REG_CERT.getType().stream()
                .filter(type -> type.equalsIgnoreCase(fileExtension))
                .findFirst()
                .orElseThrow(() -> new BadInput(ErrorCodes.INVALID_FILE_TYPE.getCode()));

            if (Objects.nonNull(response) && getFileSizeinMB(file.getSize()) > COMPANY_REG_CERT.getSizeinMb()) {
                throw new BadInput(ErrorCodes.INVALID_FILE_SIZE.getCode());
            }
        }

        String extension = fileName.substring(fileName.lastIndexOf(".") + 1);
        if (extension.isBlank()) {
            throw new BadInput(ErrorCodes.INVALID_FILE_TYPE.getCode());
        }
        FileType.isValid(extension);

        if (!fileExtension.equalsIgnoreCase(extension)) {
            throw new BadInput(ErrorCodes.INVALID_FILE_TYPE.getCode());
        }

    }

    private double getFileSizeinMB(long size) {
        return size * 0.00000095367432;
    }
}
