package com.neom.fss.neompay.onboarding.client.comviva.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactUserDto {
    private String userId;
    private String workspaceId;
    private String workspaceName;
    private String categoryId;
    private String categoryName;
    private String msisdn;
    private String loginId;
    private String title;
    private String firstName;
    private String lastName;
    private String middleName;
    private String kycIdType;
    private String kycIdValue;
    private String emailId;
    private String countryCode;
    private String countryValue;
    private String dateOfBirth;

}
