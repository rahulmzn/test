package com.neom.fss.neompay.onboarding.client.comviva.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BusinessPayload {
    private BusinessUser userInformation;
    private List<Kyc> kycs;
    private HierarchyInformation hierarchyInformation;
    private Profile profileDetails;
    private Employment employmentDetail;
    private List<PartnerData> partnerData;
    private List<PartnerDataSecond> partnerDataSecond;
    private List<PartnerDataThird> partnerDataThird;
}
