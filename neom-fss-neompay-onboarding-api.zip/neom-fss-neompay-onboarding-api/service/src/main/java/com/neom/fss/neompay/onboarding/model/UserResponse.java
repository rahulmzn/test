package com.neom.fss.neompay.onboarding.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserResponse {
    private String workspaceId;
    private String workspaceName;
    private String categoryId;
    private String categoryName;
    private String msisdn;
    private String emailId;
}
