package com.neom.fss.neompay.onboarding.config;

import com.neom.fss.neompay.crosscuttinglib.constants.ApiHeader;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.RequestParameterBuilder;
import springfox.documentation.oas.annotations.EnableOpenApi;
import springfox.documentation.schema.ScalarType;
import springfox.documentation.service.ParameterType;
import springfox.documentation.service.RequestParameter;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@EnableOpenApi
@Configuration
public class SwaggerConfig {

    @Bean
    public Docket produceApi() {
        return new Docket(DocumentationType.OAS_30)
            .apiInfo(new ApiInfoBuilder()
                .title("NEOM PAY Onboarding REST API")
                .description("API to onboard customers & merchants to NEOM Pay")
                .version("1.0")
                .build())
            .globalRequestParameters(getGlobalParameterList())
            .tags(
                new Tag(ServiceTags.REGISTRATION_API,
                    "Register NEOM Pay Wallet users"),
                new Tag(ServiceTags.ID_VERIFICATION_API,
                    "Establish applicant's identity as a resident (nationals/expats)"),
                new Tag(ServiceTags.RAYAH_API,
                    "Establish applicant's device ownership against national identity"),
                new Tag(ServiceTags.MERCHANT_REGISTRATION_API,
                    "Register Merchant on NEOM Pay Wallet"),
                new Tag(ServiceTags.PICKLIST_API,
                    "Picklist on NEOM Pay Wallet"))
            .select().apis(RequestHandlerSelectors.withClassAnnotation(RestController.class))
            .build();
    }

    private List<RequestParameter> getGlobalParameterList() {
        return Arrays.stream(ApiHeader.values())
            .filter(ApiHeader::isVisible)
            .map(header -> new RequestParameterBuilder()
                .name(header.getHeaderName())
                .in(ParameterType.HEADER)
                .description(header.getDescription())
                .required(header.isMandatory())
                .query(q ->
                    q.model(m -> m.scalarModel(ScalarType.STRING))
                        .defaultValue(header
                            .getDefaultOption()) // Note: Due to Swagger bug defaults are not being set
                        .enumerationFacet(e -> e.allowedValues(header.getOptions())))
                .build())
            .collect(Collectors.toList());
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class ServiceTags {

        public static final String REGISTRATION_API = "Application Registration API";
        public static final String MERCHANT_REGISTRATION_API = "Merchant Registration API";
        public static final String ID_VERIFICATION_API = "Identity Verification API";
        public static final String RAYAH_API = "Rayah API";
        public static final String PICKLIST_API = "Picklist API";
    }
}
