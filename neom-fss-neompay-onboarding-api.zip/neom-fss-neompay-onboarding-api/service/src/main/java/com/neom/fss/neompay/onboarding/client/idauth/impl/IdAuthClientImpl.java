package com.neom.fss.neompay.onboarding.client.idauth.impl;

import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.crosscuttinglib.util.HeaderUtil;
import com.neom.fss.neompay.onboarding.client.idauth.IdAuthClient;
import com.neom.fss.neompay.onboarding.client.idauth.dto.GenerateOtpRequestDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.GenerateOtpResponseDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationRequestDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationResponseDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.UserProfileRequestDto;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Setter
@RequiredArgsConstructor
public class IdAuthClientImpl implements IdAuthClient {

    private static final String OTP_GENERATE_AND_SEND = "/auth/v1.0/one-time-pins";
    private static final String OTP_VERIFY = "/auth/v1.0/otp-verifications";
    private static final String USER_PROFILE_WITH_PIN = "/auth/v1.0/users";
    private final WebRequestSender webRequestSender;
    @Value("#{ '${services.idauth.useOtpService}' ? '${services.idauth.service-address}' : '${services.mock.service-address}' }")
    private String idauthServiceAddress;
    @Value("${services.idauth.service-address}")
    private String idAuthUserProfileServiceAddress;

    @Override
    public GenerateOtpResponseDto generateAndSendOtp(GenerateOtpRequestDto request) {
        ParameterizedTypeReference<GenerateOtpResponseDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        var otpGenerateServiceURI = UriComponentsBuilder
            .fromHttpUrl(idauthServiceAddress + OTP_GENERATE_AND_SEND)
            .build().toUri();

        return webRequestSender.sendPostRequest(otpGenerateServiceURI,
            request, HeaderUtil.getNeomHttpHeaders(), parameterizedTypeReference);
    }


    @Override
    public OtpVerificationResponseDto verifyOtp(OtpVerificationRequestDto request) {
        ParameterizedTypeReference<OtpVerificationResponseDto> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        var otpVerifyServiceURI = UriComponentsBuilder
            .fromHttpUrl(idauthServiceAddress + OTP_VERIFY)
            .build().toUri();

        return webRequestSender.sendPostRequest(otpVerifyServiceURI, request,
            HeaderUtil.getNeomHttpHeaders(),
            parameterizedTypeReference);
    }


    @Override
    public void createUserProfileWithPin(UserProfileRequestDto userProfileRequestDto) {
        ParameterizedTypeReference<String> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };

        var userProfileWithPinServiceURI = UriComponentsBuilder
            .fromHttpUrl(idAuthUserProfileServiceAddress + USER_PROFILE_WITH_PIN).build().toUri();

        webRequestSender.sendPostRequest(userProfileWithPinServiceURI,
            userProfileRequestDto, HeaderUtil.getNeomHttpHeaders(), parameterizedTypeReference);
    }
}
