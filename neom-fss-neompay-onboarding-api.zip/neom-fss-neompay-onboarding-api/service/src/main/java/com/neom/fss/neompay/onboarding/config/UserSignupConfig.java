package com.neom.fss.neompay.onboarding.config;

import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.validation.annotation.Validated;

@PropertySource(value = "classpath:userSignupConfig.properties")
@Configuration
@ConfigurationProperties(prefix = "user.signup")
@Validated
@Getter
@Setter
public class UserSignupConfig {

    @NotBlank
    private String workspaceCatName;
    @NotBlank
    private String workspaceValue;
    @NotBlank
    private String workspaceCatCode;
    @NotBlank
    private String loginId;
    @NotBlank
    private String remarks;
    @NotBlank
    private String primaryKycId;
    @NotBlank
    private String kycIdIssueCountry;
    @NotBlank
    private String kycIdIssuePlace;
    @NotBlank
    private String kycIdType;
    @NotBlank
    private String authenticationIdType;
    @NotBlank
    private String authProfile;
    @NotBlank
    private String publicDevice;
    @NotBlank
    private String marketingProfile;
    @NotBlank
    private String securityProfile;
    @NotBlank
    private String country;
    @NotBlank
    private String city;
    @NotBlank
    private String address1;
    @NotBlank
    private String attr10;

}
