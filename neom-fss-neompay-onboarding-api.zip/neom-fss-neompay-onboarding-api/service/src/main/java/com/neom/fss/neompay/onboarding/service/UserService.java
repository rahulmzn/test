package com.neom.fss.neompay.onboarding.service;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.onboarding.model.SearchResponse;
import com.neom.fss.neompay.onboarding.repository.entity.Applicant;

public interface UserService {

    boolean userExists(UserType userType, String mobileNumber);

    Applicant getApplicantDummy(String iqamaId, String birthDate);

    SearchResponse contactSearch(String searchParam, UserType userType);
}
