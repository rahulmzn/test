package com.neom.fss.neompay.onboarding.constants;

import lombok.Getter;

@Getter
public enum OtpStatus {
    SUCCESS,
    FAILED
}
