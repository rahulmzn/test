package com.neom.fss.neompay.onboarding.client.idauth.dto;

import lombok.Getter;

@Getter
public enum RequestedByKey {
    CUSTOMER_APPLICATION_ID,
    MERCHANT_APPLICATION_ID,
    CUSTOMER_ID,
    MERCHANT_ID,
    STEP_UP_TXN_ID,
    ANY_OTHER_ID
}
