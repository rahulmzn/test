package com.neom.fss.neompay.onboarding.service;

import com.neom.fss.neompay.onboarding.model.MerchantSubmissionRequest;
import com.neom.fss.neompay.onboarding.model.RegistrationRequest;
import com.neom.fss.neompay.onboarding.model.RegistrationResponse;
import com.neom.fss.neompay.onboarding.model.SubmissionRequest;
import com.neom.fss.neompay.onboarding.model.SubmissionResponse;

public interface RegistrationService {

    RegistrationResponse registerUser(RegistrationRequest request);

    SubmissionResponse submitApplication(String applicationId, SubmissionRequest request);

    SubmissionResponse submitMerchantApplication(String applicationId, MerchantSubmissionRequest request);
}
