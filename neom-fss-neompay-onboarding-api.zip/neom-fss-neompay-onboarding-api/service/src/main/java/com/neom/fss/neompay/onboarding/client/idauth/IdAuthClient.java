package com.neom.fss.neompay.onboarding.client.idauth;

import com.neom.fss.neompay.onboarding.client.idauth.dto.GenerateOtpRequestDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.GenerateOtpResponseDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationRequestDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationResponseDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.UserProfileRequestDto;

public interface IdAuthClient {

    GenerateOtpResponseDto generateAndSendOtp(GenerateOtpRequestDto request);

    OtpVerificationResponseDto verifyOtp(OtpVerificationRequestDto request);

    void createUserProfileWithPin(UserProfileRequestDto request);
}
