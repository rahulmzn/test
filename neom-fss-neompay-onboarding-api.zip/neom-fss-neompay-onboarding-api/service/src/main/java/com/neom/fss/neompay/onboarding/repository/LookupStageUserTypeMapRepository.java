package com.neom.fss.neompay.onboarding.repository;


import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.onboarding.repository.entity.StageUserTypeLookup;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LookupStageUserTypeMapRepository extends
    JpaRepository<StageUserTypeLookup, Integer> {

    Optional<StageUserTypeLookup> findByStageNameAndUserType(String stageName,
        UserType userType);

    List<StageUserTypeLookup> findByUserType(UserType userType);

}
