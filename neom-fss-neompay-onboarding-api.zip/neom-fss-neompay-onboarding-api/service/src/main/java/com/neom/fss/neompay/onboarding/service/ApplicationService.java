package com.neom.fss.neompay.onboarding.service;

import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.repository.entity.ApplicationStageHistory;

public interface ApplicationService {

    Application getApplicationById(String applicationId);

    Application save(Application application);

    ApplicationStageHistory saveToHistory(Application application);

}
