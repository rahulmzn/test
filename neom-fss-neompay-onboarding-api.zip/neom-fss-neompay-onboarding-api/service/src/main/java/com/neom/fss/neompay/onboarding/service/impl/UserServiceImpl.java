package com.neom.fss.neompay.onboarding.service.impl;

import com.neom.fss.neompay.crosscuttinglib.client.user.CustomerServiceClient;
import com.neom.fss.neompay.crosscuttinglib.client.user.MerchantServiceClient;
import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.NoData;
import com.neom.fss.neompay.onboarding.client.comviva.ComvivaClient;
import com.neom.fss.neompay.onboarding.constants.ErrorCodes;
import com.neom.fss.neompay.onboarding.mapper.ApplicantMapper;
import com.neom.fss.neompay.onboarding.mapper.ComvivaMapper;
import com.neom.fss.neompay.onboarding.model.SearchResponse;
import com.neom.fss.neompay.onboarding.repository.entity.Applicant;
import com.neom.fss.neompay.onboarding.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final CustomerServiceClient customerServiceClient;
    private final MerchantServiceClient merchantServiceClient;
    private final ApplicantMapper applicantMapper;
    private final ComvivaClient comvivaClient;
    private final ComvivaMapper comvivaMapper;

    @Override
    public boolean userExists(UserType userType, String mobileNumber) {

        try {
            switch (userType) {
                case CUSTOMER:
                    customerServiceClient.getCustomerByMobileNumber(mobileNumber);
                    break;
                case MERCHANT:
                    merchantServiceClient.getMerchantByMobileNumber(mobileNumber);
                    break;
                default:
                    throw new BadInput("Unhandled User Type: " + userType);
            }
        } catch (NoData e) {
            return false;
        }

        return true;
    }

    @Override
    public Applicant getApplicantDummy(String iqamaId, String birthDate) {

        Applicant applicant;

        if (iqamaId.startsWith("1")) {
            var ksaCitizen = customerServiceClient.getKsaCitizen(iqamaId, birthDate);
            applicant = applicantMapper.toEntity(ksaCitizen);
        } else if (iqamaId.startsWith("2")) {
            var expatCitizen = customerServiceClient.getExpatCitizen(iqamaId, birthDate);
            applicant = applicantMapper.toEntity(expatCitizen);
        } else {
            throw new BadInput("Invalid Iqama ID: " + iqamaId);
        }

        return applicant;
    }

    @Override
    public SearchResponse contactSearch(String searchParam, UserType userType) {
        boolean resourceAvailable = false;
        SearchResponse searchResponse = null;
        var contactSearchResponse = comvivaClient.contactSearch(searchParam);
        if (contactSearchResponse.getStatus().equals("SUCCEEDED")
                && !contactSearchResponse.getUsers().isEmpty()) {
            searchResponse = comvivaMapper.mapResponseDtoToSearchResponse(contactSearchResponse);
            if (userType.name().equalsIgnoreCase("customer")) {
                resourceAvailable = contactSearchResponse.getUsers().stream()
                        .anyMatch(x -> x.getCategoryName().equalsIgnoreCase("subscriber"));

            } else if (userType.name().equalsIgnoreCase("merchant")) {
                resourceAvailable = contactSearchResponse.getUsers().stream()
                        .anyMatch(x -> x.getCategoryName().equalsIgnoreCase("merchant"));

            }
            if (!resourceAvailable) {
                throw new BadInput(ErrorCodes.NO_DATA_FOUND.getCode());
            }
        } else {
            throw new BadInput(ErrorCodes.NO_DATA_FOUND.getCode());
        }
        return searchResponse;
    }


}

