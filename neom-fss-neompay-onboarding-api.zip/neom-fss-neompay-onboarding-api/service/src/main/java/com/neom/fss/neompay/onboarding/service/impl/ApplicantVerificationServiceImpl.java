package com.neom.fss.neompay.onboarding.service.impl;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.NoData;
import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import com.neom.fss.neompay.onboarding.constants.ErrorCodes;
import com.neom.fss.neompay.onboarding.constants.OtpStatus;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationRequest;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationResponse;
import com.neom.fss.neompay.onboarding.repository.ApplicantRepository;
import com.neom.fss.neompay.onboarding.repository.entity.Applicant;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.service.ApplicantVerificationService;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import com.neom.fss.neompay.onboarding.service.UserService;
import java.util.Optional;
import java.util.logging.Level;

import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Flogger
public class ApplicantVerificationServiceImpl implements ApplicantVerificationService {

    private final ApplicantRepository applicantRepository;
    private final ApplicationService applicationService;
    private final UserService userService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicantVerificationResponse verifyApplicant(String applicationId,
        ApplicantVerificationRequest request) {

        log.at(Level.INFO).log("Fetching the registration Application by ID: %s", applicationId);
        Application application = applicationService.getApplicationById(applicationId);

        log.atInfo().log("Verifying (using Yakeen) the Applicant by Iqama ID: %s", request.getIqamaId());
        recreateApplicant(applicationId, request.getIqamaId(), request.getBirthDate());

        application.setStage(ApplicationStage.YAKEEN_RECEIVED);
        applicationService.save(application);

        return new ApplicantVerificationResponse(application.getApplicationId(), OtpStatus.SUCCESS);
    }

    @Override
    public Applicant getApplicantInformation(String applicationId) {
        Optional<Applicant> applicantOptional = applicantRepository.findByApplicationId(applicationId);
        if (applicantOptional.isPresent()) {
            return applicantOptional.get();
        } else {
            throw new NoData(ErrorCodes.USER_UNAVAILABLE.getCode());
        }
    }

    private void recreateApplicant(String applicationId, String iqamaId, String birthDate) {
        Applicant applicant;
        var applicantOptional = applicantRepository.findByApplicationId(applicationId);
        if (applicantOptional.isPresent()) {
            applicantRepository.delete(applicantOptional.get());
            applicantRepository.flush();
        }
        applicant = userService.getApplicantDummy(iqamaId, birthDate);
        applicant.setApplicationId(applicationId);
        applicantRepository.save(applicant);
    }
}
