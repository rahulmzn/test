package com.neom.fss.neompay.onboarding.mapper;

import com.neom.fss.neompay.onboarding.client.idauth.dto.UserProfileRequestDto;
import com.neom.fss.neompay.onboarding.model.ApplicantDetail;
import java.util.Objects;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface IdAuthMapper {
    @Mapping(target = "firstName", source = "applicantDetail.englishFirstName")
    @Mapping(target = "lastName", source = "applicantDetail", qualifiedByName = "mapEnglishLastName")
    @Mapping(target = "emailAddress.email", source = "applicantDetail.email")
    @Mapping(target = "enabled", constant = "true")
    @Mapping(target = "username", source = "applicantDetail.mobileNo")
    @Mapping(target = "userType", source = "applicantDetail.userType")
    @Mapping(target = "userPin", source = "applicantDetail.userPin")
    @Mapping(target = "temporaryPin", source = "applicantDetail.temporaryPin")
    @Mapping(target = "attributes.userRole", source = "applicantDetail.userRole")
    @Mapping(target = "attributes.deviceId", source = "applicantDetail.deviceDetail.deviceId")
    @Mapping(target = "attributes.userId", source = "applicantDetail.userId")
    UserProfileRequestDto mapModelToRequestDto(ApplicantDetail applicantDetail);

    @Named("mapEnglishLastName")
    default String mapEnglishLastName(ApplicantDetail applicantDetail) {
        String englishLastName = applicantDetail.getEnglishLastName();
        if(Objects.isNull(englishLastName)){
            return "NA";
        } else {
            return englishLastName.isBlank() ? "NA" : englishLastName;
        }
    }
}
