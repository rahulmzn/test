package com.neom.fss.neompay.onboarding.controller.definition;


import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponse;
import com.neom.fss.neompay.onboarding.config.SwaggerConfig.ServiceTags;
import com.neom.fss.neompay.onboarding.model.RayahOtpRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpResponse;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/registration/v1.0")
@Api(tags = {ServiceTags.RAYAH_API})
public interface RayahOtpApi {

    @ApiOperation(value = "Generate and Send Rayah OTP")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "OTP Generated", response = RayahOtpResponse.class),
        @ApiResponse(code = 404, message = "Application Not Found", response = ErrorResponse.class)
    })
    @PatchMapping(
        value = "/applications/{applicationId}/rayah-one-time-pins",
        produces = {MediaType.APPLICATION_JSON_VALUE},
        consumes = {MediaType.APPLICATION_JSON_VALUE}
    )
    ResponseEntity<RayahOtpResponse> generateOtp(
        @ApiParam(value = "Application ID", required = true) @PathVariable("applicationId") @NotBlank String applicationId,
        @ApiParam(value = "Rayah OTP Generation Request", required = true) @Valid @RequestBody RayahOtpRequest request);

    @ApiOperation(value = "Verify Rayah OTP")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "OTP Verified", response = RayahOtpVerificationResponse.class),
        @ApiResponse(code = 404, message = "Application Not Found", response = ErrorResponse.class)
    })
    @PatchMapping(
        value = "/applications/{applicationId}/rayah-otp-verifications",
        produces = {MediaType.APPLICATION_JSON_VALUE},
        consumes = {MediaType.APPLICATION_JSON_VALUE}
    )
    ResponseEntity<RayahOtpVerificationResponse> verifyOtp(
        @ApiParam(value = "Application ID", required = true) @PathVariable("applicationId") @NotBlank String applicationId,
        @ApiParam(value = "Rayah OTP Verification Request", required = true) @Valid @RequestBody RayahOtpVerificationRequest request);

}
