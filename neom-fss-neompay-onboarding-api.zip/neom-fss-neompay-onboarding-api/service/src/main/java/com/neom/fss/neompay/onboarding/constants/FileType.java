package com.neom.fss.neompay.onboarding.constants;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum FileType {

    PDF("pdf"),
    JPEG("jpeg"),
    JPG("jpg"),
    PNG("png");

    private final String type;

    public static void isValid(String fileExtension) {
        var fileType = Arrays.stream(values())
            .filter(enumType -> enumType.getType().equalsIgnoreCase(fileExtension))
            .findFirst();
        if (fileType.isEmpty()) {
            throw new BadInput(ErrorCodes.INVALID_FILE_TYPE.getCode());
        }
    }
}
