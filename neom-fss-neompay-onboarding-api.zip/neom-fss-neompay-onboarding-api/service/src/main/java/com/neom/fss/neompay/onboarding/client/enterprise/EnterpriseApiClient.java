package com.neom.fss.neompay.onboarding.client.enterprise;

public interface EnterpriseApiClient {


}
