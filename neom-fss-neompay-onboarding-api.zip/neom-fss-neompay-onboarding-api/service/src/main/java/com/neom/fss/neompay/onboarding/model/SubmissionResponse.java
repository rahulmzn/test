package com.neom.fss.neompay.onboarding.model;

import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SubmissionResponse {

    @ApiModelProperty(value = "Application Id", required = true)
    private String applicationId;

    @ApiModelProperty(value = "User On-boarding Stage", required = true)
    private ApplicationStage stage;
}
