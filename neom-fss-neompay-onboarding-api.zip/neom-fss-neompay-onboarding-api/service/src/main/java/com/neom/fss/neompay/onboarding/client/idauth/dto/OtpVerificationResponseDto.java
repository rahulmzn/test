package com.neom.fss.neompay.onboarding.client.idauth.dto;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.onboarding.constants.OtpServiceType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OtpVerificationResponseDto {

    private String otpRefId;

    private boolean isVerified;

    private String mobileNumber;

    private String iqamaId;

    private OtpTemplateType otpTemplateType;

    private OtpServiceType otpServiceType;

    private RequestedByKey requestedByKey;

    private String requestedByValue;

    private UserType userType;

    private String sentTo;

}
