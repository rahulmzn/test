package com.neom.fss.neompay.onboarding.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DeviceDetail {
    private String appName;
    private Double appVersion;
    private String browser;
    private String deviceId;
    private Double latitude;
    private Double longitude;
    private String macAddress;
    private String model;
    private String networkOperator;
    private String networkType;
    private String os;
    private String providerIpAddress;
}
