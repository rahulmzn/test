package com.neom.fss.neompay.onboarding.controller.definition;

import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponse;
import com.neom.fss.neompay.onboarding.config.SwaggerConfig.ServiceTags;
import com.neom.fss.neompay.onboarding.model.Value;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/picklists/v1.0")
@Api(tags = {ServiceTags.PICKLIST_API})
public interface PickListApi {

    @ApiOperation(value = "Fetch dropdown values for Customer")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 404, message = "Data Not Found", response = ErrorResponse.class),
        @ApiResponse(code = 400, message = "Bad Input", response = ErrorResponse.class)
    })
    @GetMapping(value = "/customers")
    ResponseEntity<Map<String, List<Value>>> picklistDataForCustomer();
}
