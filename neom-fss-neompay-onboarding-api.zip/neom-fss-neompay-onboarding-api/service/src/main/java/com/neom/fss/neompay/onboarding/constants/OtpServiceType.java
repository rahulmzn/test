package com.neom.fss.neompay.onboarding.constants;

import lombok.Getter;

@Getter
public enum OtpServiceType {
    RAYAH,
    SMS,
    EMAIL
}
