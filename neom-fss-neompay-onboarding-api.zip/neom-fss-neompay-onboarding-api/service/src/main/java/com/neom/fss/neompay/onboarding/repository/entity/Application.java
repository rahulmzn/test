package com.neom.fss.neompay.onboarding.repository.entity;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.onboarding.client.idauth.dto.RequestedByKey;
import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Getter
@Setter
@Generated
@NoArgsConstructor
@Table(name = "application")
@EntityListeners(AuditingEntityListener.class)
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String applicationId;

    @Enumerated(EnumType.STRING)
    private UserType userType;

    private String userId;

    private String mobileNo;

    @Enumerated(EnumType.STRING)
    private RequestedByKey requestedByKey;

    private String requestedByValue;

    @Enumerated(EnumType.STRING)
    private ApplicationStage stageName;

    private String intlSanction;

    private String riskRating;

    private String tokenJti;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdTs;

    @LastModifiedDate
    @Column(insertable = false)
    private LocalDateTime updatedTs;

    private String emailId;

    @OneToMany(mappedBy = "application", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Set<ApplicationStageHistory> applicationStageHistories = new HashSet<>();

    public Application(String applicationId, String mobileNo, UserType userType) {
        this.applicationId = applicationId;
        this.mobileNo = mobileNo;
        this.userType = userType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Application that = (Application) o;
        return applicationId.equals(that.applicationId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(applicationId);
    }

    public boolean setStage(ApplicationStage applicationStage) {
        this.stageName = applicationStage;
        return this.applicationStageHistories.add(new ApplicationStageHistory(this, applicationStage));
    }
}
