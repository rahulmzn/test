package com.neom.fss.neompay.onboarding.mapper;

import com.neom.fss.neompay.onboarding.client.comviva.dto.*;
import com.neom.fss.neompay.onboarding.config.MerchantSignupConfig;
import com.neom.fss.neompay.onboarding.config.UserSignupConfig;
import com.neom.fss.neompay.onboarding.model.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ComvivaMapper {

    //Payload - Device
    @Mapping(target = "payload.deviceInfo.appName", source = "applicantDetail.deviceDetail.appName")
    @Mapping(target = "payload.deviceInfo.appVersion", source = "applicantDetail.deviceDetail.appVersion")
    @Mapping(target = "payload.deviceInfo.browser", source = "applicantDetail.deviceDetail.browser")
    @Mapping(target = "payload.deviceInfo.deviceId", source = "applicantDetail.deviceDetail.deviceId")
    @Mapping(target = "payload.deviceInfo.isPublicDevice", source = "userSignupConfig.publicDevice")
    @Mapping(target = "payload.deviceInfo.latitude", source = "applicantDetail.deviceDetail.latitude")
    @Mapping(target = "payload.deviceInfo.longitude", source = "applicantDetail.deviceDetail.longitude")
    @Mapping(target = "payload.deviceInfo.mac", source = "applicantDetail.deviceDetail.macAddress")
    @Mapping(target = "payload.deviceInfo.model", source = "applicantDetail.deviceDetail.model")
    @Mapping(target = "payload.deviceInfo.networkOperator", source = "applicantDetail.deviceDetail.networkOperator")
    @Mapping(target = "payload.deviceInfo.networkType", source = "applicantDetail.deviceDetail.networkType")
    @Mapping(target = "payload.deviceInfo.os", source = "applicantDetail.deviceDetail.os")
    @Mapping(target = "payload.deviceInfo.providerIpAddress", source = "applicantDetail.deviceDetail.providerIpAddress")

    //Payload - User - Employment
    @Mapping(target = "payload.userInformation.employmentDetail.occupation", source = "applicantDetail.sourceOfIncome")

    //Payload - User - Workspace
    @Mapping(target = "payload.userInformation.workspaceInformation.workspace", source = "userSignupConfig.workspaceValue")
    @Mapping(target = "payload.userInformation.workspaceInformation.categoryCode", source = "userSignupConfig.workspaceCatCode")
    @Mapping(target = "payload.userInformation.workspaceInformation.categoryName", source = "userSignupConfig.workspaceCatName")

    //Payload - Profile
    @Mapping(target = "payload.profileDetails.authProfile", source = "userSignupConfig.authProfile")
    @Mapping(target = "payload.profileDetails.marketingProfile", source = "userSignupConfig.marketingProfile")
    @Mapping(target = "payload.profileDetails.regulatoryProfile", source = "applicantDetail.kyc")
    @Mapping(target = "payload.profileDetails.securityProfile", source = "userSignupConfig.securityProfile")

    //Payload - User - Basic Information
    @Mapping(target = "payload.userInformation.basicInformation.address1", source = "userSignupConfig.address1")
    @Mapping(target = "payload.userInformation.basicInformation.attr5", source = "applicantDetail.sourceOfIncome")
    @Mapping(target = "payload.userInformation.basicInformation.attr7", source = "applicantDetail.salaryRange")
    @Mapping(target = "payload.userInformation.basicInformation.attr8", source = "applicantDetail.employmentStatus")
    @Mapping(target = "payload.userInformation.basicInformation.attr10", source = "userSignupConfig.attr10")
    @Mapping(target = "payload.userInformation.basicInformation.authenticationIdType", source = "userSignupConfig.authenticationIdType")
    @Mapping(target = "payload.userInformation.basicInformation.authenticationValue", source = "applicantDetail.userPin")
    @Mapping(target = "payload.userInformation.basicInformation.city", source = "userSignupConfig.city")
    @Mapping(target = "payload.userInformation.basicInformation.country", source = "userSignupConfig.country")
    @Mapping(target = "payload.userInformation.basicInformation.dateOfBirth", source = "applicantDetail.englishBirthDate")
    @Mapping(target = "payload.userInformation.basicInformation.emailId", source = "applicantDetail.email")
    @Mapping(target = "payload.userInformation.basicInformation.firstName", source = "applicantDetail.englishFirstName")
    @Mapping(target = "payload.userInformation.basicInformation.lastName", source = "applicantDetail.englishLastName", qualifiedByName = "mapEnglishLastName")
    @Mapping(target = "payload.userInformation.basicInformation.fatherName", source = "applicantDetail.fatherName")
    @Mapping(target = "payload.userInformation.basicInformation.loginId", source = "userSignupConfig.loginId")
    @Mapping(target = "payload.userInformation.basicInformation.mobileNumber", source = "applicantDetail.mobileNo")
    @Mapping(target = "payload.userInformation.basicInformation.nationality", source = "applicantDetail.nationality", qualifiedByName = "mapNationalityCode")
    @Mapping(target = "payload.userInformation.basicInformation.preferredLanguage", source = "applicantDetail.preferredLanguage")
    @Mapping(target = "payload.userInformation.basicInformation.remarks", source = "userSignupConfig.remarks")
    @Mapping(target = "payload.userInformation.basicInformation.residenceCountry", source = "applicantDetail.nationality", qualifiedByName = "mapNationalityCode")
    //Payload - KYC
    @Mapping(target = "payload.kycs", source = "applicantDetail", qualifiedByName = "mapKycInformation")
    //Source
    @Mapping(target = "source", source = "applicantDetail.source")
    ComvivaOnboardRequestDto mapModelToRequestDto(ApplicantDetail applicantDetail,
        UserSignupConfig userSignupConfig);

    ComvivaRegistrationResponse mapDtoToResponseModel(
        ComvivaOnboardResponseDto comvivaOnboardResponseDto);


    @Named("mapKycInformation")
    default List<Kyc> mapKycInformation(ApplicantDetail applicantDetail) {
        List<Kyc> kycList = new ArrayList<>();
        Kyc kyc = new Kyc();
        kyc.setIsPrimaryKYCId("Yes");
        kyc.setKycGracePeriod(30);
        kyc.setKycIdIssueCountry("SA");
        kyc.setKycIdIssuePlace("Neom");
        kyc.setKycIdType("GOVT_ID");
        kyc.setKycIdValidTo(applicantDetail.getIdExpiryDate().toString());
        kyc.setKycIdValue(applicantDetail.getIqamaId());

        kycList.add(kyc);

        return kycList;
    }

    DeviceDetail mapDeviceInfoRequestToModel(DeviceInfoRequest deviceInfoRequest);

    @Named("mapNationalityCode")
    default String mapNationalityCode(String nationality) {
        return nationality.equals("KSA") ? "SA" : nationality;
    }

    @Named("mapEnglishLastName")
    default String mapEnglishLastName(String englishLastName) {
        if(Objects.isNull(englishLastName)){
            return "NA";
        } else {
            return englishLastName.isBlank() ? "NA" : englishLastName;
        }
    }


    //Payload - User - Basic Information
    @Mapping(target = "payload.userInformation.basicInformation.address1", source = "merchantSignupConfig.address1")
    @Mapping(target = "payload.userInformation.basicInformation.allowedDays", source = "merchantSignupConfig.allowedDays")
    @Mapping(target = "payload.userInformation.basicInformation.cif", source = "merchantSignupConfig.cif")
    @Mapping(target = "payload.userInformation.basicInformation.isTransferReversalRequired", source = "merchantSignupConfig.isTransferReversalRequired")
    @Mapping(target = "payload.userInformation.basicInformation.merchantCodeRequired", source = "merchantSignupConfig.merchantCodeRequired")
    @Mapping(target = "payload.userInformation.basicInformation.merchantType", source = "merchantSignupConfig.merchantType")
    @Mapping(target = "payload.userInformation.basicInformation.attr1", source = "applicantDetail.monthlyTransactionVolume")
    @Mapping(target = "payload.userInformation.basicInformation.attr2", source = "applicantDetail.monthlyTransactionValue")
    @Mapping(target = "payload.userInformation.basicInformation.authenticationIdType", source = "merchantSignupConfig.authenticationIdType")
    @Mapping(target = "payload.userInformation.basicInformation.authenticationValue", source = "merchantSignupConfig.authenticationValue")
    @Mapping(target = "payload.userInformation.basicInformation.city", source = "merchantSignupConfig.city")
    @Mapping(target = "payload.userInformation.basicInformation.businessCategory", source = "applicantDetail.businessCategory")
    @Mapping(target = "payload.userInformation.basicInformation.country", source = "merchantSignupConfig.country")
    @Mapping(target = "payload.userInformation.basicInformation.emailId", source = "applicantDetail.email")
    @Mapping(target = "payload.userInformation.basicInformation.firstName", source = "applicantDetail.companyName")
    @Mapping(target = "payload.userInformation.basicInformation.lastName", source = "applicantDetail.companyName")
    @Mapping(target = "payload.userInformation.basicInformation.fatherName", source = "applicantDetail.seniorManagement", qualifiedByName = "mapSeniorManagement")
    @Mapping(target = "payload.userInformation.basicInformation.latitude", source = "applicantDetail.latitude")
    @Mapping(target = "payload.userInformation.basicInformation.loginId", source = "merchantSignupConfig.loginId")
    @Mapping(target = "payload.userInformation.basicInformation.longitude", source = "applicantDetail.longitude")
    @Mapping(target = "payload.userInformation.basicInformation.merchantCode", source = "applicantDetail.mobileNo")
    @Mapping(target = "payload.userInformation.basicInformation.referenceId", source = "applicantDetail.companyType")
    @Mapping(target = "payload.userInformation.basicInformation.mobileNumber", source = "applicantDetail.mobileNo")
    @Mapping(target = "payload.userInformation.basicInformation.nationality", source = "merchantSignupConfig.country")
    @Mapping(target = "payload.userInformation.basicInformation.preferredLanguage", source = "applicantDetail.preferredLanguage")
    @Mapping(target = "payload.userInformation.basicInformation.remarks", source = "merchantSignupConfig.remarks")
    @Mapping(target = "payload.userInformation.basicInformation.residenceCountry", source = "merchantSignupConfig.country")
    @Mapping(target = "payload.userInformation.basicInformation.title", source = "applicantDetail.gender", qualifiedByName = "mapGenderAsTitle")
    @Mapping(target = "payload.userInformation.basicInformation.merchantClassificationCode", source = "applicantDetail.companyType")
    @Mapping(target = "payload.partnerData", source = "applicantDetail", qualifiedByName = "mapSeniorManagementToPartnerData")
    @Mapping(target = "payload.partnerDataSecond", source = "applicantDetail", qualifiedByName = "mapSeniorManagementToPartnerDataSecond")
    @Mapping(target = "payload.partnerDataThird", source = "applicantDetail", qualifiedByName = "mapSeniorManagementToPartnerDataThird")

    //Payload - User - Catalogue Information
    @Mapping(target = "payload.userInformation.catalogueInformation.catalogueId", source = "merchantSignupConfig.catalogueId")
    //Payload - User - Workspace
    @Mapping(target = "payload.userInformation.workspaceInformation.workspace", source = "merchantSignupConfig.workspaceValue")
    @Mapping(target = "payload.userInformation.workspaceInformation.categoryCode", source = "merchantSignupConfig.workspaceCatCode")
    @Mapping(target = "payload.userInformation.workspaceInformation.categoryName", source = "merchantSignupConfig.workspaceCatName")
    //Payload - KYC
    @Mapping(target = "payload.kycs", source = "applicantDetail", qualifiedByName = "mapBusinessKycInformation")
    //Payload - Hierarchy Information
    @Mapping(target = "payload.hierarchyInformation.parentId", source = "merchantSignupConfig.parentId")
    //Payload - Profile
    @Mapping(target = "payload.profileDetails.authProfile", source = "merchantSignupConfig.authProfile")
    @Mapping(target = "payload.profileDetails.marketingProfile", source = "merchantSignupConfig.marketingProfile")
    @Mapping(target = "payload.profileDetails.regulatoryProfile", source = "merchantSignupConfig.regulatoryProfile")
    @Mapping(target = "payload.profileDetails.securityProfile", source = "merchantSignupConfig.securityProfile")
    //Payload - Employment
    @Mapping(target = "payload.employmentDetail.employerName", source = "merchantSignupConfig.employerName")
    //Source
    @Mapping(target = "source", source = "applicantDetail.source")
    ComvivaBusinessOnboardRequestDto mapBusinessModelToRequestDto(BusinessApplicantDetail applicantDetail,
        MerchantSignupConfig merchantSignupConfig);

    @Named("mapBusinessKycInformation")
    default List<Kyc> mapBusinessKycInformation(BusinessApplicantDetail applicantDetail) {
        List<Kyc> kycList = new ArrayList<>();

        Kyc kyc = new Kyc();
        kyc.setIsPrimaryKYCId("Yes");
        kyc.setKycGracePeriod(30);
        kyc.setKycIdIssueCountry("SA");
        kyc.setKycIdIssuePlace("Neom");
        kyc.setKycIdType("GOVT_ID");
        kyc.setKycIdValidTo("2030-05-30");
        kyc.setKycIdValue(applicantDetail.getCompanyRegistrationNo());
        kyc.setKycImageUrl(applicantDetail.getCompanyRegistrationDocUrl());

        kycList.add(kyc);
        return kycList;
    }

    @Mapping(target = "kycIdType" ,expression = "java(contactSearchResponse.getUsers().get(0).getKycIdType())")
    @Mapping(target = "kycIdValue" ,expression = "java(contactSearchResponse.getUsers().get(0).getKycIdValue())")
    @Mapping(target = "dateOfBirth" ,expression = "java(contactSearchResponse.getUsers().get(0).getDateOfBirth())")
    @Mapping(target = "emailId" ,expression = "java(contactSearchResponse.getUsers().get(0).getEmailId())")
    @Mapping(target = "mobile" ,expression = "java(contactSearchResponse.getUsers().get(0).getMsisdn())")
    SearchResponse mapResponseDtoToSearchResponse(ContactSearchResponseDto contactSearchResponse);

    @Named("mapGenderAsTitle")
    default String mapGenderAsTitle(Character gender) {
        if(gender.toString().equals("M")){
            return "PR_MR";
        } else {
            return "PR_MS";
        }
    }

    @Named("mapSeniorManagement")
    default String mapSeniorManagement(List<Management> seniorManagements) {
        if (Objects.nonNull(seniorManagements) && !seniorManagements.isEmpty()) {
            return seniorManagements.stream()
                .map(Management::getName)
                .collect(Collectors.joining("-"));
        } else {
            return "NA";
        }

    }

    @Named("mapSeniorManagementToPartnerData")
    default List<PartnerData> mapSeniorManagementToPartnerData(BusinessApplicantDetail applicantDetail) {
        List<Management> seniorManagements = applicantDetail.getSeniorManagement();
        if (Objects.nonNull(seniorManagements) && !seniorManagements.isEmpty()) {
            PartnerData partnerData = new PartnerData();
            partnerData.setPartnerName(seniorManagements.get(0).getName());
            partnerData.setPartnerImageUrl(seniorManagements.get(0).getSeniorManagementDocUrl());
            partnerData.setBeneficiaryImageUrl(seniorManagements.get(0).getBeneficialOwnerDocUrl());
            partnerData.setPartnerIdType("GOVT_ID");
            partnerData.setPartnerIdValue(applicantDetail.getCompanyRegistrationNo());
            return List.of(partnerData);
        }
        return Collections.emptyList();
    }

    @Named("mapSeniorManagementToPartnerDataSecond")
    default List<PartnerDataSecond> mapSeniorManagementToPartnerDataSecond(BusinessApplicantDetail applicantDetail) {
        List<Management> seniorManagements = applicantDetail.getSeniorManagement();
        if (Objects.nonNull(seniorManagements)  && seniorManagements.size() >= 2) {
            PartnerDataSecond partnerData = new PartnerDataSecond();
            partnerData.setPartnerSecondName(seniorManagements.get(1).getName());
            partnerData.setPartnerSecondImageUrl(seniorManagements.get(1).getSeniorManagementDocUrl());
            partnerData.setBeneficiaryImageUrlSecond(seniorManagements.get(1).getBeneficialOwnerDocUrl());
            partnerData.setPartnerSecondIdType("GOVT_ID");
            partnerData.setPartnerSecondIdValue(applicantDetail.getCompanyRegistrationNo());
            return List.of(partnerData);
        }
        return Collections.emptyList();
    }

    @Named("mapSeniorManagementToPartnerDataThird")
    default List<PartnerDataThird> mapSeniorManagementToPartnerDataThird(BusinessApplicantDetail applicantDetail) {
        List<Management> seniorManagements = applicantDetail.getSeniorManagement();
        if (Objects.nonNull(seniorManagements) && seniorManagements.size() >= 3) {
            PartnerDataThird partnerData = new PartnerDataThird();
            partnerData.setPartnerThirdName(seniorManagements.get(2).getName());
            partnerData.setPartnerThirdImageUrl(seniorManagements.get(2).getSeniorManagementDocUrl());
            partnerData.setBeneficiaryImageUrlThird(seniorManagements.get(2).getBeneficialOwnerDocUrl());
            partnerData.setPartnerThirdIdType("GOVT_ID");
            partnerData.setPartnerThirdIdValue(applicantDetail.getCompanyRegistrationNo());
            return List.of(partnerData);
        }
        return Collections.emptyList();
    }
}
