package com.neom.fss.neompay.onboarding.model;

import com.neom.fss.neompay.onboarding.constants.OtpStatus;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class RegistrationResponse {

    @ApiModelProperty(value = "Application ID", required = true)
    @NotBlank
    private String applicationId;

    @ApiModelProperty(value = "OTP Reference ID", required = true)
    @NotBlank
    private String otpRefId;

    @ApiModelProperty(value = "OTP Verification Status", required = true)
    @NotNull
    private OtpStatus status;

    @ApiModelProperty(value = "OTP Verification attempts left", required = true)
    @NotNull
    private Integer attemptsLeft;
}
