package com.neom.fss.neompay.onboarding.client.idauth.dto;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.onboarding.constants.OtpServiceType;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class GenerateOtpRequestDto {

    private String iqamaId;

    private String mobileNumber;

    @Enumerated(EnumType.STRING)
    private OtpTemplateType otpTemplateType;

    @Enumerated(EnumType.STRING)
    private OtpServiceType otpServiceType;

    @Enumerated(EnumType.STRING)
    private RequestedByKey requestedByKey;

    private String requestedByValue;

    @Enumerated(EnumType.STRING)
    private UserType userType;

    // Rayah OTP request
    public GenerateOtpRequestDto(String iqamaId, OtpServiceType otpServiceType, OtpTemplateType otpTemplateType,
        UserType userType) {
        this.iqamaId = iqamaId;
        this.otpServiceType = otpServiceType;
        this.userType = userType;
        this.otpTemplateType = otpTemplateType;
    }
}
