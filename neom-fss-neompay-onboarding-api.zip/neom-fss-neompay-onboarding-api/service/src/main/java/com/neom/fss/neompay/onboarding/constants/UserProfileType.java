package com.neom.fss.neompay.onboarding.constants;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum UserProfileType {
    CUSTOMER("customer"),
    MERCHANT("merchant"),
    TOURIST("tourist"),
    CASHIER("cashier");

    private String value;

    public static UserProfileType isValidUserType(String userType) {
        return Arrays.stream(values())
            .filter(enumType -> enumType.getValue().equals(userType))
            .findFirst()
            .orElseThrow(() -> new BadInput("Invalid User Profile Type"));
    }
}
