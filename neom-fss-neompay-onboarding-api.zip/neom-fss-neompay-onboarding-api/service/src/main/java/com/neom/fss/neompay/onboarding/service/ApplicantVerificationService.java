package com.neom.fss.neompay.onboarding.service;

import com.neom.fss.neompay.onboarding.model.ApplicantVerificationRequest;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationResponse;
import com.neom.fss.neompay.onboarding.repository.entity.Applicant;

public interface ApplicantVerificationService {

    ApplicantVerificationResponse verifyApplicant(String applicationId,
        ApplicantVerificationRequest request);

    Applicant getApplicantInformation(String applicationId);
}
