package com.neom.fss.neompay.onboarding.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.onboarding.client.mobiquity.MobiquityClient;
import com.neom.fss.neompay.onboarding.constants.ErrorCodes;
import com.neom.fss.neompay.onboarding.model.Value;
import com.neom.fss.neompay.onboarding.service.PickListService;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
@Flogger
public class PickListServiceImpl implements PickListService {

    private final MobiquityClient mobiquityClient;

    @Override
    @Cacheable(value = "customerPicklistCache")
    public Map<String, List<Value>> picklistData() {
        log.atInfo().log("Fetching Dropdown data for Customer");

        ObjectMapper objectMapper = new ObjectMapper();
        TypeReference<Map<String, List<Value>>> typeReference= new TypeReference<>() {
        };

        var picklistDataResponse = mobiquityClient.mobiquityPickListCustomerData();
        if(StringUtils.hasText(picklistDataResponse)) {
            try{
                return objectMapper.readValue(picklistDataResponse, typeReference);
            } catch (JsonProcessingException e) {
                throw new BadInput(ErrorCodes.INVALID_BODY.getCode());
            }
        } else {
            throw new ServiceException.NoData(ErrorCodes.NO_DATA_FOUND.getCode());
        }
    }
}
