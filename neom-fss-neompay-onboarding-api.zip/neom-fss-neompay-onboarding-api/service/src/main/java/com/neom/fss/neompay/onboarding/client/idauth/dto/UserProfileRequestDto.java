package com.neom.fss.neompay.onboarding.client.idauth.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = "userPin")
public class UserProfileRequestDto {

    private String firstName;
    private String lastName;
    private EmailAddress emailAddress;
    private boolean enabled;
    private String username;
    private AttributesRequestDto attributes;
    private String userType;
    private String userPin;
    private boolean isTemporaryPin;
}
