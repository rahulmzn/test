package com.neom.fss.neompay.onboarding.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ApiModel
public class ManagementDetail {
    @ApiModelProperty(value = "List of Senior Management")
    private List<Management> seniorManagements;
}
