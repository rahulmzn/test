package com.neom.fss.neompay.onboarding.constants;

import lombok.Getter;

@Getter
public enum KycType {
    FULL_KYC,
    NO_KYC,
    UNKNOWN
}
