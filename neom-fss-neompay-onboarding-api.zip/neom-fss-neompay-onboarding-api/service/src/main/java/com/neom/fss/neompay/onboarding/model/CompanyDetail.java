package com.neom.fss.neompay.onboarding.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ApiModel
public class CompanyDetail {
    @ApiModelProperty(value = "Registartion Details")
    @Valid
    private RegistrationDetail registrationInfo;

    @ApiModelProperty(value = "Management Details")
    private ManagementDetail managementDetails;

    @ApiModelProperty(value = "Business Details")
    @Valid
    private BusinessDetail businessInfo;
}
