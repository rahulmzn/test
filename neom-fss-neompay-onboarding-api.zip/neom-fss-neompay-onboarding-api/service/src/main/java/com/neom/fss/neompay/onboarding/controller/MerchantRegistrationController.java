package com.neom.fss.neompay.onboarding.controller;

import com.neom.fss.neompay.onboarding.controller.definition.MerchantRegistrationApi;
import com.neom.fss.neompay.onboarding.model.DocumentUploadRequest;
import com.neom.fss.neompay.onboarding.model.DocumentUploadResponse;
import com.neom.fss.neompay.onboarding.model.MerchantSubmissionRequest;
import com.neom.fss.neompay.onboarding.model.SubmissionResponse;
import com.neom.fss.neompay.onboarding.service.MerchantRegistrationService;
import com.neom.fss.neompay.onboarding.service.RegistrationService;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@RequiredArgsConstructor
public class MerchantRegistrationController implements MerchantRegistrationApi {

    private final MerchantRegistrationService merchantRegistrationService;
    private final RegistrationService registrationService;

    @Override
    public ResponseEntity<DocumentUploadResponse> uploadDocument(String applicationId,
        DocumentUploadRequest documentUploadRequest) throws IOException {
        return ResponseEntity.ok(merchantRegistrationService.uploadDocument(documentUploadRequest, applicationId));
    }

    @Override
    public ResponseEntity<SubmissionResponse> submitMerchantApplication(String applicationId,
        MerchantSubmissionRequest request) {
        SubmissionResponse submissionResponse = registrationService
            .submitMerchantApplication(applicationId, request);
        return new ResponseEntity<>(submissionResponse, HttpStatus.OK);
    }
}
