package com.neom.fss.neompay.onboarding.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DeviceInfoRequest {

    @ApiModelProperty(example = "CUSTOMER", required = true, value = "Application name")
    @NotBlank
    private String appName;

    @ApiModelProperty(example = "10.2", required = true, value = "Application Version")
    @NotBlank
    private Double appVersion;

    @ApiModelProperty(example = "Chrome", value = "Browser Name")
    private String browser;

    @ApiModelProperty(example = "excs-233-daca-312", required = true, value = "Device ID")
    @NotBlank
    private String deviceId;

    @ApiModelProperty(example = "12.3434", required = true, value = "Latitude")
    @NotBlank
    private Double latitude;

    @ApiModelProperty(example = "10.3374", required = true, value = "Longitude")
    @NotBlank
    private Double longitude;

    @ApiModelProperty(example = "00:1B:44:11:3A:B7", value = "MAC Address")
    private String macAddress;

    @ApiModelProperty(example = "Oneplus10", value = "Device Model")
    @NotBlank
    private String model;

    @ApiModelProperty(example = "Orange", value = "Network Operator")
    private String networkOperator;

    @ApiModelProperty(example = "4G", value = "Network Type")
    private String networkType;

    @ApiModelProperty(example = "Android", value = "Operating Platform")
    private String os;

    @ApiModelProperty(example = "10.123.234.345", value = "IP Address")
    private String providerIpAddress;
}
