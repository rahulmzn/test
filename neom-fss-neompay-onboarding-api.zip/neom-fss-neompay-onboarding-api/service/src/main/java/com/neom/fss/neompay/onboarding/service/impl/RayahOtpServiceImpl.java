package com.neom.fss.neompay.onboarding.service.impl;


import com.neom.fss.neompay.onboarding.client.idauth.IdAuthClient;
import com.neom.fss.neompay.onboarding.client.idauth.dto.GenerateOtpRequestDto;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpTemplateType;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationRequestDto;
import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import com.neom.fss.neompay.onboarding.constants.OtpServiceType;
import com.neom.fss.neompay.onboarding.constants.OtpStatus;
import com.neom.fss.neompay.onboarding.model.RayahOtpRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpResponse;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationResponse;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import com.neom.fss.neompay.onboarding.service.RayahOtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class RayahOtpServiceImpl implements RayahOtpService {

    private final IdAuthClient idAuthClient;

    private final ApplicationService applicationService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RayahOtpResponse generateAndSendOtp(String applicationId,
        RayahOtpRequest rayahOtpRequest) {

        Application application = applicationService.getApplicationById(applicationId);

        var generateOtpRequestDto = new GenerateOtpRequestDto(
            rayahOtpRequest.getIqamaId(), OtpServiceType.RAYAH, OtpTemplateType.ONBOARD, application.getUserType());

        // TO -- DO -- remove below setting once rayah integrated
        generateOtpRequestDto.setMobileNumber(application.getMobileNo());

        var otpResponseDto = idAuthClient.generateAndSendOtp(generateOtpRequestDto);

        application.setStage(ApplicationStage.RAYAH_OTP_INIT);
        applicationService.save(application);

        return new RayahOtpResponse(applicationId, otpResponseDto.getOtpRefId(), otpResponseDto.getOtpNumber(),
            otpResponseDto.getResendCounter(), otpResponseDto.getExpiryTime());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RayahOtpVerificationResponse verifyOtp(String applicationId,
        RayahOtpVerificationRequest request) {

        Application application = applicationService.getApplicationById(applicationId);

        var otpVerificationRequest = new OtpVerificationRequestDto(
            request.getOtpRefId(), request.getOtpNumber());

        var otpResponse = idAuthClient.verifyOtp(otpVerificationRequest);

        OtpStatus verificationStatus;
        if (otpResponse.isVerified()) {
            verificationStatus = OtpStatus.SUCCESS;
            application.setStage(ApplicationStage.RAYAH_OTP_VERIFIED);
            applicationService.save(application);
        } else {
            verificationStatus = OtpStatus.FAILED;
        }

        return new RayahOtpVerificationResponse(applicationId, verificationStatus);
    }

}
