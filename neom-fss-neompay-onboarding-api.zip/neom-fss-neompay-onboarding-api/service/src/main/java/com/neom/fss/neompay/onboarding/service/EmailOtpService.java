package com.neom.fss.neompay.onboarding.service;

import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationResponse;

public interface EmailOtpService {

    EmailOtpVerificationResponse verifyEmail(String applicationId,
                                             EmailOtpVerificationRequest request);

}
