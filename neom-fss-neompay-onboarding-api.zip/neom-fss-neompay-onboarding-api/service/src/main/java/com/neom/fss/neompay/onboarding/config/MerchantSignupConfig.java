package com.neom.fss.neompay.onboarding.config;

import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.validation.annotation.Validated;

@PropertySource(value = "classpath:merchantSignupConfig.properties")
@Configuration
@ConfigurationProperties(prefix = "merchant.signup")
@Validated
@Getter
@Setter
public class MerchantSignupConfig {
    @NotBlank
    private String workspaceCatName;
    @NotBlank
    private String workspaceValue;
    @NotBlank
    private String workspaceCatCode;
    @NotBlank
    private String loginId;
    @NotBlank
    private String remarks;
    @NotBlank
    private String primaryKycId;
    @NotBlank
    private String kycIdIssueCountry;
    @NotBlank
    private String kycIdIssuePlace;
    @NotBlank
    private String kycIdType;
    @NotBlank
    private String authenticationIdType;
    private Integer authenticationValue;
    @NotBlank
    private String authProfile;
    @NotBlank
    private String marketingProfile;
    @NotBlank
    private String regulatoryProfile;
    @NotBlank
    private String securityProfile;
    @NotBlank
    private String country;
    @NotBlank
    private String city;
    @NotBlank
    private String address1;
    @NotBlank
    private String parentId;
    @NotBlank
    private String catalogueId;
    @NotBlank
    private String employerName;
    @NotBlank
    private String cif;
    @NotBlank
    private String isTransferReversalRequired;
    @NotBlank
    private String merchantCodeRequired;
    @NotBlank
    private String merchantType;
    @NotBlank
    private String allowedDays;
    @NotBlank
    private String attr1;
    @NotBlank
    private String attr3;
    @NotBlank
    private String attr5;
    @NotBlank
    private String businessCategory;
}
