package com.neom.fss.neompay.onboarding.client.comviva.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ComvivaOnboardRequestDto {

    private Payload payload;
    private String source;
}
