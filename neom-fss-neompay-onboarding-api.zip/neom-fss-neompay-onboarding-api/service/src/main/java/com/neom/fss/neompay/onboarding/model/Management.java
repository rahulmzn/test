package com.neom.fss.neompay.onboarding.model;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.onboarding.constants.ErrorCodes;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ApiModel
public class Management {

    @ApiModelProperty(example = "John Doe",  value = "Senior Management Name")
    private String name;

    @ApiModelProperty(example = "/proof/srManager",  value = "Senior Management Document Url")
    private String seniorManagementDocUrl;

    @ApiModelProperty(example = "/bo/doc",  value = "Beneficial Owner Document Url")
    private String beneficialOwnerDocUrl;

    //implement the logic for putting either proof or beneficialOwner or Both
    public void checkDocUrlAvailable() {
        if(Objects.nonNull(name) && !name.isBlank()
            && Objects.isNull(seniorManagementDocUrl) && Objects.isNull(beneficialOwnerDocUrl)) {
                throw new BadInput(ErrorCodes.MISSING_FIELD.getCode());
        }
    }
}
