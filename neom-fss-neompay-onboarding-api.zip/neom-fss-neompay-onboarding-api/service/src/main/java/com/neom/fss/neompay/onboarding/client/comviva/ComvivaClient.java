package com.neom.fss.neompay.onboarding.client.comviva;

import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaBusinessOnboardRequestDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaOnboardRequestDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ComvivaOnboardResponseDto;
import com.neom.fss.neompay.onboarding.client.comviva.dto.ContactSearchResponseDto;

public interface ComvivaClient {

    ComvivaOnboardResponseDto comvivaSelfRegistration(
        ComvivaOnboardRequestDto comvivaOnboardRequestDto);

    ComvivaOnboardResponseDto merchantSelfRegistration(
        ComvivaBusinessOnboardRequestDto comvivaBusinessOnboardRequestDto);

    ContactSearchResponseDto contactSearch(String searchParameter);
}
