package com.neom.fss.neompay.onboarding.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ApiModel
public class RegistrationDetail {
    @ApiModelProperty(example = "Carrefour UAE", required = true, value = "Name of the Company")
    @NotBlank
    private String companyName;

    @ApiModelProperty(example = "Private", required = true, value = "Type of the Company")
    @NotBlank
    private String companyType;

    @ApiModelProperty(example = "1234567890", required = true, value = "Company's Registration Number")
    @NotBlank
    @Size(max = 10, min = 10)
    @Pattern(regexp = "^[0-9]{1,10}$")
    private String registrationNo;

    @ApiModelProperty(example = "/abc/fileName", required = true, value = "Company's Registration Document Url")
    @NotBlank
    private String registrationDocUrl;
}
