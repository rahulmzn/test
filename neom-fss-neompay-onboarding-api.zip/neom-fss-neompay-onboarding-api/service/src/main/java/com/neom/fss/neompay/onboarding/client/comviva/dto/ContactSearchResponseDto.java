package com.neom.fss.neompay.onboarding.client.comviva.dto;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactSearchResponseDto {
    private String serviceRequestId;
    private String message;
    private String serviceFlow;
    private String status;
    private List<ContactUserDto> users;
}
