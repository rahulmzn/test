package com.neom.fss.neompay.onboarding.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@ApiModel
public class BusinessDetail {
    @ApiModelProperty(example = "Dining", required = true, value = "Business Category")
    @NotBlank
    private String businessCategory;

    @ApiModelProperty(example = "1001 - 5000", required = true, value = "Monthly Volume of transactions")
    @NotBlank
    private String transactionVolume;

    @ApiModelProperty(example = "SAR 5001 - SAR 10000", required = true, value = "Monthly Value of transactions")
    @NotBlank
    private String transactionValue;
}
