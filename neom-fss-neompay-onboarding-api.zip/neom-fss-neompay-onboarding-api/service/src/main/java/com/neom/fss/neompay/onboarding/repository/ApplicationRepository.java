package com.neom.fss.neompay.onboarding.repository;

import com.neom.fss.neompay.onboarding.repository.entity.Application;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {

    Optional<Application> findByApplicationId(String applicationId);

}
