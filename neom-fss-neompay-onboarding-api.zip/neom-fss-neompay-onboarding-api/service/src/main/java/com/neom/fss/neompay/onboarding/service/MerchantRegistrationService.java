package com.neom.fss.neompay.onboarding.service;

import com.neom.fss.neompay.onboarding.model.DocumentUploadRequest;
import com.neom.fss.neompay.onboarding.model.DocumentUploadResponse;
import java.io.IOException;

public interface MerchantRegistrationService {

    DocumentUploadResponse uploadDocument(DocumentUploadRequest documentUploadRequest, String applicationId) throws IOException;

}
