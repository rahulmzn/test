package com.neom.fss.neompay.onboarding.constants;

import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Getter;

@ApiModel
@Getter
@AllArgsConstructor
public enum DocumentType {

    COMPANY_REG_CERT(5, Arrays.stream(FileType.values()).map(Enum::name).collect(Collectors.toList())),
    SR_MGMT(5, Arrays.stream(FileType.values()).map(Enum::name).collect(Collectors.toList())),
    BENEFECIAL_OWNER(5, Arrays.stream(FileType.values()).map(Enum::name).collect(Collectors.toList())),
    OTHER(5, new ArrayList());

    private int sizeinMb;
    private final List<String> type;

}
