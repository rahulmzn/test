package com.neom.fss.neompay.onboarding.repository.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Generated
@Table(name = "applicant")
@EntityListeners(AuditingEntityListener.class)
public class Applicant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String applicationId;

    private String iqamaId;

    private String firstName;
    private String secondName;
    private String thirdName;

    private String fatherName;
    private String grandFatherName;
    private String familyName;

    @Column(name = "en_first_name")
    private String englishFirstName;

    @Column(name = "en_second_name")
    private String englishSecondName;

    @Column(name = "en_third_name")
    private String englishThirdName;

    @Column(name = "en_last_name")
    private String englishLastName;

    private Character gender;

    private String nationality;

    private String hijriBirthDate;

    @Column(name = "en_birth_date")
    private LocalDate englishBirthDate;

    private LocalDate idExpiryDate;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdTs;

    @LastModifiedDate
    @Column(insertable = false)
    private LocalDateTime updatedTs;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Applicant applicant = (Applicant) o;
        return applicationId.equals(applicant.applicationId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(applicationId);
    }

}
