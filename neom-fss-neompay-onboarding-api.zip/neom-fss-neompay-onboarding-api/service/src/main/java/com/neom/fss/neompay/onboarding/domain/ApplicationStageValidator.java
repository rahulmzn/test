package com.neom.fss.neompay.onboarding.domain;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.onboarding.repository.LookupStageUserTypeMapRepository;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.repository.entity.ApplicationStageHistory;
import com.neom.fss.neompay.onboarding.repository.entity.StageUserTypeLookup;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ApplicationStageValidator {

    private final LookupStageUserTypeMapRepository lookupStageUserTypeMapRepository;

    /**
     * Checks all the stages before Submission of the request
     * @param application application entity
     * @return boolean value
     */
    public boolean hasPassedAllStages(Application application) {
        List<StageUserTypeLookup> stageUserTypeLookupList =
            lookupStageUserTypeMapRepository.findByUserType(UserType.valueOf(application.getUserType().name()));
        Set<ApplicationStageHistory> applicationStageHistories = application.getApplicationStageHistories();
        //Checking for Previous Stages
        stageUserTypeLookupList.forEach(lookup -> {
            //Check in Previous Stage
            if(applicationStageHistories.stream().noneMatch(history -> history.getStageName().name().equals(lookup.getStageName()))) {
                throw new BadInput("Stage %s not completed in signup process " + lookup.getStageName());
            }
        });
        return true;
    }

}
