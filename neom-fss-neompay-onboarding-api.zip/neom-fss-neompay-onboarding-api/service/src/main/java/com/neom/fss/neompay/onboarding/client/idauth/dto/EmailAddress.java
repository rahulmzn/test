package com.neom.fss.neompay.onboarding.client.idauth.dto;

import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@ToString
@ApiModel(description = "User's Email Address")
public class EmailAddress {

    @ApiModelProperty(example = "johndoe@gmail.com", value = "Email Address")
    @Email
    private String email;

    @JsonValue
    public String emailInfo() {
        return email;
    }
}
