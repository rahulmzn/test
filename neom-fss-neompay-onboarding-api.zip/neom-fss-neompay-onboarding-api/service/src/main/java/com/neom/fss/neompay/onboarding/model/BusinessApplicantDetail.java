package com.neom.fss.neompay.onboarding.model;


import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BusinessApplicantDetail {

    private String applicationId;
    private String iqamaId;
    private String firstName;
    private String secondName;
    private String thirdName;
    private String fatherName;
    private String grandFatherName;
    private String familyName;
    private String englishFirstName;
    private String englishSecondName;
    private String englishThirdName;
    private String englishLastName;
    private Character gender;
    private String nationality;
    private String hijriBirthDate;
    private LocalDate englishBirthDate;
    private LocalDate idExpiryDate;
    private String mobileNo;
    private String email;
    private String userId;
    //National - expat - tourist
    private String userRole;
    //Customer - Merchant
    private String userType;
    private String source;
    private String preferredLanguage;
    private Double latitude;
    private Double longitude;
    private String companyName;
    private String companyType;
    private String companyRegistrationNo;
    private String companyRegistrationDocUrl;
    private String companyRegistrationDocName;
    private String businessCategory;
    private String monthlyTransactionVolume;
    private String monthlyTransactionValue;
    private List<Management> seniorManagement;

}
