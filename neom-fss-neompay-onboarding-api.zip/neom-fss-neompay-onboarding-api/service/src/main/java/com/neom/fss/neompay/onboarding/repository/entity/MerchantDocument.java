package com.neom.fss.neompay.onboarding.repository.entity;

import com.neom.fss.neompay.onboarding.constants.ApplicationIdType;
import com.neom.fss.neompay.onboarding.constants.DocumentType;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Generated
@Table(name = "merchant_doc_detail")
@EntityListeners(AuditingEntityListener.class)
public class MerchantDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_type", nullable = false)
    @Enumerated(EnumType.STRING)
    private ApplicationIdType idType;

    @Column(name = "id_value", nullable = false)
    private String idValue;

    @Column(name = "mobile", nullable = false)
    private String mobileNo;

    @Column(name = "ext_doc_id", nullable = false)
    private String extDocId;

    @Column(name = "doc_name", nullable = false)
    private String documentName;

    @Column(name = "doc_type", nullable = false)
    @Enumerated(EnumType.STRING)
    private DocumentType documentType;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdTs;

    @UpdateTimestamp
    @Column(insertable = false)
    private LocalDateTime updatedTs;

    public MerchantDocument(ApplicationIdType idType, String idValue, String mobileNo, String extDocId,
        String documentName, DocumentType documentType) {
        this.idType = idType;
        this.idValue = idValue;
        this.mobileNo = mobileNo;
        this.extDocId = extDocId;
        this.documentName = documentName;
        this.documentType = documentType;
    }
}
