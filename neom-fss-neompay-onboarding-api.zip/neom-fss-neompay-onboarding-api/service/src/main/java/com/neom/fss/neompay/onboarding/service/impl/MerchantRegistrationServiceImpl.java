package com.neom.fss.neompay.onboarding.service.impl;

import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.onboarding.client.comviva.dto.DocumentUploadResponseDto;
import com.neom.fss.neompay.onboarding.constants.ApplicationIdType;
import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import com.neom.fss.neompay.onboarding.constants.DocumentType;
import com.neom.fss.neompay.onboarding.model.DocumentUploadRequest;
import com.neom.fss.neompay.onboarding.model.DocumentUploadResponse;
import com.neom.fss.neompay.onboarding.repository.MerchantDocumentRepository;
import com.neom.fss.neompay.onboarding.repository.entity.MerchantDocument;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import com.neom.fss.neompay.onboarding.service.MerchantRegistrationService;
import com.neom.fss.neompay.onboarding.utils.MultipartInputStreamFileResource;
import java.io.IOException;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;

/*
 * TO DO ====
 * This is an exceptional class which has ++service + client++ layer together.
 * Reason being the serialzation issue. Since DocumentUploadRequest.java has a field named Multipart request .
 * When trying to send the object to client layer it's throwing below exception
 * +++++++++++++++++++++++
 * No serializer found for class java.io.FileDescriptor and no properties discovered to create BeanSerializer(to avoid exception, disable SerializationFeature.FAIL_ON_EMPTY_BEANS)
 *  (through reference chain: com.neom.fss.neompay.onboarding.model.DocumentUploadRequest["file"]->
 *  org.springframework.web.multipart.support.StandardMultipartHttpServletRequest$StandardMultipartFile["inputStream"]->java.io.FileInputStream["fd"])
 * +++++++++++++++++++++++
 * we can split if any solution found. TO DO
 */

@Service
@RequiredArgsConstructor
public class MerchantRegistrationServiceImpl implements MerchantRegistrationService {

    private final MerchantDocumentRepository merchantDocumentRepository;
    private final ApplicationService applicationService;

    //@Qualifier("comvivaWebRequestSender")
    private final WebRequestSender webRequestSender;

    // http://52.27.60.51:5000/dms/swagger-ui.html#!/New_Document_Management_System_using_MongoDb/uploadDocumentUsingPOST
    @Value("${services.comviva.doc-upload-url}")
    private String docUploadUrl;

    @Override
    public DocumentUploadResponse uploadDocument(DocumentUploadRequest documentUploadRequest, String applicationId)
        throws IOException {

        var application = applicationService.getApplicationById(applicationId);
        documentUploadRequest.validateFileType();

        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        map.add("file", new MultipartInputStreamFileResource(documentUploadRequest.getFile().getInputStream(),
            documentUploadRequest.getFile().getOriginalFilename()));
        map.add("uploadedBy", documentUploadRequest.getMobileNo());
        map.add("documentType", "KYC");
        map.add("documentName", documentUploadRequest.getFileName());

        var httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.MULTIPART_FORM_DATA_VALUE);

        var customerSignUpURI = UriComponentsBuilder.fromHttpUrl(docUploadUrl).build().toUri();

        var responseDto = webRequestSender.sendPostRequest(customerSignUpURI, map, httpHeaders,
            new ParameterizedTypeReference<DocumentUploadResponseDto>() {
            });

        if (Objects.nonNull(responseDto) && HttpStatus.OK.value() == responseDto.getStatus()) {

            var extDocId = responseDto.getPayload().getDocumentId();

            var merchantDocumentEntity = new MerchantDocument(
                documentUploadRequest.getIdType(),
                documentUploadRequest.getIdValue(),
                documentUploadRequest.getMobileNo(),
                extDocId,
                documentUploadRequest.getFileName(),
                documentUploadRequest.getDocType());
            merchantDocumentRepository.save(merchantDocumentEntity);

            if (ApplicationIdType.MERCHNAT_SIGNUP_APPID.equals(documentUploadRequest.getIdType())
                && DocumentType.COMPANY_REG_CERT.equals(documentUploadRequest.getDocType())) {
                application.setStage(ApplicationStage.COMP_DOC_UPD);
                applicationService.save(application);
            }
            return new DocumentUploadResponse(extDocId, "SUCCESS");
        }
        return new DocumentUploadResponse(null, "FAILED");

    }

}
