package com.neom.fss.neompay.onboarding.service.impl;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.onboarding.constants.ErrorCodes;
import com.neom.fss.neompay.onboarding.repository.ApplicationRepository;
import com.neom.fss.neompay.onboarding.repository.ApplicationStageHistoryRepository;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.repository.entity.ApplicationStageHistory;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ApplicationServiceImpl implements ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final ApplicationStageHistoryRepository applicationStageHistoryRepository;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Application getApplicationById(String applicationId) {
        Optional<Application> applicationOptional = applicationRepository.findByApplicationId(
            applicationId);

        if (applicationOptional.isEmpty()) {
            throw new ServiceException.NoData(ErrorCodes.INVALID_APPLICATION_ID.getCode());
        }

        return applicationOptional.get();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Application save(Application application) {
        return applicationRepository.save(application);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationStageHistory saveToHistory(Application application) {
        ApplicationStageHistory applicationStageHistory = new ApplicationStageHistory(application, application.getStageName());
        return applicationStageHistoryRepository.save(applicationStageHistory);
    }


}
