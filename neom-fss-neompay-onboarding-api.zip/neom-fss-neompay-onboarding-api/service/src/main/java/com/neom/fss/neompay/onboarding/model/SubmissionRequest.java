package com.neom.fss.neompay.onboarding.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString(exclude = "userPin")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SubmissionRequest {

    @ApiModelProperty(example = "Public", required = true, value = "Employment Status")
    @NotBlank
    private String employmentStatus;

    @ApiModelProperty(example = "Employment", required = true, value = "Primary Source of Income")
    @NotEmpty
    private String primarySourceOfIncome;

    @ApiModelProperty(example = "SAR 0 - SAR 5,000", required = true, value = "Income Range (monthly)")
    @NotEmpty
    private String incomeRange;

    @ApiModelProperty(example = "287326", required = true, value = "User PIN")
    @NotBlank
    @Size(min = 6, max = 6)
    private String userPin;

    @ApiModelProperty(example = "287326", required = true, value = "User PIN")
    @NotBlank
    @Size(min = 6, max = 6)
    private String confirmUserPin;

    @ApiModelProperty(example = "johndoe@gmail.com", value = "User Email Address")
    @Email
    private String email;

    @ApiModelProperty(required = true, value = "Device Details")
    private DeviceInfoRequest device;

    @ApiModelProperty(example = "en", required = true, value = "Language preferred")
    @NotEmpty
    private String preferredLanguage;

}
