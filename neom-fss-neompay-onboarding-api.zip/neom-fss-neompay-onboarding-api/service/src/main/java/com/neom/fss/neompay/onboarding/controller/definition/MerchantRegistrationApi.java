package com.neom.fss.neompay.onboarding.controller.definition;


import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponse;
import com.neom.fss.neompay.onboarding.config.SwaggerConfig.ServiceTags;
import com.neom.fss.neompay.onboarding.model.DocumentUploadRequest;
import com.neom.fss.neompay.onboarding.model.DocumentUploadResponse;
import com.neom.fss.neompay.onboarding.model.MerchantSubmissionRequest;
import com.neom.fss.neompay.onboarding.model.SubmissionResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.io.IOException;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/registration/v1.0/applications/")
@Api(tags = {ServiceTags.MERCHANT_REGISTRATION_API})
public interface MerchantRegistrationApi {

    @ApiOperation(value = "Upload Merchant Document to complete user registration")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Document Uploaded", response = DocumentUploadResponse.class),
        @ApiResponse(code = 400, message = "Submission Failed", response = ErrorResponse.class)
    })
    @PostMapping(value = "{applicationId}/documents",
        produces = MediaType.APPLICATION_JSON_VALUE,
        consumes = {MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.APPLICATION_JSON_VALUE})
    ResponseEntity<DocumentUploadResponse> uploadDocument(
        @ApiParam(value = "Application ID", required = true) @PathVariable("applicationId") @NotBlank String applicationId,
        @ApiParam(value = "Document Upload Request", required = true) @Valid @ModelAttribute DocumentUploadRequest documentUploadRequest)
        throws IOException;

    @ApiOperation(value = "Submit Merchant Application for registration")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Application Submitted", response = SubmissionResponse.class),
        @ApiResponse(code = 400, message = "Submission Failed", response = ErrorResponse.class)
    })
    @PostMapping(value = "{applicationId}/merchant-submissions",
        produces = MediaType.APPLICATION_JSON_VALUE,
        consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<SubmissionResponse> submitMerchantApplication(
        @ApiParam(value = "Application ID", required = true) @PathVariable("applicationId") @NotBlank String applicationId,
        @ApiParam(value = "Merchant Submission Request", required = true) @Valid @RequestBody MerchantSubmissionRequest request);
}
