package com.neom.fss.neompay.onboarding.model;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString(exclude = "otpNumber")
public class RegistrationRequest {

    @ApiModelProperty(required = true, value = "OTP Reference ID", example = "1234567")
    @NotBlank
    private String otpRefId;

    @ApiModelProperty(required = true, value = "Six Digit OTP Number", example = "112233")
    @NotBlank
    @Size(min = 6, max = 6)
    @Pattern(regexp = "[0-9]+")
    private String otpNumber;
}
