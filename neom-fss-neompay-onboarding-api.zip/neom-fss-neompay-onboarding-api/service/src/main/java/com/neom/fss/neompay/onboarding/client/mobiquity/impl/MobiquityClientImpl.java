package com.neom.fss.neompay.onboarding.client.mobiquity.impl;

import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.WebClientError;
import com.neom.fss.neompay.crosscuttinglib.proxy.WebRequestSender;
import com.neom.fss.neompay.onboarding.client.mobiquity.MobiquityClient;
import com.neom.fss.neompay.onboarding.config.BackendApiPathsConfig;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@Setter
@Flogger
@RequiredArgsConstructor
public class MobiquityClientImpl implements MobiquityClient {
    private final WebRequestSender webRequestSender;

    private final BackendApiPathsConfig backendApiPathsConfig;

    @Value("#{ '${services.mobiquity.useMobiquity}' ? '${services.mobiquity.service-address}' : '${services.mock.service-address}' }")
    private String mobiquityServiceAddress;

    @Override
    public String mobiquityPickListCustomerData() {
        ParameterizedTypeReference<String> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        String response = "";
        var customerSelfRegDataURI = UriComponentsBuilder
            .fromHttpUrl(mobiquityServiceAddress + backendApiPathsConfig.getCustomerPicklistApi()).build()
            .toUri();
        try {
            response =  webRequestSender.sendGetRequest(customerSelfRegDataURI, parameterizedTypeReference);
        } catch (WebClientError exception) {
            log.atSevere().log("Mobiquity call has failed with error: %s", exception.getMessage());
        }
        return response;
    }
    @Override
    public String mobiquityPickListMerchantData() {
        ParameterizedTypeReference<String> parameterizedTypeReference = new ParameterizedTypeReference<>() {
        };
        String response = "";
        var customerSelfRegDataURI = UriComponentsBuilder
                .fromHttpUrl(mobiquityServiceAddress + backendApiPathsConfig.getMerchantPicklistApi()).build()
                .toUri();
        try {
            response =  webRequestSender.sendGetRequest(customerSelfRegDataURI, parameterizedTypeReference);
        } catch (WebClientError exception) {
            log.atSevere().log("Mobiquity call has failed with error: %s", exception.getMessage());
        }
        return response;
    }
}
