package com.neom.fss.neompay.onboarding.service;

import com.neom.fss.neompay.onboarding.model.Value;
import java.util.List;
import java.util.Map;

public interface PickListService {
    Map<String, List<Value>> picklistData();
}
