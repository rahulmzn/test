package com.neom.fss.neompay.onboarding.client.idauth.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OtpVerificationRequestDto {

    private String otpRefId;

    private String otpNumber;

}
