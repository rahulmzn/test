package com.neom.fss.neompay.onboarding.service.impl;

import com.neom.fss.neompay.onboarding.client.idauth.IdAuthClient;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationRequestDto;
import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import com.neom.fss.neompay.onboarding.constants.OtpStatus;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationResponse;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import com.neom.fss.neompay.onboarding.service.EmailOtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class EmailOtpServiceImpl implements EmailOtpService {

    private final IdAuthClient idAuthClient;

    private final ApplicationService applicationService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public EmailOtpVerificationResponse verifyEmail(String applicationId, EmailOtpVerificationRequest request) {

        Application application = applicationService.getApplicationById(applicationId);

        var otpVerificationRequest = new OtpVerificationRequestDto(
            request.getOtpRefId(), request.getOtpNumber());

        var otpResponse = idAuthClient.verifyOtp(otpVerificationRequest);

        OtpStatus verificationStatus;
        if (otpResponse.isVerified()) {
            verificationStatus = OtpStatus.SUCCESS;
            application.setStage(ApplicationStage.EMAIL_VERIFIED);
            application.setEmailId(otpResponse.getSentTo());
            applicationService.save(application);
        } else {
            verificationStatus = OtpStatus.FAILED;
        }
        return new EmailOtpVerificationResponse(applicationId, verificationStatus);
    }
}
