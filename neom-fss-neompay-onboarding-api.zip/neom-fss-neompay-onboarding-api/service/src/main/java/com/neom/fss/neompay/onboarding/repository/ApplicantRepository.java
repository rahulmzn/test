package com.neom.fss.neompay.onboarding.repository;

import com.neom.fss.neompay.onboarding.repository.entity.Applicant;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplicantRepository extends JpaRepository<Applicant, Long> {

    Optional<Applicant> findByApplicationId(String applicationId);
}
