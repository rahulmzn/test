package com.neom.fss.neompay.onboarding.constants;

import io.swagger.annotations.ApiModel;

@ApiModel
public enum ApplicationIdType {

    CUSTOMER_SIGNUP_APPID,
    MERCHNAT_SIGNUP_APPID
}
