package com.neom.fss.neompay.onboarding.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ApiModel
public class MerchantSubmissionRequest {

    @ApiModelProperty(example = "en", required = true, value = "Language preferred")
    @NotBlank
    private String preferredLanguage;

    @ApiModelProperty(example = "12.3434", required = true, value = "Latitude")
    @DecimalMin(value="-90")
    @DecimalMax(value="90")
    private Double latitude;

    @ApiModelProperty(example = "10.3374", required = true, value = "Longitude")
    @DecimalMin(value="-180")
    @DecimalMax(value="180")
    private Double longitude;

    @ApiModelProperty(required = true, value = "Company Details")
    @Valid
    private CompanyDetail companyDetails;

}
