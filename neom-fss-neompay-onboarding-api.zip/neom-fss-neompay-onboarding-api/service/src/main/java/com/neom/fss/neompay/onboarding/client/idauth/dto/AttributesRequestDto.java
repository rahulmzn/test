package com.neom.fss.neompay.onboarding.client.idauth.dto;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AttributesRequestDto {

    @ApiModelProperty(value = "User Role", required = true, example = "customer")
    @NotBlank
    private String userRole;

    @ApiModelProperty(value = "User's Device Token", required = true, example = "sample_device_token")
    @NotBlank
    private String deviceId;

    @ApiModelProperty(value = "Comviva User Id", required = true, example = "US.93951643303832611")
    @NotBlank
    private String userId;
}
