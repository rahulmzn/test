package com.neom.fss.neompay.onboarding.mapper;

import com.neom.fss.neompay.crosscuttinglib.client.user.dto.ExpatCitizenDto;
import com.neom.fss.neompay.crosscuttinglib.client.user.dto.KsaCitizenDto;
import com.neom.fss.neompay.onboarding.model.ApplicantDetail;
import com.neom.fss.neompay.onboarding.model.BusinessApplicantDetail;
import com.neom.fss.neompay.onboarding.repository.entity.Applicant;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ApplicantMapper {

    ApplicantDetail toModel(Applicant applicant);

    @Mapping(target = "iqamaId", source = "logId")
    @Mapping(target = "hijriBirthDate", source = "dateOfBirthH")
    @Mapping(target = "englishBirthDate", source = "dateOfBirthH")
    @Mapping(target = "nationality", constant = "KSA")
    Applicant toEntity(KsaCitizenDto ksaCitizenDto);

    @Mapping(target = "iqamaId", source = "logId")
    @Mapping(target = "familyName", source = "lastName")
    @Mapping(target = "hijriBirthDate", source = "dateOfBirthG")
    @Mapping(target = "englishBirthDate", source = "dateOfBirthG")
    @Mapping(target = "idExpiryDate", source = "iqamaExpiryDateG")
    @Mapping(target = "nationality", source = "nationalityCode")
    Applicant toEntity(ExpatCitizenDto expatCitizenDto);


    BusinessApplicantDetail toBusinessApplicantModel(Applicant applicant);

}
