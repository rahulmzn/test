package com.neom.fss.neompay.onboarding.controller.definition;

import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponse;
import com.neom.fss.neompay.onboarding.config.SwaggerConfig.ServiceTags;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationRequest;
import com.neom.fss.neompay.onboarding.model.ApplicantVerificationResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/registration/v1.0")
@Api(tags = {ServiceTags.ID_VERIFICATION_API})
public interface IdentityVerificationApi {

    @ApiOperation(value = "Verify if applicant is a valid NEOM Resident (using Yakeen)")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Applicant Verified", response = ApplicantVerificationResponse.class),
        @ApiResponse(code = 404, message = "Application Not Found", response = ErrorResponse.class)
    })
    @PatchMapping(value = "/applications/{applicationId}/applicant-verifications",
        produces = MediaType.APPLICATION_JSON_VALUE,
        consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ApplicantVerificationResponse> verifyApplicant(
        @ApiParam(value = "Application ID", required = true) @PathVariable("applicationId") @NotBlank String applicationId,
        @ApiParam(value = "Verification Request", required = true) @Valid @RequestBody ApplicantVerificationRequest request);
}
