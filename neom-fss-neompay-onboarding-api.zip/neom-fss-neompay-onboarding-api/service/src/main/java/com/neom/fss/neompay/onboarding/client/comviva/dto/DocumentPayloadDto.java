package com.neom.fss.neompay.onboarding.client.comviva.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DocumentPayloadDto {

    private String fileName;
    private String documentId;
    private String message;
    private String referenceId;
}
