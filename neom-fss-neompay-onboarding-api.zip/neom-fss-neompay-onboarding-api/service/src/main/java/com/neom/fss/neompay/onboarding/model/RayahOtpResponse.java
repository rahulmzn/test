package com.neom.fss.neompay.onboarding.model;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = "otpNumber")
public class RayahOtpResponse {

    @ApiModelProperty(value = "Application ID", required = true)
    @NotBlank
    private String applicationId;

    @ApiModelProperty(value = "OTP Reference ID", required = true)
    @NotBlank
    private String otpRefId;

    @ApiModelProperty(value = "OTP Number", required = true)
    @NotBlank
    private String otpNumber;

    @ApiModelProperty(value = "OTP resend counter, increase for each resend request by 1 until 5", required = true, example = "5")
    @NotNull
    private Integer resendCounter;

    @ApiModelProperty(value = "Time when Otp will be expired, this will be in epoch unix millisecods (long)", example = "1648650576", required = true)
    @NotNull
    private Long expiryTime;
}
