package com.neom.fss.neompay.onboarding.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.ClientError;
import com.neom.fss.neompay.crosscuttinglib.util.PasscodeValidator;
import com.neom.fss.neompay.crosscuttinglib.util.UniqueIdGenerator;
import com.neom.fss.neompay.onboarding.client.comviva.ComvivaClient;
import com.neom.fss.neompay.onboarding.client.idauth.IdAuthClient;
import com.neom.fss.neompay.onboarding.client.idauth.dto.OtpVerificationRequestDto;
import com.neom.fss.neompay.onboarding.client.mobiquity.MobiquityClient;
import com.neom.fss.neompay.onboarding.config.MerchantSignupConfig;
import com.neom.fss.neompay.onboarding.config.UserSignupConfig;
import com.neom.fss.neompay.onboarding.constants.ApplicationStage;
import com.neom.fss.neompay.onboarding.constants.ErrorCodes;
import com.neom.fss.neompay.onboarding.constants.KycType;
import com.neom.fss.neompay.onboarding.constants.OtpStatus;
import com.neom.fss.neompay.onboarding.constants.UserProfileType;
import com.neom.fss.neompay.onboarding.domain.ApplicationStageValidator;
import com.neom.fss.neompay.onboarding.mapper.ApplicantMapper;
import com.neom.fss.neompay.onboarding.mapper.ComvivaMapper;
import com.neom.fss.neompay.onboarding.mapper.IdAuthMapper;
import com.neom.fss.neompay.onboarding.model.*;
import com.neom.fss.neompay.onboarding.repository.entity.Applicant;
import com.neom.fss.neompay.onboarding.repository.entity.Application;
import com.neom.fss.neompay.onboarding.service.ApplicantVerificationService;
import com.neom.fss.neompay.onboarding.service.ApplicationService;
import com.neom.fss.neompay.onboarding.service.RegistrationService;
import com.neom.fss.neompay.onboarding.service.UserService;
import com.neom.fss.neompay.onboarding.utils.PropertiesConfig;
import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import lombok.RequiredArgsConstructor;
import lombok.extern.flogger.Flogger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
@Flogger
public class RegistrationServiceImpl implements RegistrationService {

    private final ComvivaClient comvivaClient;
    private final IdAuthClient idAuthClient;
    private final ApplicationService applicationService;
    private final ApplicantVerificationService applicantVerificationService;
    private final ComvivaMapper comvivaMapper;
    private final IdAuthMapper idAuthMapper;
    private final UniqueIdGenerator uniqueIdGenerator;
    private final UserService userService;
    private final ApplicationStageValidator applicationStageValidator;
    private KycType kycType = KycType.UNKNOWN;
    private final UserSignupConfig userSignupConfig;
    private final ApplicantMapper applicantMapper;
    private final MerchantSignupConfig merchantSignupConfig;
    private final MobiquityClient mobiquityClient;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RegistrationResponse registerUser(RegistrationRequest request) {
        var otpVerificationRequest = new OtpVerificationRequestDto(request.getOtpRefId(),
            request.getOtpNumber());
        var otpVerificationResponse = idAuthClient.verifyOtp(otpVerificationRequest);

        if (otpVerificationResponse.isVerified()) {
            if (userService.userExists(otpVerificationResponse.getUserType(),
                otpVerificationResponse.getSentTo())) {
                throw new BadInput(ErrorCodes.RESOURCE_EXISTS.getCode());
            }

            Application application = new Application(
                uniqueIdGenerator.getRandomAlphabeticStartWithGivenAndHyphen(
                    PropertiesConfig.APP_REF_ID_PREFIX, PropertiesConfig.APP_REF_ID_LENGTH),
                otpVerificationResponse.getSentTo(),
                otpVerificationResponse.getUserType());

            application.setRequestedByKey(otpVerificationResponse.getRequestedByKey());
            application.setRequestedByValue(otpVerificationResponse.getRequestedByValue());
            application.setStage(ApplicationStage.OTP_VERIFIED);

            applicationService.save(application);

            return new RegistrationResponse(application.getApplicationId(), request.getOtpRefId(),
                OtpStatus.SUCCESS,
                0);
        }
        throw new BadInput("OTP Verification Failed");
    }

    @Override
    public SubmissionResponse submitApplication(String applicationId,
        SubmissionRequest submissionRequest) {
        log.atInfo()
            .log("On-boarding an Applicant with details - request: %s",
                submissionRequest.toString());

        Applicant applicant = applicantVerificationService.getApplicantInformation(applicationId);
        //User Pin Checks
        if (Objects.nonNull(applicant.getEnglishBirthDate())) {
            String dateOfBirth = applicant.getEnglishBirthDate().toString();
            try {
                PasscodeValidator.validatePasscode(submissionRequest.getUserPin(),
                    submissionRequest.getConfirmUserPin(), dateOfBirth, ErrorCodes.INVALID_PIN.getCode());
            } catch (ParseException parseException) {
                throw new ServiceException.BadInput(ErrorCodes.INVALID_FIELD.getCode());
            }
        }

        //1. Perform Checks as per the JIRA Ticket
        Application application = stageChecks(applicationId);

        //2. Pull out details related to Applicant Repository and Build Complete Applicant Details
        ApplicantDetail applicantDetail =
            this.buildApplicantDetails(application.getMobileNo(), submissionRequest, applicant);

        //3. Applicant's On-boarding with Comviva API - WIP
        this.applicantOnboardWithComviva(applicantDetail);

        //4. Applicant's Profile Creation with PIN - WIP
        idAuthClient.createUserProfileWithPin(idAuthMapper.mapModelToRequestDto(applicantDetail));

        SubmissionResponse submissionResponse = new SubmissionResponse();
        submissionResponse.setApplicationId(applicationId);
        submissionResponse.setStage(ApplicationStage.ONBOARDING_COMPLETED);

        return submissionResponse;
    }

    @Override
    public SubmissionResponse submitMerchantApplication(String applicationId,
        MerchantSubmissionRequest merchantSubmissionRequest) {
        //Validating Request
        if(merchantSubmissionRequest.getCompanyDetails().getManagementDetails() != null
            && !merchantSubmissionRequest.getCompanyDetails().getManagementDetails().getSeniorManagements().isEmpty()){
           this.validateManagement(merchantSubmissionRequest.getCompanyDetails().getManagementDetails().getSeniorManagements());
        }
        //1. Perform pre-submission checks from Lookup Table
        Application application = stageChecks(applicationId);

        //2. Pull out details related to Applicant Repository and Build Complete Applicant Details
        BusinessApplicantDetail applicantDetail =
            this.buildBusinessApplicantDetails(application.getMobileNo(), application.getEmailId(),
                merchantSubmissionRequest, applicationId);

        //3. Applicant's On-boarding with Comviva API - WIP
        var comvivaRegistrationResponse = comvivaMapper.mapDtoToResponseModel(
            comvivaClient.merchantSelfRegistration(
                comvivaMapper
                    .mapBusinessModelToRequestDto(applicantDetail, merchantSignupConfig)));

        //4. Update Applicant Table in Database
        Application merchantApplication = applicationService.getApplicationById(applicationId);
        if (Objects.nonNull(comvivaRegistrationResponse)) {
            merchantApplication.setUserId(comvivaRegistrationResponse.getUserId());
            merchantApplication.setStageName(ApplicationStage.APPLICATION_SUBMITTED);
        } else {
            merchantApplication.setStageName(ApplicationStage.ONBOARDING_FAILED);
        }
        var updatedApplication = applicationService.save(merchantApplication);
        applicationService.saveToHistory(updatedApplication);

        if (updatedApplication.getStageName().equals(ApplicationStage.APPLICATION_SUBMITTED)) {
            SubmissionResponse response = new SubmissionResponse();
            response.setApplicationId(applicationId);
            response.setStage(ApplicationStage.APPLICATION_SUBMITTED);
            return response;
        } else {
            throw new ClientError(ErrorCodes.UNKNOWN.getCode());
        }
    }

    private Map<String, List<Value>> pickListMerchantData(){
        ObjectMapper objectMapper = new ObjectMapper();
        TypeReference<Map<String, List<Value>>> typeReference= new TypeReference<>() {
        };
        var picklistDataResponse = mobiquityClient.mobiquityPickListMerchantData();
        if(StringUtils.hasText(picklistDataResponse)) {
            try{
                return objectMapper.readValue(picklistDataResponse, typeReference);
            } catch (JsonProcessingException e) {
                throw new BadInput(ErrorCodes.INVALID_BODY.getCode());
            }
        } else {
            throw new ServiceException.NoData(ErrorCodes.NO_DATA_FOUND.getCode());
        }
    }

    private ApplicantDetail buildApplicantDetails(String mobileNumber,
        SubmissionRequest submissionRequest, Applicant applicant) {
        //Calling Applicant Information
        ApplicantDetail applicantDetail = applicantMapper.toModel(applicant);
        applicantDetail.setEmail(submissionRequest.getEmail());
        applicantDetail.setEmploymentStatus(submissionRequest.getEmploymentStatus());
        applicantDetail.setUserPin(submissionRequest.getUserPin());
        applicantDetail.setSalaryRange(submissionRequest.getIncomeRange());
        applicantDetail.setSourceOfIncome(submissionRequest.getPrimarySourceOfIncome());
        //TO-DO: Need to take it from Request Headers
        applicantDetail.setSource("MOBILE");
        applicantDetail.setPreferredLanguage(submissionRequest.getPreferredLanguage());
        applicantDetail.setUserRole(UserProfileType.CUSTOMER.getValue());
        applicantDetail.setMobileNo(mobileNumber);
        applicantDetail.setKyc(this.kycType);

        //Use Mapper
        DeviceDetail deviceDetail = comvivaMapper.mapDeviceInfoRequestToModel(submissionRequest.getDevice());
        applicantDetail.setDeviceDetail(deviceDetail);

        return applicantDetail;
    }

    private void applicantOnboardWithComviva(ApplicantDetail applicantDetail) {
        var comvivaRegistrationResponse = comvivaMapper.mapDtoToResponseModel(
            comvivaClient.comvivaSelfRegistration(
                comvivaMapper.mapModelToRequestDto(applicantDetail, userSignupConfig)));

        //Update Applicant Table in Database with user Id and email if exist
        var applicationResponse = saveToApplication(comvivaRegistrationResponse, applicantDetail);

        if (applicationResponse.getStageName().equals(ApplicationStage.ONBOARDING_COMPLETED)) {
            applicantDetail.setUserId(comvivaRegistrationResponse.getUserId());
            applicantDetail.setTemporaryPin(!applicationResponse.getUserType().equals(UserType.CUSTOMER));
            //TO-DO: Need to re-work
            applicantDetail.setUserRole(UserProfileType.CUSTOMER.getValue());
            applicantDetail.setUserType(applicationResponse.getUserType().name().toLowerCase());
            applicantDetail.setEmail(applicationResponse.getEmailId());
        } else {
            throw new ClientError(ErrorCodes.ON_BONDING_FAILED_DUE_TO_COMVIVA.getCode());
        }

    }


    private Application saveToApplication(
        ComvivaRegistrationResponse comvivaRegistrationResponse, ApplicantDetail applicantDetail) {

        Application application = applicationService.getApplicationById(
            applicantDetail.getApplicationId());

        if (Objects.nonNull(comvivaRegistrationResponse)
            && StringUtils.hasText(comvivaRegistrationResponse.getUserId())) {

            application.setUserId(comvivaRegistrationResponse.getUserId());
            application.setStageName(ApplicationStage.ONBOARDING_COMPLETED);
            application.setEmailId(Strings.isNotBlank(applicantDetail.getEmail()) ? applicantDetail.getEmail() : null);
            var updatedApplication = applicationService.save(application);
            applicationService.saveToHistory(updatedApplication);

            return updatedApplication;

        } else {
            application.setStageName(ApplicationStage.ONBOARDING_FAILED);
            var failedApplication = applicationService.save(application);
            applicationService.saveToHistory(failedApplication);

            return failedApplication;
        }
    }

    private Application stageChecks(String applicationId) {
        Application application = applicationService.getApplicationById(applicationId);
        if (application.getStageName().equals(ApplicationStage.ONBOARDING_COMPLETED)) {
            throw new ClientError(ErrorCodes.RESOURCE_EXISTS.getCode());
        }
        boolean stageVerifyStatus = applicationStageValidator.hasPassedAllStages(application);

        //TO-DO: This code would be part of Risk Score - Yet to be implemented.
        if (stageVerifyStatus) {
            this.kycType = KycType.NO_KYC;
        }

        return application;
    }

    private BusinessApplicantDetail buildBusinessApplicantDetails (String mobileNumber, String emailId,
        MerchantSubmissionRequest submissionRequest, String applicationId){
        BusinessApplicantDetail applicantDetail = new BusinessApplicantDetail();
        Map<String, List<Value>> pickListMerchantData = pickListMerchantData();
        List<Value> businessCategoryList = pickListMerchantData.get("businessCategoryList");
        Optional<Value> businessCategory = businessCategoryList.stream().filter(a -> a.getDisplayName().equalsIgnoreCase(submissionRequest.getCompanyDetails().getBusinessInfo().getBusinessCategory())).findFirst();
        businessCategory.ifPresent(value -> applicantDetail.setBusinessCategory(value.getId()));

        List<Value> companyTypeList = pickListMerchantData.get("companyTypeList");
        Optional<Value> companyType = companyTypeList.stream().filter(a -> a.getDisplayName().equalsIgnoreCase(submissionRequest.getCompanyDetails().getRegistrationInfo().getCompanyType())).findFirst();
        companyType.ifPresent(value -> applicantDetail.setCompanyType(value.getId()));

        //Calling Applicant Information

        applicantDetail.setEmail(emailId);
        applicantDetail.setLatitude(submissionRequest.getLatitude());
        applicantDetail.setLongitude(submissionRequest.getLongitude());
        applicantDetail.setPreferredLanguage(submissionRequest.getPreferredLanguage());
        applicantDetail.setCompanyName(submissionRequest.getCompanyDetails().getRegistrationInfo().getCompanyName());
        applicantDetail.setCompanyRegistrationNo(submissionRequest.getCompanyDetails().getRegistrationInfo().getRegistrationNo());
        applicantDetail.setCompanyRegistrationDocUrl(submissionRequest.getCompanyDetails().getRegistrationInfo().getRegistrationDocUrl());
        applicantDetail.setMonthlyTransactionValue(
            submissionRequest.getCompanyDetails().getBusinessInfo().getTransactionValue());
        applicantDetail.setMonthlyTransactionVolume(
            submissionRequest.getCompanyDetails().getBusinessInfo().getTransactionVolume());
        if(Objects.nonNull(submissionRequest.getCompanyDetails().getManagementDetails())
            && Objects.nonNull(submissionRequest.getCompanyDetails().getManagementDetails().getSeniorManagements())
            && !submissionRequest.getCompanyDetails().getManagementDetails().getSeniorManagements().isEmpty()){
            applicantDetail.setSeniorManagement(submissionRequest.getCompanyDetails().getManagementDetails().getSeniorManagements());
        }
        applicantDetail.setSource("MOBILE");
        applicantDetail.setUserRole(UserProfileType.MERCHANT.getValue());
        applicantDetail.setMobileNo(mobileNumber);
        applicantDetail.setGender('M');
        applicantDetail.setApplicationId(applicationId);

        return applicantDetail;
    }

    private void validateManagement(List<Management> managements) {
        for(Management management : managements){
            if(StringUtils.hasText(management.getName())){
                management.checkDocUrlAvailable();
            }
        }
    }
}
