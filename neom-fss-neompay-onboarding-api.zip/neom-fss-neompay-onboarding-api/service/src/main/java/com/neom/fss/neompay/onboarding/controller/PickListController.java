package com.neom.fss.neompay.onboarding.controller;

import com.neom.fss.neompay.onboarding.controller.definition.PickListApi;
import com.neom.fss.neompay.onboarding.model.Value;
import com.neom.fss.neompay.onboarding.service.PickListService;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@RequiredArgsConstructor
public class PickListController implements PickListApi {

    private final PickListService pickListService;

    @Override
    public ResponseEntity<Map<String, List<Value>>> picklistDataForCustomer() {
        Map<String, List<Value>> response = pickListService.picklistData();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
