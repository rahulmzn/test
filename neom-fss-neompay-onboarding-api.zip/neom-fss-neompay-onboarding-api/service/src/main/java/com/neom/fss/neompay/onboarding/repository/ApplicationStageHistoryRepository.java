package com.neom.fss.neompay.onboarding.repository;

import com.neom.fss.neompay.onboarding.Application;
import com.neom.fss.neompay.onboarding.repository.entity.ApplicationStageHistory;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApplicationStageHistoryRepository extends
    JpaRepository<ApplicationStageHistory, Long> {

    List<ApplicationStageHistory> findByApplication(Application application);
}
