package com.neom.fss.neompay.onboarding.model;

import com.neom.fss.neompay.onboarding.constants.KycType;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApplicantDetail {

    private String applicationId;
    private String iqamaId;
    private String firstName;
    private String secondName;
    private String thirdName;
    private String fatherName;
    private String grandFatherName;
    private String familyName;
    private String englishFirstName;
    private String englishSecondName;
    private String englishThirdName;
    private String englishLastName;
    private Character gender;
    private String nationality;
    private String hijriBirthDate;
    private LocalDate englishBirthDate;
    private LocalDate idExpiryDate;
    private String mobileNo;
    private String employmentStatus;
    private String sourceOfIncome;
    private String salaryRange;
    private String sourceOfFunds;
    private String userPin;
    private String email;
    private String userId;
    //National - expat - tourist
    private String userRole;
    private KycType kyc;
    //Customer - Merchant
    private String userType;
    private DeviceDetail deviceDetail;
    private String source;
    private boolean temporaryPin;
    private String preferredLanguage;
}
