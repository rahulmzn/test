package com.neom.fss.neompay.onboarding.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class PropertiesConfig {

    public static final String APP_REF_ID_PREFIX = "app";
    public static final int APP_REF_ID_LENGTH = 20;
}
