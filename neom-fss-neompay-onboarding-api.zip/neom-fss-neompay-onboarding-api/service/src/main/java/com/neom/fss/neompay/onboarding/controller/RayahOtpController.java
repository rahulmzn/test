package com.neom.fss.neompay.onboarding.controller;

import com.neom.fss.neompay.onboarding.controller.definition.RayahOtpApi;
import com.neom.fss.neompay.onboarding.model.RayahOtpRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpResponse;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.RayahOtpVerificationResponse;
import com.neom.fss.neompay.onboarding.service.RayahOtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@RequiredArgsConstructor
public class RayahOtpController implements RayahOtpApi {

    private final RayahOtpService rayahOtpService;

    @Override
    public ResponseEntity<RayahOtpResponse> generateOtp(String applicationId,
        RayahOtpRequest request) {
        return new ResponseEntity<>(rayahOtpService.generateAndSendOtp(applicationId, request),
            HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RayahOtpVerificationResponse> verifyOtp(String applicationId,
        RayahOtpVerificationRequest request) {
        RayahOtpVerificationResponse verifyOtpResponse = rayahOtpService
            .verifyOtp(applicationId, request);

        return new ResponseEntity<>(verifyOtpResponse, HttpStatus.OK);
    }

}
