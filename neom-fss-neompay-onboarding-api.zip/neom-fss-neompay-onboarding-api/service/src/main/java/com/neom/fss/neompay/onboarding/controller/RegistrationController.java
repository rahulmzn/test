package com.neom.fss.neompay.onboarding.controller;

import com.neom.fss.neompay.crosscuttinglib.constants.UserType;
import com.neom.fss.neompay.crosscuttinglib.exception.ServiceException.BadInput;
import com.neom.fss.neompay.onboarding.controller.definition.RegistrationApi;
import com.neom.fss.neompay.onboarding.model.RegistrationRequest;
import com.neom.fss.neompay.onboarding.model.RegistrationResponse;
import com.neom.fss.neompay.onboarding.model.SearchResponse;
import com.neom.fss.neompay.onboarding.model.SubmissionRequest;
import com.neom.fss.neompay.onboarding.model.SubmissionResponse;
import com.neom.fss.neompay.onboarding.service.RegistrationService;
import com.neom.fss.neompay.onboarding.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@RequiredArgsConstructor
public class RegistrationController implements RegistrationApi {

    private final RegistrationService registrationService;
    private final UserService userService;

    @Override
    public ResponseEntity<RegistrationResponse> registerUser(RegistrationRequest request) {
        RegistrationResponse registrationResponse = registrationService.registerUser(request);
        return new ResponseEntity<>(registrationResponse, HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<SubmissionResponse> submitApplication(String applicationId,
                                                                SubmissionRequest request) {
        SubmissionResponse submissionResponse = registrationService
                .submitApplication(applicationId, request);
        return new ResponseEntity<>(submissionResponse, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SearchResponse> searchUserContactExist(String searchParameter, String type) {
        UserType userType = null;
        try{
            userType = UserType.valueOf(type);
        } catch (IllegalArgumentException exception) {
            throw new BadInput("userType");
        }
        SearchResponse searchResponse = userService.contactSearch(searchParameter, userType);
        return new ResponseEntity<>(searchResponse, HttpStatus.OK);
    }
}
