package com.neom.fss.neompay.onboarding.controller.definition;

import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponse;
import com.neom.fss.neompay.onboarding.config.SwaggerConfig.ServiceTags;
import com.neom.fss.neompay.onboarding.model.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequestMapping("/registration/v1.0")
@Api(tags = {ServiceTags.REGISTRATION_API})
public interface RegistrationApi {

    @ApiOperation(value = "Register Customer/Merchant Application to use NEOM Pay Wallet")
    @ApiResponses(value = {
        @ApiResponse(code = 201, message = "Application registered", response = RegistrationResponse.class),
        @ApiResponse(code = 400, message = "OTP Verification Failed", response = ErrorResponse.class)
    })
    @PostMapping(value = "/applications",
        produces = MediaType.APPLICATION_JSON_VALUE,
        consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<RegistrationResponse> registerUser(
        @ApiParam(value = "Applicant Verification Request", required = true) @Valid @RequestBody RegistrationRequest request);

    @ApiOperation(value = "Submit Customer Application to use NEOM Pay Wallet")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Application Submitted", response = SubmissionResponse.class),
        @ApiResponse(code = 400, message = "Submission Failed", response = ErrorResponse.class)
    })
    @PatchMapping(value = "/applications/{applicationId}/submissions",
        produces = MediaType.APPLICATION_JSON_VALUE,
        consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<SubmissionResponse> submitApplication(
        @ApiParam(value = "Application ID", required = true) @PathVariable("applicationId") @NotBlank String applicationId,
        @ApiParam(value = "Application Submission Request", required = true) @Valid @RequestBody SubmissionRequest request);


    @ApiOperation(value = "Search if User's MSISDN or email already exist")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "OK"),
        @ApiResponse(code = 404, message = "Data Not Found", response = ErrorResponse.class),
        @ApiResponse(code = 400, message = "Bad Input", response = ErrorResponse.class)
    })
    @GetMapping(value = "/contact/search")
    ResponseEntity<SearchResponse> searchUserContactExist(
        @ApiParam(value = "MSISDN or Email Value", required = true) @Valid @RequestParam(name = "searchParam")  String searchParameter,
        @ApiParam(value = "Type of user to enter", required = true, example = "CUSTOMER") @Valid @RequestParam(name = "userType")
        String userType);
}
