package com.neom.fss.neompay.onboarding.model;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactSearchResponse {
    private Boolean exist;
    private List<UserResponse> users;
}
