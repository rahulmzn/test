package com.neom.fss.neompay.onboarding.controller.definition;

import com.neom.fss.neompay.crosscuttinglib.exception.ErrorResponse;
import com.neom.fss.neompay.onboarding.config.SwaggerConfig.ServiceTags;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationRequest;
import com.neom.fss.neompay.onboarding.model.EmailOtpVerificationResponse;
import io.swagger.annotations.*;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@RequestMapping("/registration/v1.0")
@Api(tags = {ServiceTags.RAYAH_API})
public interface EmailOtpApi {

    @ApiOperation(value = "Verify Email OTP")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "OTP Verified", response = EmailOtpVerificationResponse.class),
        @ApiResponse(code = 404, message = "Application Not Found", response = ErrorResponse.class)
    })
    @PatchMapping(
        value = "/applications/{applicationId}/email-verifications",
        produces = {MediaType.APPLICATION_JSON_VALUE},
        consumes = {MediaType.APPLICATION_JSON_VALUE}
    )
    ResponseEntity<EmailOtpVerificationResponse> verifyEmail(
        @ApiParam(value = "Application ID", required = true) @PathVariable("applicationId") @NotBlank String applicationId,
        @ApiParam(value = "Email OTP Verification Request", required = true) @Valid @RequestBody EmailOtpVerificationRequest request);

}
