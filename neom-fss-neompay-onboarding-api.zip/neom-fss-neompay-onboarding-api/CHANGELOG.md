# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.40.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.40.0...v0.40.1) (2022-09-08)


### Bug Fixes

* NFS-1767 values added (#94) ([3ef2b15](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/3ef2b155ab521c7f94512e27dcb923c8d9e06f40))

## [0.40.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.39.3...v0.40.0) (2022-09-06)


### Release

* NFS-6258 Release notes link update  R 2.22.04 ([6dec1bc](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/6dec1bc2c3e122ee5ff0fcd8a0adff2f97da4f3a))

### [0.39.3](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.39.2...v0.39.3) (2022-09-01)


### Bug Fixes

* NFS-6467 Comviva host details updated ([636ad9a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/636ad9a5d81da5388f9144e7f19de5276ac5cc65))

### [0.39.2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.39.1...v0.39.2) (2022-09-01)


### Bug Fixes

* NFS-6467 Comviva host update for OCI (#93) ([700334c](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/700334c5571c273c1f9200b6e3e9291d5cb7f125))

### [0.39.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.39.0...v0.39.1) (2022-08-31)


### Bug Fixes

* NFS-1767 code added (#91) ([e3d8938](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/e3d8938d3f93c389d939a2265db84ac8f4117e68))

## [0.39.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.38.0...v0.39.0) (2022-08-29)


### Release

* NFS-6258 version updated ([906399a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/906399a19996ca166787d7583b38dadb86c8e986))

## [0.38.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.37.0...v0.38.0) (2022-08-29)


### Release

* NFS-6258 Release notes link update  R 2.22.03 ([b9ff696](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/b9ff696210bd8e8c21bb7792e682d9d457bb08f8))

## [0.37.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.36.0...v0.37.0) (2022-08-26)


### Release

* NFS-6431 Release notes link update R 2.22.02 ([908d560](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/908d5603fff2401304ead5681b2c99fae26fab65))

## [0.36.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.35.0...v0.36.0) (2022-08-25)


### Release

* NFS-6431 Release notes link updated to include multilogin for R 2.22 ([86d5f8d](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/86d5f8d4868c0eede2f0200934c86714175ad275))

## [0.35.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.34.0...v0.35.0) (2022-08-22)


### Release

* NFS-6431 Release notes link updated for R 2.22 ([253c006](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/253c00692fd4eb82841ea58bdab9a317e9a5e1ed))

## [0.34.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.33.0...v0.34.0) (2022-08-22)


### Release

* NFS-6431 Release notes link updated for R 2.22 ([2069078](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/2069078f03f03004decc386c85a55abbea092b63))

## [0.33.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.32.4...v0.33.0) (2022-08-08)


### Features

* NFS-6257 removed v2 token and x-idp header from request ([d240aca](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/d240acafa9cc383f80f07b284c6c19d5543d33f0))

### [0.32.4](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.32.3...v0.32.4) (2022-08-08)


### Bug Fixes

* NFS-5894 check added (#90) ([5eb9ce5](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/5eb9ce56fc082485c0957847321e8698eb427733))

### [0.32.3](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.32.2...v0.32.3) (2022-08-05)


### Bug Fixes

* NFS-5894 check added (#89) ([63000b0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/63000b0bd9aeb192bb05b430194c1e4c6c7bfbd9))

### [0.32.2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.32.1...v0.32.2) (2022-08-04)


### Bug Fixes

* NFS-5355 moved service to auth with system and api token ([42d7246](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/42d7246a4132c144401233770111aee3534d898f))

### [0.32.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.32.0...v0.32.1) (2022-08-02)


### Bug Fixes

* NFS-1962 secrets added (#87) ([143eaa9](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/143eaa911fe4ee737b1801065dfe07f0b208cace))
* NFS-1962 secrets removed (#88) ([9fb01cf](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/9fb01cf7858aabf3168b9696c7e504e4eeeffdad))

## [0.32.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.31.0...v0.32.0) (2022-07-27)


### Release

* NFS-6247 Spring 2.19 feature release ([964747f](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/964747f2465fb0b996f43a04bf93c44bb42e007e))

## [0.31.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.30.0...v0.31.0) (2022-07-27)


### Features

* NFS-6247 id auth integration with comivia api's ([fec7c07](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/fec7c07e582140415dda248a2de870a2fe7f5886))

## [0.30.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.29.0...v0.30.0) (2022-07-12)


### Release

* NFS-2669 release latest for INT env ([806cc49](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/806cc4970cbc6430252987999040f5b1ded65f3b))

## [0.29.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.28.1...v0.29.0) (2022-07-08)


### Release

* NFS-2669 release latest for INT env ([e45d6b4](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/e45d6b4a9eda58c2a442ef49291dd5edafd0f2f5))

### [0.28.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.28.0...v0.28.1) (2022-07-06)


### Bug Fixes

* NFS-5659 fixing not serialization issue (#86) ([b4dd89a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/b4dd89a7c91bcef845a9d6591e73e761d518e81e))

## [0.28.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.27.0...v0.28.0) (2022-07-06)


### Release

* NFS-2662- Service Release automatically to INT ([ce16a73](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/ce16a73885c5422b99c26f0fd3734715ad924ad1))

## [0.27.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.26.2...v0.27.0) (2022-07-05)


### Features

* NFS-5659 dropdown values for customer (#82) ([f19f718](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/f19f71896a40422ee227ecad258bb0c5bed2a41c))

### [0.26.2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.26.1...v0.26.2) (2022-07-04)


### Bug Fixes

* NFS-5809 authentication fix (#85) ([6f8ab7b](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/6f8ab7b32a1b6d422bf218b3a94bc88aeee355d0))

### [0.26.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.26.0...v0.26.1) (2022-07-04)


### Bug Fixes

* NFS-5809 dedup error handling for request parameter (#81) ([20c30ef](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/20c30ef5fbccc809fca0c864d057a009989c9148))
* NFS-5809 including test case (#84) ([09970f9](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/09970f90298ed50458159141134caf5352b00e2a))

## [0.26.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.25.4...v0.26.0) (2022-07-01)


### Release

* NFS-2662- Service Release automatically to INT ([67c7bbb](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/67c7bbb89b801debdeb6269f310931814662ede8))

### [0.25.4](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.25.3...v0.25.4) (2022-07-01)


### Bug Fixes

* NFS-2662 Merge branch 'master' of https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api ([4fe3886](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/4fe3886beb3566e4f6d4c769ef42f35773990e41))
* NFS-2662- Service mash config implemented ([6d4bf52](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/6d4bf526c66bce797e8e31f626ba6a463a1d8dbe))
* NFS-2662- Service mash config implemented ([f3c8d74](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/f3c8d74005282eb8aceab4f3803accf890d4f21b))

### [0.25.3](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.25.2...v0.25.3) (2022-07-01)


### Bug Fixes

* NFS-2662- Service mash config implemented ([959b4d0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/959b4d01183a670b80aef1a51c1b7d07111900f7))

### [0.25.2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.25.1...v0.25.2) (2022-07-01)


### Bug Fixes

* NFS-2662- Service mash config implemented ([8e31910](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/8e31910d0c837e51b8e35f5f594329f01c8cb85c))

### [0.25.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.25.0...v0.25.1) (2022-07-01)


### Bug Fixes

* NFS-2662- Service mash config implemented ([ba9c80a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/ba9c80a20e0b0ab62490d9492fd5acaaac15156f))

## [0.25.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.24.0...v0.25.0) (2022-06-30)


### Bug Fixes

* NFS-2662 Redis Config Added ([e548e98](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/e548e9876ccc8d62b1e6040f633698384ab62ecd))
* NFS-2662 Service mash and release config update ([0f963be](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/0f963beedc08ca6bdcffbbb8febc81fded00718d))
* NFS-2662- Service mash config implemented ([3db7117](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/3db71177a6c30b5977e4672e701f6f07eff5a63a))

## [0.24.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.23.0...v0.24.0) (2022-06-17)


### Features

* NFS-5766 removing unwanted fields from mapper ([#79](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/79)) ([0b61af9](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/0b61af95934961c2d9747058012cdfcc221f20c8))

## [0.23.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.22.0...v0.23.0) (2022-06-16)


### Features

* NFS-5733 fixing email id flow in service ([#78](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/78)) ([f95380e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/f95380ea65fef2e26665eaadb60ed1d9b4eee7eb))

## [0.22.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.21.0...v0.22.0) (2022-06-16)


### Features

* NFS-5733 adding email id to on-boarding signup journey ([#77](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/77)) ([258b85b](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/258b85bf80558fb2fa1ebe21e61399652887ddea))

## [0.21.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.20.1...v0.21.0) (2022-06-13)


### Features

* NFS-5870 dedup response change ([#76](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/76)) ([06a3f64](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/06a3f64d4527bf50dbcb51e9452d5f05d301e14a))

### [0.20.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.20.0...v0.20.1) (2022-06-08)


### Bug Fixes

* NFS-3076 config root changes ([#74](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/74)) ([1ec0e49](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/1ec0e4950260e180118edbe6d204f1eb2e3fb125))

## [0.20.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.19.0...v0.20.0) (2022-06-08)


### Features

* NFS-5414 junits coverage ([#71](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/71)) ([72f1a21](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/72f1a21b9e88d513f7252796aba39301d3df950b))

## [0.19.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.18.1...v0.19.0) (2022-06-08)

### [0.18.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.18.0...v0.18.1) (2022-06-07)


### Bug Fixes

* NFS-5385 updated data source config ([0da9dfe](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/0da9dfe478bcb27e6188adeb7bd12fc925b55e9d))

## [0.18.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.17.0...v0.18.0) (2022-06-07)


### Features

* NFS-5506 testing with search flow for system token ([#73](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/73)) ([e8555d9](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/e8555d962d6f0ed34a4a1ddda16b120974db53ed))

## [0.17.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.16.0...v0.17.0) (2022-06-06)


### Features

* NFS-5506 including authentication by system token ([#66](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/66)) ([586fd8a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/586fd8a1903383cc9eedaf26bc04279336e6abe9))

## [0.16.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.15.0...v0.16.0) (2022-06-02)


### Features

* NFS-5244 handling stage update error ([#70](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/70)) ([8cbfa84](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/8cbfa847295d25191dde349f14e85877b5239ff2))

## [0.15.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.14.1...v0.15.0) (2022-06-02)


### Features

* NFS-5526 dedup api for msisdn and email check ([#69](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/69)) ([25aa79f](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/25aa79f7173eeaa8d6852c44fd898d6c78b86560))

### [0.14.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.14.0...v0.14.1) (2022-06-01)


### Features

* NFS-5242 return additional security headers ([06f2dc5](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/06f2dc5028e254e691a788565258290e0bc9c194))


### Bug Fixes

* NFS-5729 updated namespaces ([f0a6692](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/f0a6692d359326fb7e7ad873bf8696cc47393ee2))

## [0.14.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.13.2...v0.14.0) (2022-05-31)


### Features

* NFS-2672 bdd tcs and fixes ([3b84a1f](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/3b84a1fac71e932dfb66fa82b125b132fb7692c6))

### [0.13.2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.13.1...v0.13.2) (2022-05-31)


### Bug Fixes

* NFS-5739 fixing isd code issue ([#67](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/67)) ([505604b](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/505604b6c749ee65c3e7a10d302f3c2d5b029916))

### [0.13.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.13.0...v0.13.1) (2022-05-27)


### Bug Fixes

* NFS-5720 including transactional annotation on call ([#65](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/65)) ([3caa9ad](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/3caa9ad067670dba7c320639d1f2339f8969fa39))

## [0.13.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.12.1...v0.13.0) (2022-05-27)


### Features

* NFS-1963 bdd tcs and fixes ([4fbec62](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/4fbec62164fef71436fd947eca98b9475136f254))
* NFS-1963 bdd tcs and fixes ([330ba48](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/330ba4889ea17d2e597b1a9485717fd9aa95af17))

### [0.12.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.12.0...v0.12.1) (2022-05-26)


### Bug Fixes

* NFS-5682 removing applicant call ([#63](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/63)) ([8d409ed](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/8d409ede92f4e58e49f7c0feb307580be8b5665a))

## [0.12.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.11.4...v0.12.0) (2022-05-26)


### Features

* NFS-5708 memory increased ([a3c343e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/a3c343e69466eb0833bf601c4bb4d0496b085aa9))
* NFS-5708 memory increased ([67fddc9](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/67fddc905535bf77aa09e8ed8028b089ec4abc9b))
* NFS-5708 memory increased ([050274b](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/050274b52a02840d2b6a2f92e1b105504eff450a))
* NFS-5708 memory increased ([de5c658](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/de5c6587f371d78066d49f95b45ba236a515e39a))
* NFS-5708 memory increased ([9149c97](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/9149c97405d881194d7a2c2a1521053218a3ea91))


### Bug Fixes

* NFS-3670 added proxy server config ([675fae1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/675fae15ee76ddd8347e6d1fcf8798c4b51770b3))
* NFS-3670 Merge branch 'NFS-5708-memeory-increase' of https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api into NFS-5708-memeory-increase ([fb76142](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/fb7614271905228f68d9cac46ac3f87e44c2f759))
* NFS-5242 set DB parameters ([e83d560](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/e83d5600c24e197b403b1108290883f6dc6acc43))
* NFS-5708 added proxy server config ([fc94f02](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/fc94f0230c34441b2cae99153e143859405e7412))
* NFS-5708 updating values and int-values file ([bc1589e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/bc1589ee3315ce72048ef72c7f94d6a750cd6407))

### [0.11.5](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.11.4...v0.11.5) (2022-05-26)


### Bug Fixes

* NFS-5242 set DB parameters ([e83d560](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/e83d5600c24e197b403b1108290883f6dc6acc43))

### [0.11.4](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.11.3...v0.11.4) (2022-05-23)


### Bug Fixes

* NFS-3322 including bakery process changes ([#52](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/52)) ([86d38c2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/86d38c266bca3ef50ec00951066bda0bd06dfb2d))

### [0.11.3](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.11.2...v0.11.3) (2022-05-20)


### Bug Fixes

* NFS-5507 fixing unauthorized flow check ([#53](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/53)) ([24b5a9e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/24b5a9ec877f6438a2efb551efeb33c6a7abc2c6))

### [0.11.2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.11.1...v0.11.2) (2022-05-19)


### Bug Fixes

* NFS-1963 removing email and mobile number fields from request ([#51](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/51)) ([fcab9da](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/fcab9daf540ddb97aeefb93d09af6d8a1c4016de))

### [0.11.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.11.0...v0.11.1) (2022-05-19)


### Bug Fixes

* NFS-1963 re-designing api code ([#49](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/49)) ([239c912](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/239c912a8e0c55c4a665075925eacbabd6470c0d))
* NFS-1963 re-designing api code adding new files ([#50](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/50)) ([f32bf35](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/f32bf35053b7aaf9908a55a7c57562cb74a50d92))

## [0.11.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.10.0...v0.11.0) (2022-05-18)


### Features

* NFS-1963 lookup for merchant included ([#48](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/48)) ([6742d82](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/6742d82d35ee64daf3ad60f95dfe4822fe3200d4))

## [0.10.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.9.0...v0.10.0) (2022-05-18)


### Features

* NFS-1963 liquibase fix ([#46](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/46)) ([03b4867](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/03b4867eada5b33975371507345140dac1741ff8))

## [0.9.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.8.0...v0.9.0) (2022-05-18)


### Features

* NFS-1963 fixing liquibase issue ([#45](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/45)) ([754d611](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/754d611ca1d2bfde17924ef0e8c6ed5b84f8560c))

## [0.8.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.7.0...v0.8.0) (2022-05-18)


### Features

* NFS-1963 merchant submit signup ([#35](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/35)) ([1a5a3ed](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/1a5a3ed2f314074dc393d89eff184575f23cb69a))

## [0.7.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.6.8...v0.7.0) (2022-05-17)


### Features

* NFS-5275 space removed ([#43](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/43)) ([6bc0a98](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/6bc0a98b87f473f0291457b49d405ffe2028927d))

### [0.6.8](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.6.7...v0.6.8) (2022-05-16)


### Features

* NFS-1083 email id limit increased ([#40](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/40)) ([31ec4f2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/31ec4f2e8fa9e07a6ee307fd078dcb3a91f8c3b9))


### Bug Fixes

* NFS-5242 backend api path externalized ([0028071](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/0028071c1d97952e71893b4c2f021b9742c3b432))
* NFS-5242 backend api path externalized ([95c4a57](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/95c4a5751c8ba000501f3cc64697c8650c967672))
* NFS-5242 fixed unit test and removed disabled test cases ([292ff32](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/292ff3205d0d1042fae05e6519c48768dd4828f7))
* NFS-5242 Merge branch 'master' of https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api ([a2ce6c0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/a2ce6c0d28fff5966a47e75fa9dfe85d4983521d))

### [0.6.7](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.6.6...v0.6.7) (2022-05-13)


### Bug Fixes

* NFS-5242 comviva error message corrected ([6e1e83a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/6e1e83ac544afd6aa8ba3060f67015e1598196e5))

### [0.6.6](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.6.5...v0.6.6) (2022-05-12)


### Bug Fixes

* NFS-5242 Merge branch 'master' of https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api ([9691897](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/9691897c0825829074af2540d8652881e441e133))
* NFS-5242 Updated comviva error codes ([60d9087](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/60d90876cb2a852ee783e7cd53a09d446469b1a4))

### [0.6.5](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.6.4...v0.6.5) (2022-05-12)


### Features

* NFS-1959 fix commit msg issue ([e7a2a3f](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/e7a2a3f31739a8cf91d6ad11b92af81beddc329a))
* NFS-1959fix filename extension should be equal to uploaded file extension ([cffab84](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/cffab847d294552eda77601ab94cd582e4c65f5c))
* NFS-2963 fix filename and file extension comparison issue ([a464451](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/a464451c74b529a1d6e8c142b068e1e2319b2fd1))


### Bug Fixes

* NFS-1959 fix commit msg issue ([f186ea2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/f186ea2618bc70473427719f39fdb89c54abc729))
* NFS-1959 fix commit msg issue ([4257c9c](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/4257c9c2a91d905921235499275b486aab8948cf))
* NFS-5242 Updated comviva error codes ([b73697c](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/b73697c3cec2db571a0bcd7a610205ed215969df))
* NFS-5242 Updated comviva error codes ([5678282](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/567828200d27c5be9345b69013083beba029749a))
* NFS-5242 Updated comviva error codes ([a65ea6e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/a65ea6e19a0882d220ffa1ccceef9aaaf798cc3b))
* NFS-5242 Updated new version crosslib ([2a2dfbb](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/2a2dfbba526460235c80ce8ae51af269b3742d8e))
* NFS-5342 Merge branch 'master' of https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api ([39fda65](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/39fda653c37cbea0788883b1a83798fcb6a666af))

### [0.6.4](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.6.3...v0.6.4) (2022-05-12)


### Bug Fixes

* NFS-5242 Merge branch 'master' of https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api ([4db2012](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/4db20120c2ff3edd600c2311421e65e4d2f1dfea))
* NFS-5242 Updated new version crosslib ([a73c58c](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/a73c58c15c8472bc0e82edcfdf037ef26f4dee92))

### [0.6.3](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.6.2...v0.6.3) (2022-05-12)


### Bug Fixes

* NFS-5242 Merge branch 'master' of https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api ([f96cb25](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/f96cb25b5a7a74eacfb5455db078b4bd73ab1c22))
* NFS-5242 Updated new version crosslib ([2c0179a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/2c0179a3947e03f2e491d4723861b57972330684))

### [0.6.2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.6.1...v0.6.2) (2022-05-12)


### Bug Fixes

* NFS-5242 Updated comviva service url ([c47a676](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/c47a6768f47a6a228f271509f77bfa92e8df77dc))

### [0.6.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.6.0...v0.6.1) (2022-05-12)


### Bug Fixes

* NFS-5242 Integrated Cross lib 0.0.60 changes ([920e7f7](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/920e7f7527279ac41e93a6f0fa83053ef31bc8e5))

## [0.6.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.5.1...v0.6.0) (2022-05-11)


### Features

* NFS-1083 updated mobile to sentTo ([#38](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/38)) ([e5e1fdf](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/e5e1fdf5e16213e3f96be12b6c44e753d35678f7))

### [0.5.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.5.0...v0.5.1) (2022-05-11)


### Features

* NFS-1083 merchant email verification onboard ([#30](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/30)) ([3488b8f](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/3488b8f371cf53b236db978807e14207b918ea79))


### Bug Fixes

* NFS-2081 fixed test cases ([168a946](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/168a9464deb467d53579418eb3b0c0876fc0637f))

## [0.5.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.4.1...v0.5.0) (2022-05-10)


### Features

* NFS-2963 updated passcode validator imports ([#36](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/36)) ([0c77925](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/0c7792514d4ab709ead506282b4d9f3763e5aa73))

### [0.4.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.4.0...v0.4.1) (2022-05-06)


### Bug Fixes

* NFS-5349 web request sender included ([#34](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/34)) ([cd2cc3e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/cd2cc3e1f5b62862aa1ebc215b835e464520f80d))

## [0.4.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.3.0...v0.4.0) (2022-05-06)


### Features

* NFS-5357 fix commit msg issue ([4ec6b05](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/4ec6b054e5082af97dbe4a273a27227a58e57d72))
* NFS-5357 fix commit msg issue ([76a22a1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/76a22a14291af7b971c17e32772fb2d246adea6d))

## [0.3.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.2.1...v0.3.0) (2022-05-06)


### Features

* NFS-5357 fix commit msg issue ([#32](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/32)) ([0ea8583](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/0ea8583480c20810ea01f603424eff1388b1408d))

### [0.2.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.2.0...v0.2.1) (2022-05-06)


### Bug Fixes

* NFS-5349 client error fix while Customer submit request ([#31](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/31)) ([3937ec6](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/3937ec619f1a818847050768f9185f7c78a919ea))

## [0.2.0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.1.1...v0.2.0) (2022-05-05)


### Features

* NFS-1959 added db to persist merchant uploaded doc detail ([69afb9e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/69afb9ef92f0ae7c5c6639407eedf3f31e76626a))
* NFS-1959 added db to persist merchant uploaded doc detail ([4d3f23e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/4d3f23efa7d2e6cae4e882725e8d8d16f0fe9213))
* NFS-1959 code coverage ([86812e0](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/86812e0f2c56991f759b3bbe194130682e52e585))
* NFS-1959 code coverage for util class ([56307a4](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/56307a4aefbd7caf300eb3ebfd5608e7017782c5))
* NFS-1959 code coverage for util class ([6ebbe21](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/6ebbe21935f0daa5ad76af30f6385778f7628479))
* NFS-1959 controller/service classes should be included in code-coverage ([348a95a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/348a95a149ea70e630ea660c52e23453b85d8198))
* NFS-1959 create index on extdocId and applicationid ([9f050c2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/9f050c20cbe04090aecd6d63f3aabaa9fccd1177))
* NFS-1959 disable client unit test ([fe02343](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/fe02343955186512add5b2e933e7d94cdfeadf68))
* NFS-1959 disable controller from code coverage ([c67b78a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/c67b78a8b34493dac8d5264158dbfc6b91027f69))
* NFS-1959 disable controller from code coverage ([172a40f](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/172a40fb6c82785237d2b49ef911c11b70cf7956))
* NFS-1959 disable util sonar coverage ([e3b5d10](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/e3b5d10678cbe08432eb3f2570445e908729ff19))
* NFS-1959 externalise config comviva ([61314d8](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/61314d8c1ea0781a6f86191d6e3562257aa7ce98))
* NFS-1959 fix commit msg issue ([1ec7c43](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/1ec7c43e8cf3b2eecc74180a44a123f5ec219b46))
* NFS-1959 fix commit msg issue ([2d73310](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/2d73310d6f8301e7391dae54f0ead1fad343b0db))
* NFS-1959 fix PR review comments ([bbb8ac6](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/bbb8ac6205cf9557eb94ba2af4e2b23e15e60b99))
* NFS-1959 fix PR review comments ([2bb9aa5](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/2bb9aa564a2310eb878700097c9df9c6f7c0d874))
* NFS-1959 fix PR review comments ([7e72681](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/7e7268159065fbb813d7d8921787eba40bda43f5))
* NFS-1959 fix unit test failure ([38b4206](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/38b42069ea0fb4801585491f8a330c7fdaab20e6))
* NFS-1959 java doc ([46388dc](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/46388dcd038023852e3bdd0d7d1ef7be8b4fc6e1))
* NFS-1959 merchant doc upload initial commit ([8d6d3e1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/8d6d3e1ba19750ce4366aab6a0f607dfd02759e0))
* NFS-1959 merchant doc upload initial commit ([d06078a](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/d06078ad4f2278939d0178f1193108b67459b939))
* NFS-1959 response mapping fixes ([dbc6be6](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/dbc6be6e3269945c7ae186bec42b3032d54a831b))
* NFS-1959 self-review fixed ([cd9a80e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/cd9a80e2ec32f67f1e0800ec3765692e15ca5ce1))

### [0.1.1](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/compare/v0.1.0...v0.1.1) (2022-05-04)


### Features

* NFS-1059 add keycloak config to verify token ([#24](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/24)) ([1d362c2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/1d362c28f109949452361b29543be01eeda1cb0c))
* NFS-1772 get citizen api ([#22](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/22)) ([3ca1136](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/3ca11361a380244699efbf3df5587329f8e133a1))
* NFS-1804 ([4bfc5dd](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/4bfc5dd2039ee70c69dcc026f3c77be51ddbf424))
* NFS-1804 Signup_BDD ([56363a3](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/56363a353a1127d566e7816fa09dad29c11fa067))
* NFS-4347 user pin validations ([71efda7](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/71efda71ac03866bc1b18062656be83a2d0c3282))
* NFS-4347 user pin validations ([6ae4cd4](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/6ae4cd4aca85c86f4812bbe2d0b007216ffa2dc6))
* NFS-4973 enable helm package ([9353215](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/9353215af162ed92c2a6a65d2a7334091793e6d3))
* NFS-4973 enable helm package ([7bcc868](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/7bcc8689fe4afc56192ab2fd86c29da1dd10c690))


### Bug Fixes

* NFS-0000 fix of zap proxy ([48f25e6](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/48f25e63188c394c07f811c0d6419a720108f87c))
* NFS-0000 fixed int required int configurations ([0c2df0e](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/0c2df0e1c131a8e09a7e7664bb5e77523e5ed3f4))
* NFS-1772 spring boot version upgrade ([f3aa607](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/f3aa607c137c05dd9f393519d108e571956ed0a7))
* NFS-4347 quality gate fix for excluding protobuf ([#20](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/20)) ([528239b](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/528239b2ad63932c7d46025bcadec9c1f4dfc423))
* NFS-4973 Upgraded spring boot due to trivy scan fix ([9801d5d](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/9801d5dfdbe991cf8bdbe4f6da622bb14f7bf893))
* NFS-4973 Upgraded spring boot due to trivy scan fix ([d29ef43](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/d29ef4395e248438032ab114483d1bd08eb624b2))
* NFS-5218 email is made optional ([#23](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/23)) ([54bff6c](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/54bff6c9d4b3b3eca7c7f18f86792599b2a31968))
* NFS-5263 password forceful option removed ([#26](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/issues/26)) ([77a09c2](https://github.com/NEOM-KSA/neom-fss-neompay-onboarding-api/commit/77a09c2a9a72b934248fb25d954da32673ef076a))
