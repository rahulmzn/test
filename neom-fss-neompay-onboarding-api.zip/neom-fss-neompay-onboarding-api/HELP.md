# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Rest with Protobuf](https://docs.spring.io/spring-boot/docs/2.6.5/reference/htmlsingle/#howto-execute-liquibase-database-migrations-on-startup)

