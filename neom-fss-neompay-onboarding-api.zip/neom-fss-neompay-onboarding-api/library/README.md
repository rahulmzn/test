# Library Module

<!-- ABOUT THE MODULE -->

## About The Service Module

Library module will be responsible for Swagger, Api docs, Api models, auto generated models by
protocol buffer and swagger utility

Package and exceptions are defined below

## Package and Role Definition

* proto directory will contain protocol buffer (protobuf) schema definition which will be used by
  build.gradle script to auto generate models.
* java source package will contain auto generated models by protobuf and swagger utility.






